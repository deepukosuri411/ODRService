﻿//using Fsl.Utilities.Network.IbmMq;
//using IBM.WMQ;
//using Microsoft.Extensions.Options;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
////using OrderStatusService.Core.Model;
//using OrderStatusService.Core.Interfaces.Logging;

//using OrderStatusService.Core.Interfaces.Service;
//using OrderStatusService.Core.Enumeration;
//using Microsoft.Extensions.Hosting;

//using OrderStatusService.Core.Model;

//using Fsl.Utilities.Models;
//using Fsl.Utilities.CertificatesHelper;
//using FSLContext = OrderStatusService.Core.Model.FSLContext;

//namespace OrderStatusService.Api.Listeners
//{
//    public class Listener : IIbmMqListener
//    {
//        private MQQueueManager mqManager = null;
//        #region Config Server members
//        private IOptionsSnapshot<OrderListenerConfigurations> orderListnerConfigurations { get; set; }
//        #endregion

//        private MQQueue mqInQueue = null;
//        private bool keepRunning = true;
//        FSLContext ctx = null;
//        ICommonLogger _logger;
//        public ILogisticsResponseService lgsHandler { get; set; }
//        private readonly IHostEnvironment env;
//        public Listener(FSLContext _ctx, IOptionsSnapshot<OrderListenerConfigurations> _orderListnerConfigurations, ICommonLogger logger, ILogisticsResponseService _lgsHandler, IHostEnvironment _env)
//        {
//            orderListnerConfigurations = _orderListnerConfigurations;
//            ctx = _ctx;
//            logger = _logger;
//            env = _env;
//            this.lgsHandler = _lgsHandler;
//            ctx.grpListenerConfigurations = orderListnerConfigurations.Value;
//        }

//        void IIbmMqListener.Receive()
//        {

//            PullMessage();
//            try
//            {
//                if (mqManager != null)
//                {
//                    mqManager.Disconnect();
//                    System.Console.Out.WriteLine("Disconnected from queue manager");
//                    _logger.Info("","","","","Disconnected from queue manager");
//                }
//            }
//            catch (MQException mqex)
//            {
//                System.Console.Out.WriteLine("MQException CC=" + mqex.CompletionCode + " : RC=" + mqex.ReasonCode);
//                _logger.Error("","","","","MQException CC=" + mqex.CompletionCode + " : RC=" + mqex.ReasonCode);

//            }
//            ReConnect();
//        }

//        private void PullMessage()
//        {
//            InitQMgrAndQueue();
//            MQGetMessageOptions gmo = new MQGetMessageOptions();
//            gmo.Options |= MQC.MQGMO_WAIT | MQC.MQGMO_FAIL_IF_QUIESCING;
//            gmo.WaitInterval = 2000;
//            MQMessage msg = null;
//            while (keepRunning)
//            {
//                try
//                {
//                    msg = new MQMessage();
//                    mqInQueue = mqManager.AccessQueue(ctx.grpListenerConfigurations.IbmMqConfigrations.MqGolfToFsl, MQC.MQOO_INPUT_AS_Q_DEF + MQC.MQOO_FAIL_IF_QUIESCING);
//                    mqInQueue.Get(msg, gmo);
//                    var message = msg.ReadString(msg.MessageLength);
//                    _logger.Info("","","","","Inside DAOListener.Receive Picked item from Golf mq is:");
//                    _logger.Info("","","",message,"");
//                    ctx.InMsg.InMessage = message;

//                    try
//                    {
//                        var ibmMQContextTask = Task.Run(() => lgsHandler.Process(ctx, orderListnerConfigurations.Value));
//                        ibmMQContextTask.Wait();
//                        string grpResponse = ibmMQContextTask.Result;


//                    }
//                    catch (System.Exception ex)
//                    {
//                        _logger.Error("","","",$"ExceptionMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
//                    }
//                }
//                catch (MQException mqex)
//                {
//                    if (mqex.Reason != MQC.MQRC_NO_MSG_AVAILABLE)
//                    {
//                        keepRunning = false;  // severe error - time to exit
//                        System.Console.Out.WriteLine("MQException CC=" + mqex.CompletionCode + " : RC=" + mqex.ReasonCode);
//                        _logger.Error("", "", "","MQException CC=" + mqex.CompletionCode + " : RC=" + mqex.ReasonCode);
//                    }
//                }
//                catch (System.IO.IOException ioex)
//                {
//                    System.Console.Out.WriteLine("ioex=" + ioex.Message);
//                    _logger.Error("", "", "",$"ExceptionMessage: {ioex.Message}, StackTrace: {ioex.StackTrace}");
//                }
//                finally
//                {
//                    if (mqInQueue != null)
//                    {
//                        mqInQueue.Close();
//                    }
//                }
//            }
//        }

//        private void PushToIbmMQ(string grpResponse)
//        {
//            try
//            {
//                _logger.Info("","","","Pushed GrpResponse To RMQ","");
//                _logger.Info("", "", "", grpResponse,"");
//                mqInQueue = mqManager.AccessQueue(ctx.grpListenerConfigurations.IbmMqConfigrations.MqFslToOfs, MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING);
//                MQMessage queueMessage = new MQMessage();
//                int characterSetId = ctx.grpListenerConfigurations.IbmMqConfigrations.CharacterSetId;
//                queueMessage.Format = MQC.MQFMT_STRING;
//                if (characterSetId != -1)
//                {
//                    queueMessage.CharacterSet = characterSetId;
//                }
//                queueMessage.WriteString(grpResponse);
//                MQPutMessageOptions options = new MQPutMessageOptions();
//                mqInQueue.Put(queueMessage, options);
//            }
//            catch (System.Exception ex)
//            {
//                _logger.Error("", "", "", $"Error while Pushing  GrpResponse is  : {ex.Message}, StackTrace: {ex.StackTrace}");
//                System.Console.Out.WriteLine($"Error while Pushing  GrpResponse is  : {ex.Message}, StackTrace: {ex.StackTrace}");
//            }

//        }

//        public void InitQMgrAndQueue()
//        {
//            IbmMqConfig ibmMqConfig = new IbmMqConfig();
//            ibmMqConfig.Channel = ctx.grpListenerConfigurations.IbmMqConfigrations.MqChannel;
//            ibmMqConfig.CipherSuite = ctx.grpListenerConfigurations.IbmMqConfigrations.MqCiperSpecProperty;
//            ibmMqConfig.Host = ctx.grpListenerConfigurations.IbmMqConfigrations.MqHost;
//            ibmMqConfig.KeyRepository = ctx.grpListenerConfigurations.IbmMqConfigrations.MqCertStoreProperty;
//            ibmMqConfig.Port = ctx.grpListenerConfigurations.IbmMqConfigrations.MqPort;
//            ibmMqConfig.QMgr = ctx.grpListenerConfigurations.IbmMqConfigrations.MqQueueManager;
//            ibmMqConfig.CharacterSetId = ctx.grpListenerConfigurations.IbmMqConfigrations.CharacterSetId;
//            mqManager = new IbmMqCertificateHelper().InitQMgrAndQueue(ctx.grpListenerConfigurations?.IbmMqCertConfig, env.ContentRootPath, ibmMqConfig);
//        }

//        private void ReConnect()
//        {
//            keepRunning = true;
//            PullMessage();
//        }
//    }
//}
