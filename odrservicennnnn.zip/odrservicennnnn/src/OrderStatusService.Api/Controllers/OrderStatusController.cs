﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Interfaces.Repository;
using OrderStatusService.Core.Interfaces.Service;
using OrderStatusService.Core.ViewModel;
using System.Threading.Tasks;

namespace OrderStatusService.Api.Controllers
{
    public class OrderStatusController : BaseController
    {
        private IOrderStatusMessageService service { get; }
        public IOrderStatusRepository repository { get; set; }
        public OrderStatusController(IOrderStatusMessageService service)
        {
            this.service = service;
        }

        [HttpPost("api/OrderStatusServiceAsync")]
        public async Task<IActionResult> OrderStatusServiceAsync(IFormFile formFile)
        {
            OrderStatusOutputViewModel objViewModel = await service.OrderStatusServiceAsync(formFile, false);
            if (objViewModel.ResultData == null)
            {
                objViewModel.HasErrorOccured = true;
                objViewModel.ErrorMessage = GlobalConstants.NoRecordAvailable;
                return NotFound(objViewModel);
            }
            return Ok(objViewModel.ResultData);
        }

        [HttpPost("api/OrderStatusServiceAsyncTest")]
        public async Task<IActionResult> OrderStatusServiceAsyncTest(IFormFile formFile)
        {
            OrderStatusOutputViewModel objViewModel = await service.OrderStatusServiceAsync(formFile, true);
            if (objViewModel.ResultData == null)
            {
                objViewModel.HasErrorOccured = true;
                objViewModel.ErrorMessage = GlobalConstants.NoRecordAvailable;
                return NotFound(objViewModel);
            }
            return Ok(objViewModel.ResultData);
        }
    }
}