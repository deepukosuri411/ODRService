﻿using Fsl.Utilities.Common.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using OrderStatusService.Core.Global.Configs;
using System;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Api.Controllers
{
    [ExcludeFromCodeCoverage]
    public class ConfigController : BaseController
    {
        private IOptionsSnapshot<GlobalConfigs> _configServerData { get; set; }
        private IConfigurationRoot _config { get; set; }

        public ConfigController(IConfiguration config, IOptionsSnapshot<GlobalConfigs> configServerData)
        {
            if (configServerData != null)
                _configServerData = configServerData;

            _config = (IConfigurationRoot)config;
        }

        [HttpGet("api/configserverdata")]
        public IActionResult ConfigServer()
        {
            Console.WriteLine($"Inside ConfigServer Action Method | ConfigServer Data: {_configServerData.Value.ToJsonString()}");
            return Ok(_configServerData.Value);
        }

        [HttpGet("api/reload")]
        public IActionResult Reload()
        {
            if (_config != null)
            {
                _config.Reload();
            }
            return Ok("Configurations has been reloaded successfully");
        }
    }
}