﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Api.Controllers
{
    [ExcludeFromCodeCoverage]
    [ApiController]
    [Produces("application/xml", "application/json")]
    public class BaseController : Controller
    {
        //test
    }
}