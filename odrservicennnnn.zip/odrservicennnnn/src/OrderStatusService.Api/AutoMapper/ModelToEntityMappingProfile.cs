﻿using AutoMapper;
using Fsl.Utilities.Models;
using OrderStatusService.Core.Model;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Api.AutoMapper
{
    [ExcludeFromCodeCoverage]
    public class ModelToEntityMappingProfile : Profile
    {
        public ModelToEntityMappingProfile()
        {
            AllowNullCollections = true;

            CreateMap<InputData, InputRequest>()
                 .ForMember(c => c.EntityType, d => d.MapFrom(y => y.KeyName))
                 .ForMember(c => c.EntityValue, d => d.MapFrom(y => y.KeyValue))
                 .ForMember(c => c.EventID, d => d.MapFrom(y => y.EventType))
                 .ForMember(c => c.EventTimestamp, d => d.MapFrom(y => y.EventTimestamp))
                 .ForMember(c => c.Attributes, d => d.MapFrom(y => y.Attributes));
        }
    }
}
