﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Extensions.Configuration;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;

namespace OrderStatusService.Api.MiddleWare.Formatter
{
    [ExcludeFromCodeCoverage]
    public class OutputFormatter : TextOutputFormatter
    {
        private readonly string mediatype;
        public OutputFormatter(IConfiguration configuration)
        {
            mediatype = configuration["GlobalSettings:MediaFormatter"].ToString();
            if (mediatype.ToUpper() == "XML")
                SupportedMediaTypes.Add(MediaTypeHeaderValue.Parse("application/xml"));
            else
                SupportedMediaTypes.Add(MediaTypeHeaderValue.Parse("application/json"));
            SupportedEncodings.Add(Encoding.UTF8);
            SupportedEncodings.Add(Encoding.Unicode);
        }

        public override async Task WriteResponseBodyAsync(OutputFormatterWriteContext context, Encoding selectedEncoding)
        {
            string responseData = (mediatype.ToUpper() == "JSON") ?
                                                JsonConvert.SerializeObject(context.Object)
                                                : SerializeXML(context.Object);
            await context.HttpContext.Response.WriteAsync(responseData);
        }

        private string SerializeXML(object dataToSerialize)
        {
            if (dataToSerialize == null)
                return null;
            else
                return dataToSerialize.ToString();
        }
    }
}
