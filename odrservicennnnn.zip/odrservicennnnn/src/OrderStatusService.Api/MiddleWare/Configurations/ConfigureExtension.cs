﻿using Microsoft.AspNetCore.Builder;
using OrderStatusService.Api.MiddleWare.Exceptions;
using OrderStatusService.Core.Constants;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Api.MiddleWare.Configurations
{
    [ExcludeFromCodeCoverage]
    public static class ConfigureExtension
    {
        private const string swaggerEndpoint = "/swagger/v1/swagger.json";

        public static void AddCustomConfiguration(this IApplicationBuilder app)
        {
            app.ConfigureExceptionMiddleware();
            //app.UseDiscoveryClient();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint(swaggerEndpoint, GlobalConstants.MicroServiceNameOrderStatus);
            });
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
