﻿using AutoMapper;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using OrderStatusService.Api.AutoMapper;
using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Global.Configs;
using OrderStatusService.Core.Interfaces.CredHub;
using OrderStatusService.Core.Interfaces.Logging;
using OrderStatusService.Core.Interfaces.Repository;
using OrderStatusService.Core.Interfaces.Service;
using OrderStatusService.Core.Interfaces.Utility;
using OrderStatusService.Infrastructure.Logging;
using OrderStatusService.Infrastructure.Repository;
using OrderStatusService.Infrastructure.Service;
using OrderStatusService.Infrastructure.Utility;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;

namespace OrderStatusService.Api.MiddleWare.Configurations
{
    [ExcludeFromCodeCoverage]
    public static class ContainerExtension
    {
        public static IServiceCollection AddContainerServices(this IServiceCollection container)
        {
            //Configure the container
            container.AddSingleton<GlobalConfigs>();
            container.AddTransient<IOrderStatusMessageService, OrderStatusMessageService>();
            container.AddTransient<ISyncroMessageRepository, SyncroMessageRepository>();
            container.AddTransient<IPdslRepository, PdslRepository>();
            container.AddTransient<ICredHubConfigs, CredHubConfigs>();
            container.AddTransient<IHttpMethodUtility, HttpMethodUtility>();
            container.AddSingleton<ICommonLogger, CommonLogger>();
            container.AddTransient<IOrderStatusRepository, OrderStatusRepository>();
            container.AddTransient<IMediaFormatUtility, MediaFormatUtility>();
            container.AddTransient<IOrderStatusRepository, OrderStatusRepository>();
            //container.AddScoped<IRabbitMQListener, RabbitMqListener>();
            //container.AddScoped(typeof(IMqPublisher<>), typeof(MqPublisher<>));
            container.AddAutomapper();
            container.AddCredHub();
            container.AddFileProvider();
            container.AddHttpContextAccessor();

            return container;
        }

        private static void AddAutomapper(this IServiceCollection container)
        {
            MapperConfiguration mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new ModelToEntityMappingProfile());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            container.AddSingleton(mapper);
        }

        private static void AddCredHub(this IServiceCollection container)
        {
            container.AddSingleton<ICredHubConfigs>(new CredHubConfigs
            {
                LogsV2ConnectionString = GlobalConstants.LogsV2ConnectionString.GetCredHubData(),
                HostName = GlobalConstants.RmqHostName.GetCredHubData(),
                HostServer = GlobalConstants.RmqHostName.GetCredHubData(),
                ServerName = GlobalConstants.RmqServerName.GetCredHubData(),
                UserName = GlobalConstants.RmqUserName.GetCredHubData(),
                Password = GlobalConstants.RmqPswd.GetCredHubData(),
                VirtualHost = GlobalConstants.RmqVirtualHost.GetCredHubData(),
                Port = Convert.ToInt32(GlobalConstants.RmqPort.GetCredHubData()),
                DaoConnectionString = GlobalConstants.DaoConnectionString.GetCredHubData(),
                EmeaConnectionString = GlobalConstants.EmeaConnectionString.GetCredHubData(),
                ApjConnectionString = GlobalConstants.ApjConnectionString.GetCredHubData(),
                LDRConnectionString = GlobalConstants.LDRConnectionString.GetCredHubData()
            });
        }

        private static void AddFileProvider(this IServiceCollection container)
        {
            IFileProvider physicalProvider = new PhysicalFileProvider(Directory.GetCurrentDirectory());
            container.AddSingleton(physicalProvider);
        }
    }
}
