﻿using LogIt;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Global.Configs;
using OrderStatusService.Core.Interfaces.Utility;
using OrderStatusService.Infrastructure.Utility;
using Polly;
using Polly.Extensions.Http;
using Steeltoe.Extensions.Configuration.ConfigServer;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace OrderStatusService.Api.MiddleWare.Configurations
{
    [ExcludeFromCodeCoverage]
    public static class ServicesExtension
    {
        public static IServiceCollection AddCustomServices(this IServiceCollection services, IConfiguration configuration)
        {
            return services.AddAsyncServices(configuration);
        }

        private static IServiceCollection AddAsyncServices(this IServiceCollection services, IConfiguration configuration)
        {
            // Adds services required for using options.
            services.AddOptions();

            // ConfigServer
            services.ConfigureConfigServer(configuration);

            // Configure CredHub And LogConfigs
            services.ConfigureLogConfigs(configuration);

            // Service Discovery
            //services.AddDiscoveryClient(configuration);

            // Swagger Configuration
            services.ConfigureSwagger();

            // Http Client Factory
            services.ConfigureHttpClientFactory(configuration);

            return services;
        }

        private static void ConfigureConfigServer(this IServiceCollection services, IConfiguration configuration)
        {
            services.ConfigureConfigServerClientOptions(configuration);
            services.Configure<GlobalConfigs>(configuration);
            //services.AddConfiguration(configuration);
        }

        private static void ConfigureHttpClientFactory(this IServiceCollection services, IConfiguration configuration)
        {
            string config = configuration["HttpClientFactorySettings:TimeOutInMinutes"];
            int timeOutInMinutes = config.TryParseToInt(10);

            config = configuration["HttpClientFactorySettings:RetryCount"];
            int retryCount = config.TryParseToInt(0);

            // Use IHttpClientFactory to implement resilient HTTP requests
            IHttpClientBuilder clientBuilder = services.AddHttpClient<IHttpMethodUtility, HttpMethodUtility>(client =>
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(GlobalConstants.HttpMediaType));
                client.Timeout = TimeSpan.FromMinutes(timeOutInMinutes);
                //To create SSL/TLS secure channel.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            });
            if (retryCount > 0)
                clientBuilder.AddPolicyHandler(GetRetryPolicy(retryCount));
        }

        /// <summary>
        /// Http message resiliency policy to retry the http call in case it fails.
        /// </summary>
        /// <returns></returns>
        private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy(int retryCount)
        {
            return HttpPolicyExtensions
                .HandleTransientHttpError()
                .WaitAndRetryAsync(retryCount, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
        }

        private static void ConfigureSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(setup =>
            {
                setup.SwaggerDoc(GlobalConstants.SwaggerVesrion, new OpenApiInfo { Title = GlobalConstants.MicroServiceNameOrderStatus, Description = GlobalConstants.MicroServiceNameOrderStatus, Version = GlobalConstants.SwaggerVesrion });
            });
        }

        private static void ConfigureLogConfigs(this IServiceCollection services, IConfiguration configuration)
        {
            LogConfigs logConfigs = new LogConfigs();
            configuration.GetSection("LogConfigs").Bind(logConfigs);

            string mongoDbConnectionString = logConfigs.MongoDbConnectionString;
            if (string.IsNullOrEmpty(mongoDbConnectionString))
                logConfigs.MongoDbConnectionString = GlobalConstants.LogsV2ConnectionString.GetCredHubData();

            services.AddSingleton<ICustomLogger>(provider => new CustomLogger(logConfigs));
        }
    }
}