﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NJsonSchema;
using OrderStatusService.Api.MiddleWare.Exception;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace OrderStatusService.Api.MiddleWare.Validator
{
    [ExcludeFromCodeCoverage]
    public static class InputValidator
    {
        public static void Validate<T>(T obj, string serviceName, string jsonFilePath)
        {
            string schema;
            Dictionary<string, string> schemas = new Dictionary<string, string>();
            using (StreamReader streamReader = new StreamReader(jsonFilePath))
            {
                schema = streamReader.ReadToEnd();
                schemas.Add(serviceName, schema);
            }

            Task<JsonSchema> schemaTask = Task.Run(() => JsonSchema.FromJsonAsync(schemas[serviceName]));
            schemaTask.Wait();

            string inputJson = Serialize<T>(obj);
            JObject jObj = JObject.Parse(inputJson);
            ICollection<NJsonSchema.Validation.ValidationError> error = schemaTask.Result.Validate(jObj);
            if (error.Count > 0)
            {
                throw new InputValidatorException($"Json Schema Validation failed with following issues : \n{string.Join("\n", error.Select(e => e.Path + ":" + e.Kind).ToArray())} | Input JSON: {inputJson}");
            }
        }

        public static string Serialize<T>(T obj)
        {
            try
            {
                return JsonConvert.SerializeObject(obj, new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore
                });
            }
            catch (System.Exception ex)
            {
                throw new InputValidatorException($"Error while serializing the input json ::{ex.Message}::{ex.InnerException}");
            }
        }
    }
}
