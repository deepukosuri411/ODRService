﻿using Microsoft.AspNetCore.Builder;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Api.MiddleWare.Exceptions
{
    [ExcludeFromCodeCoverage]
    public static class ErrorLoggingExtensions
    {
        public static void ConfigureExceptionMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ErrorLoggingMiddleware>();
        }
    }
}
