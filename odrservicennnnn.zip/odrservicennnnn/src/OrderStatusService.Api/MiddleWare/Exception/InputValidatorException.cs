﻿using System;
using System.Runtime.Serialization;

namespace OrderStatusService.Api.MiddleWare.Exception
{
    [Serializable]
    public class InputValidatorException : System.Exception
    {
        public InputValidatorException(string message) : base(message)
        {
        }

        protected InputValidatorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
