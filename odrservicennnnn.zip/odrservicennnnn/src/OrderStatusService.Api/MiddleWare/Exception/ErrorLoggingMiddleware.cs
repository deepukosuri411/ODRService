﻿using Microsoft.AspNetCore.Http;
using OrderStatusService.Api.MiddleWare.Exception;
using OrderStatusService.Core.ExceptionModel;
using OrderStatusService.Core.Interfaces.Logging;
using OrderStatusService.Infrastructure.Utility;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading.Tasks;

namespace OrderStatusService.Api.MiddleWare.Exceptions
{
    [ExcludeFromCodeCoverage]
    public class ErrorLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private ICommonLogger logger { get; }

        public ErrorLoggingMiddleware(RequestDelegate next, ICommonLogger logger)
        {
            _next = next;
            this.logger = logger;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (InputValidatorException ex)
            {
                string message = MessageUtility.ConstructMiddlewareMessage(ex.Message.ToString());
                logger.Error(this, httpContext.TraceIdentifier, message);
                await HandleExceptionAsync(httpContext, ex.Message.ToString(), HttpStatusCode.BadRequest);
            }
            catch (KeyNotFoundException ex)
            {
                string message = MessageUtility.ConstructMiddlewareMessage(ex.Message.ToString());
                logger.Error(this, httpContext.TraceIdentifier, message);
                await HandleExceptionAsync(httpContext, ex.Message.ToString(), HttpStatusCode.NotFound);
            }
            catch (System.Exception ex)
            {
                string message = MessageUtility.ConstructMiddlewareMessage($"{ ex.Message}:{ ex.InnerException}:{ ex.StackTrace}");
                logger.Error(this, httpContext.TraceIdentifier, message);
                await HandleExceptionAsync(httpContext, "Internal Server Error", HttpStatusCode.InternalServerError);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, string Message, HttpStatusCode httpStatusCode)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)httpStatusCode;

            return context.Response.WriteAsync(new ErrorResponse()
            {
                StatusCode = context.Response.StatusCode,
                Message = Message
            }.ToString());
        }
    }
}
