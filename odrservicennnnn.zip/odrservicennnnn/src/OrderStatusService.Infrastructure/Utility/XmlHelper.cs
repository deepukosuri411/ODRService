﻿using Microsoft.AspNetCore.Http;
using OrderStatusService.Core.Common;
using System;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace OrderStatusService.Infrastructure.Utility
{
    public class XmlHelper
    {
        const string xmlnsNs = "http://www.w3.org/2000/xmlns/";
        const string defaultNs = "xmlns";
        XmlDocument output;

        /// <summary>
        /// Serializes the specified type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        public static string Serialize<T>(T type)
        {
            string output = string.Empty;
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (StringWriter writer = new Utf8StringWriter())
            {
                writer.NewLine = string.Empty;
                XmlTextWriter tw = new XmlTextWriter(writer);
                serializer.Serialize(tw, type);
                output = writer.ToString();
            }
            return output;
        }

        /// <summary>
        /// Removes the NS fields
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <returns></returns>
        public string RemoveAllNS(string xmlDocument)
        {
            XmlDocument inputdoc = new XmlDocument();
            XmlDocument doc;
            inputdoc.LoadXml(xmlDocument);
            doc = StripNS(inputdoc);
            return doc.InnerXml;
        }


        /// <summary>
        /// Validates the XML
        /// </summary>
        /// <param name="xDoc"></param>
        /// <param name="xSDFileName"></param>
        /// <param name="targetNamespace"></param>
        internal void ValidateXML(XDocument xDoc, string xSDFileName, string targetNamespace)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Removes the NS tag from xml document
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public XmlDocument StripNS(XmlDocument input)
        {
            output = new XmlDocument();
            output.PreserveWhitespace = true;

            foreach (XmlNode child in input.ChildNodes)
            {
                //changed code for error 'The node to be inserted is from a different document context'
                //The input xmldocument node is being added to the output document
                XmlNode outputnode = output.ImportNode(StripNamespace(child), true);
                output.AppendChild(outputnode);
            }

            return output;
        }

        /// <summary>
        /// Removes the name spaces from the input node
        /// </summary>
        /// <param name="inputNode"></param>
        /// <returns></returns>
        XmlNode StripNamespace(XmlNode inputNode)
        {
            XmlNode outputNode = output.CreateNode(inputNode.NodeType, inputNode.LocalName, null);

            // copy attributes, stripping namespaces
            if (inputNode.Attributes != null)
            {
                foreach (XmlAttribute inputAttribute in inputNode.Attributes)
                {
                    if (!(inputAttribute.NamespaceURI == xmlnsNs || inputAttribute.LocalName == defaultNs))
                    {
                        XmlAttribute outputAttribute = output.CreateAttribute(inputAttribute.LocalName);
                        outputAttribute.Value = inputAttribute.Value;
                        outputNode.Attributes.Append(outputAttribute);
                    }
                }
            }

            // copy child nodes, stripping namespaces
            foreach (XmlNode childNode in inputNode.ChildNodes)
            {
                //changed code for error 'The node to be inserted is from a different document context'
                //The input xmldocument node is being added to the output document
                XmlNode outputnode = output.ImportNode(StripNamespace(childNode), true);
                outputNode.AppendChild(outputnode);
            }

            // copy value for nodes without children
            if (inputNode.Value != null)
            {
                outputNode.Value = inputNode.Value;
            }
            return outputNode;
        }

        /// <summary>
        /// Gets the XDocument for Iform File
        /// </summary>
        /// <param name="formFile"></param>
        /// <returns></returns>
        public static XmlDocument GetXmlDocument(IFormFile formFile)
        {
            XmlDocument doc = new XmlDocument();
            if (formFile != null)
            {
                var reader = new StreamReader(formFile.OpenReadStream());
                doc.Load(reader);
            }

            return doc;
        }
    }
}

