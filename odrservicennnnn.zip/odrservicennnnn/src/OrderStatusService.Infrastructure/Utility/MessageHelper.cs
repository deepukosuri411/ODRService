﻿using OrderStatusService.Core.Constants;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Infrastructure.Utility
{
    [ExcludeFromCodeCoverage]
    public static class MessageHelper
    {
        public static string ConstructVMMessage(string traceId, string message)
        {
            return $"{GlobalConstants.TraceIdMsg}{traceId} | {message}";
        }
        public static string ConstructControllerMessage(string controllerIndentity, string message)
        {
            return $"{controllerIndentity} | {message}";
        }

    }
}
