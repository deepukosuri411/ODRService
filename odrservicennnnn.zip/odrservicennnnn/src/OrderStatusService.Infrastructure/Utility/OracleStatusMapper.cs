﻿using OrderStatusService.Core.Model;
using OrderStatusService.Core.Model.Input;
using System.Collections.Generic;

namespace OrderStatusService.Infrastructure.Utility
{
    public class OracleStatusMapper
    {
        public static ODRInputEntity GetInputEntity(ODRRequest orderStatusRequest)
        {
            ODRInputEntity OrderStatusInputEntity = new ODRInputEntity();
            OrderStatusInputEntity.OrderValInputTbl = new ODRTbl();

            List<OdrPayload> ordList = new List<OdrPayload>();

                OdrPayload orderInfoT = new OdrPayload();
                orderInfoT.Created_By = System.Environment.MachineName ;
            orderInfoT.Sender_Id = orderStatusRequest.Sender_Id;
                orderInfoT.Order_Type = orderStatusRequest.Order_Type;
            orderInfoT.SyncroOrder = orderStatusRequest.Value1;
            orderInfoT.ItemBom = orderStatusRequest.Value2;
            orderInfoT.CloB_XML = orderStatusRequest.Clob_XML;
            orderInfoT.AI_Order_No = orderStatusRequest.AI_Order_Number;

            ordList.Add(orderInfoT);

            OrderStatusInputEntity.OrderValInputTbl.Value = ordList.ToArray();
            return OrderStatusInputEntity;
        }
    }
}
