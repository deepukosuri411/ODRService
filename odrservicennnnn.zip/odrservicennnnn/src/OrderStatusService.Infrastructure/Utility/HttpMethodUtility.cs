﻿using Newtonsoft.Json;
using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Interfaces.Utility;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace OrderStatusService.Infrastructure.Utility
{
    public class HttpMethodUtility : IHttpMethodUtility
    {
        #region Private Properties
        private HttpClient httpClient { get; }
        #endregion

        #region Constructor
        public HttpMethodUtility(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }
        #endregion

        /// <summary>
        /// Post Method
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestUrl"></param>
        /// <param name="payload"></param>
        /// <param name="customHeaders"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> HttpPostAsync<T>(string requestUrl, T payload, Dictionary<string, string> customHeaders = null)
        {
            string json;
            httpClient.DefaultRequestHeaders.Clear();
            
            if (customHeaders != null)
            {
                foreach (var customHeader in customHeaders)
                    httpClient.DefaultRequestHeaders.Add(customHeader.Key, customHeader.Value);
            }

            if (!(payload is string))
                json = JsonConvert.SerializeObject(payload);
            else
                json = payload.ToString();

            var stringContent = new StringContent(json, Encoding.UTF8, GlobalConstants.HttpMediaType);

            //To create SSL/TLS secure channel.
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                   | SecurityProtocolType.Tls11
                   | SecurityProtocolType.Tls12;

            var response = await httpClient.PostAsync(requestUrl, stringContent);
            return response;
        }

        /// <summary>
        /// Gets Method
        /// </summary>
        /// <param name="requestUrl"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> HttpGetDataAsync(string requestUrl)
        {
            var response = await httpClient.GetAsync(requestUrl);
            return response;
        }

    }
}
