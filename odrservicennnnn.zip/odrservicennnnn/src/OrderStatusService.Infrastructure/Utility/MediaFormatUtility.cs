﻿using Newtonsoft.Json;
using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.Interfaces.Utility;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Xml.Serialization;

namespace OrderStatusService.Infrastructure.Utility
{
    public class MediaFormatUtility : IMediaFormatUtility
    {
        /// <summary>
        /// Generic method that converts a COM object to JSON or XML based on configuration.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objFaasResponse"></param>
        /// <param name="mediaType"></param>
        /// <param name="jsonSerializerType"></param>
        /// <returns></returns>
        public string SerializeToXmlorJson<T>(T objFaasResponse, string mediaType, JsonSerializerType jsonSerializerType = JsonSerializerType.NewtonSoftJson)
        {
            string response = string.Empty;
            if (string.Equals(mediaType, GlobalConstants.XmlMediaType))
            {
                XmlSerializerNamespaces objXMLSerNameSpace = new XmlSerializerNamespaces();
                objXMLSerNameSpace.Add("", "");
                response = SerializeObject(objFaasResponse, objXMLSerNameSpace);
            }
            else if (string.Equals(mediaType, GlobalConstants.JsonMediaType))
            {
                if (jsonSerializerType == JsonSerializerType.NewtonSoftJson)
                    response = JsonConvert.SerializeObject(objFaasResponse);
                else
                {
                    DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T));
                    using (MemoryStream ms = new MemoryStream())
                    {
                        ser.WriteObject(ms, objFaasResponse);
                        response = Encoding.UTF8.GetString(ms.ToArray());
                    }
                }
            }

            return response;
        }

        /// <summary>
        /// Serializes the object into xml string.
        /// </summary>
        /// <param name="theObject"></param>
        /// <param name="xmlSerializerNameSpace"></param>
        /// <returns></returns>
        private static string SerializeObject(object theObject, XmlSerializerNamespaces xmlSerializerNameSpace)
        {
            XmlSerializer OfficeActivationXmlSerializer;
            StreamWriter OfficeActivationXmlStreamWriter;
            StreamReader OfficeActivationXmlStreamReader;
            string returnXml;
            OfficeActivationXmlSerializer = new XmlSerializer(theObject.GetType());
            OfficeActivationXmlStreamWriter = new StreamWriter(new MemoryStream());
            OfficeActivationXmlSerializer.Serialize(OfficeActivationXmlStreamWriter, theObject, xmlSerializerNameSpace);
            OfficeActivationXmlStreamReader = new StreamReader(OfficeActivationXmlStreamWriter.BaseStream);
            OfficeActivationXmlStreamReader.BaseStream.Seek(0, SeekOrigin.Begin);
            returnXml = OfficeActivationXmlStreamReader.ReadToEnd();
            return returnXml.Replace("'", "''");
        }
    }
}
