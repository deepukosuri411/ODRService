﻿using OrderStatusService.Core.Constants;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Infrastructure.Utility
{
    [ExcludeFromCodeCoverage]
    public static class MessageUtility
    {
        public static string ConstructMiddlewareMessage(string message)
        {
            return $"Exception : {message}";
        }

        public static string ConstructVmMessage(string traceId, string message)
        {
            return $"{GlobalConstants.TraceId}: {traceId} | {message}";
        }
    }
}
