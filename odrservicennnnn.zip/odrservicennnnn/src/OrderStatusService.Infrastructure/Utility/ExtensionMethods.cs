﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OrderStatusService.Core.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;

namespace OrderStatusService.Infrastructure.Utility
{
    [ExcludeFromCodeCoverage]
    public static class ExtensionMethods
    {
        /// <summary>
        /// Extention method that converts a list of values (primitive data-type) to comma separated values(primitive data-type).
        /// </summary>
        /// <param name="listEntity"></param>
        /// <returns>Returns a comma separated separated values(primitive data-type)</returns>
        public static string ToCommaSeparated<T>(this List<T> listEntity) where T : IConvertible
        {
            if (listEntity != null && listEntity.Any())
                return string.Join(", ", listEntity);
            else
                return string.Empty;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputData"></param>
        /// <param name="keyName"></param>
        /// <returns></returns>
        public static string GetAttributeValueFromInput(this InputRequest inputData, string keyName)
        {
            var attributeValues = inputData.Attributes.Where(attr => attr.Name.ToUpper() == keyName.ToUpper()).Select(attr => attr.Value).SingleOrDefault();
            return attributeValues;
        }

        public static string ToNullIfEmpty(this string input)
        {
            if (input != null)
            {
                if (input.Trim().Equals(string.Empty))
                    return null;
                else
                    return input;
            }
            return null;
        }

        /// <summary>
        /// Checks if the supplied list is null
        /// </summary>
        /// <param name="keyName"></param>
        /// <returns></returns>
        public static IList<T> EnsureNotNull<T>(this IList<T> list)
        {
            return list ?? new List<T>();
        }

        /// <summary>
        /// Extention method that converts a list of string to a pipe separated string.
        /// </summary>
        /// <param name="listStr"></param>
        /// <returns>Returns a pipe separated string</returns>
        public static string ToPipeSeparatedString(this IEnumerable<string> listStr)
        {
            if (listStr != null && listStr.Any())
                return string.Join("| ", listStr);
            else
                return string.Empty;
        }

        public static string ToPipeSeparatedString(this ModelErrorCollection modelErrorCollection)
        {
            StringBuilder errorMessage = new StringBuilder();
            if (modelErrorCollection != null && modelErrorCollection.Any())
            {
                int length = modelErrorCollection.Count();
                int index = 0;
                foreach (var modelError in modelErrorCollection)
                {
                    index++;
                    errorMessage.Append(modelError);
                    if (index < length)
                        errorMessage.Append(" | ");
                }
                return errorMessage.ToString();
            }
            else
                return string.Empty;
        }

        /// <summary>
        /// Converts the object into JSON string and beautifies it. 
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="isFormatted"></param>
        /// <returns></returns>
        public static string ToJson(this object obj, bool isFormatted = false)
        {
            string unFormattedJson = JsonConvert.SerializeObject(obj);
            if (isFormatted)
            {
                dynamic parsedJson = JsonConvert.DeserializeObject(unFormattedJson);
                return JsonConvert.SerializeObject(parsedJson, Formatting.Indented);
            }

            return unFormattedJson;
        }

        public static TEnumeration ToEnum<TEnumeration>(this string enumValueAsString, TEnumeration defaultEnumValue)
        {
            if (!Enum.IsDefined(typeof(TEnumeration), enumValueAsString))
                return defaultEnumValue;

            return (TEnumeration)Enum.Parse(typeof(TEnumeration), enumValueAsString);
        }

        /// <summary>
        /// Converts a string having boolean string to Y or N.
        /// </summary>
        /// <param name="strArr"></param>
        /// <param name="textToCheck"></param>
        /// <returns>Returns a value Y or N.</returns>
        public static string ToYorN(this string input)
        {
            if (!string.IsNullOrEmpty(input))
                return (input.ToUpper().Equals("TRUE") ? "Y" : "N");
            else
                return "N";
        }

        /// <summary>
        /// Checks whether a list of object is not null and its count is more than zero.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="inputObj"></param>
        /// <returns></returns>
        public static bool IsNotNullAndNotEmpty<T>(this List<T> inputObj)
        {
            return inputObj != null && inputObj.Any();
        }

        /// <summary>
        /// Converts a list of string to a string separated by a specified separater.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="inputObj"></param>
        /// <returns></returns>
        public static string ToString(this List<string> inputObj, char separater)
        {
            StringBuilder outputString = new StringBuilder();
            if (inputObj != null && inputObj.Any())
            {
                inputObj.ToList().ForEach(obj =>
                {
                    outputString.Append(obj.ToString()).Append(separater.ToString());
                });
            }

            return outputString.ToString();
        }

        /// <summary>
        /// Checks whether an array of object is not null and its count is more than zero.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="inputObj"></param>
        /// <returns></returns>
        public static bool IsNotNullAndNotEmpty<T>(this T[] inputObj)
        {
            return inputObj != null && inputObj.Any();
        }

        /// <summary>
        /// Parses string to int.
        /// </summary>
        /// <param name="config"></param>
        /// <param name="defaultVal"></param>
        /// <returns></returns>
        public static int TryParseToInt(this string config, int defaultVal)
        {
            return int.TryParse(config, out var tempRetry) ? int.Parse(config) : defaultVal;
        }

        /// <summary>
        /// Gets the value of CredHub data using the respective keyname.
        /// </summary>
        /// <param name="keyName"></param>
        /// <returns></returns>
        public static string GetCredHubData(this string keyName)
        {
            if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == null && Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") != "Development")
            {
                JObject myCredHubSecrets = JObject.Parse(Environment.GetEnvironmentVariable("VCAP_SERVICES"));
                return myCredHubSecrets["credhub"][0]["credentials"][keyName].ToString();
            }
            else
                return Environment.GetEnvironmentVariable(keyName);
        }

        public static string ToSlashSeparated<T>(this List<T> listEntity) where T : IConvertible
        {
            if (listEntity != null && listEntity.Any())
                return string.Join("/", listEntity);
            else
                return string.Empty;
        }
    }
}
