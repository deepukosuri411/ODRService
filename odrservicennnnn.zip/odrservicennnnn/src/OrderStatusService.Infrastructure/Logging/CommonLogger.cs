﻿using LogIt;
using OrderStatusService.Core.Interfaces.Logging;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;

namespace OrderStatusService.Infrastructure.Logging
{
    [ExcludeFromCodeCoverage]

    public class CommonLogger : ICommonLogger
    {
        private ICustomLogger logger { get; set; }

        public CommonLogger(ICustomLogger logger)
        {
            this.logger = logger;
        }

        public void Input(string traceId, string methodName, string entityType, string entityValue, params object[] list)
        {
            logger.Input(traceId, methodName, entityType, entityValue, list);
        }

        public void Info(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "")
        {
            logger.Info(traceId, $"{type.GetType()}.{callerFunction}", entityType, entityValue, logText);
        }

        public void Debug(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "")
        {
            logger.Debug(traceId, $"{type.GetType()}.{callerFunction}", entityType, entityValue, logText);
        }

        public void Error(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "")
        {
            logger.Error(traceId, $"{type.GetType()}.{callerFunction}", entityType, entityValue, logText);
        }

        public void Error(object type, string traceId, string logText, [CallerMemberName] string callerFunction = "")
        {
            logger.Error(traceId, $"{type.GetType()}.{callerFunction}", logText);
        }

        public void Fatal(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "")
        {
            logger.Fatal(traceId, $"{type.GetType()}.{callerFunction}", entityType, entityValue, logText);
        }

        public void Warning(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "")
        {
            logger.Warning(traceId, $"{type.GetType()}.{callerFunction}", entityType, entityValue, logText);
        }

        public void Output(string traceId, string methodName, string entityType, string entityValue, params object[] list)
        {
            logger.Output(traceId, methodName, entityType, entityValue, list);
        }
    }
}
