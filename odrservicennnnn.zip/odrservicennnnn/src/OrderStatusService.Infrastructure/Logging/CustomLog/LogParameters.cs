﻿using System;

namespace OrderStatusService.Infrastructure.Logging.CustomLog
{
    public class LogParameters
    {

        public string ProcessID;
        public string ServiceGroup;
        public string ServiceName;
        public string InstanceVersion;
        public string Region;
        public string Source;
        public string MessageID;
        public DateTime SourceCreateDateTime;
        public string MachineName;
        public DateTime? ProcessStartDateTime;
        public string InputParameters;
        public string InputData;
        public string LogMessage; // comments
        public LogLevel LogLevel;
        public MessageType MessageType;
        public DateTime? ProcessEndDateTime;
        public ProcessStatus ProcessStatus;
        public TransactionType Type;

        /// <summary>
        /// Method to fill log parameters. This LogParameter object can be passed along to different layers via context.
        /// </summary>
        /// <param name="processId">process ID</param>
        /// <param name="serviceName">Service name</param>
        /// <param name="methodName">Method name</param>
        /// <param name="instanceVersion">Version of the service</param>
        /// <param name="region">Region of operation.</param>
        /// <param name="source">Source application name.</param>
        /// <param name="messageId">Message ID</param>
        /// <param name="inputData">Payload object</param>
        /// <param name="inputParameters">Key value pair.</param>
        /// <returns></returns>
        public LogParameters FillLogParameters(string processId, string serviceName,
                                             string methodName, string instanceVersion,
                                             string region, string source, string messageId,
                                             string inputData, string inputParameters)
        {
            LogParameters _logParameters = new LogParameters();
            _logParameters.ProcessID = processId;
            _logParameters.ServiceGroup = serviceName;
            _logParameters.ServiceName = methodName;
            _logParameters.InstanceVersion = instanceVersion;
            _logParameters.Region = region;

            if (!string.IsNullOrEmpty(source))
            {
                if (source.Length > 5)
                {
                    source = source.Substring(0, 3);
                }
                _logParameters.Source = source;
            }
            else
                _logParameters.Source = "NULL";

            _logParameters.MessageID = messageId;
            _logParameters.MachineName = Environment.MachineName;
            _logParameters.InputData = inputData;
            _logParameters.InputParameters = inputParameters;


            return _logParameters;
        }
        //TBD write an overloaded method to set all the properties.

    }

    public enum TransactionType
    {

        I, // Initialization
        F, //Final 
        T //Transaction
    }

    public enum ProcessStatus
    {
        S,//Success
        F//Failure
    }

    public enum MessageType
    {
        IN,
        LOG,
        OUT

    }

    //public enum Region
    //{
    //    D,
    //    E,
    //    A
    //}

    public enum LogLevel
    {
        INFO,
        ERROR,
        EVENT,
        TRACE
    }
}
