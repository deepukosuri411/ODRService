﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.Global.Configs;
using OrderStatusService.Core.Interfaces.Logging;
using OrderStatusService.Core.Interfaces.Repository;
using OrderStatusService.Core.Interfaces.Utility;
using OrderStatusService.Core.Model;
using OrderStatusService.Core.ViewModel;
using OrderStatusService.Infrastructure.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;

namespace OrderStatusService.Infrastructure.Repository
{
    public class PdslRepository : IPdslRepository
    {
        #region Private Methods
        private IOptionsSnapshot<GlobalConfigs> _configServerData { get; }
        private ICommonLogger _logger { get; set; }
        private IHttpMethodUtility _httpMethodUtility { get; set; }
        #endregion

        public PdslRepository(IOptionsSnapshot<GlobalConfigs> configServerData, ICommonLogger logger, IHttpMethodUtility httpMethodUtility)
        {
            _configServerData = configServerData;
            _logger = logger;
            _httpMethodUtility = httpMethodUtility;
        }

        #region Public Methods

        /// <summary>
        /// Gets the item bom list details from PDSL client
        /// </summary>
        /// <param name="skuList"></param>
        /// <param name="regionCode"></param>
        /// <param name="bcrType"></param>
        /// <returns></returns>
        public async Task<ItemBomList> GetItemBomList(OrderStatusInputViewModel orderStatusInputViewModel, List<string> skuList, string regionCode, string bcrType)
        {
            ItemBomList itemBomList = new ItemBomList();
            string requestUri = _configServerData?.Value?.BusinessSettings.RequestUriGetItemBomList;
            string requestUrl = requestUri + "?level=-1&bcrType=" + bcrType + "&regionCode=" + regionCode + "&filtering=" + 1 + "&bypassCache=false&languageID=1";
            string jwtToken = _configServerData?.Value?.BusinessSettings.PdslJwtTokenGetItemBomList;

            try
            {
                JArray partList = new JArray();
                foreach (var productType in skuList)
                {
                    partList.Add(productType);
                }
                var content = JsonConvert.SerializeObject(partList);

                string authKey = $"{HttpAuthorization.Bearer} {jwtToken}";
                Dictionary<string, string> customHeaders = new Dictionary<string, string>() {
                                        { GlobalConstants.HttpHeaderAuthKey, authKey}
                                    };

                var httpResponseMessage = await _httpMethodUtility.HttpPostAsync(requestUrl, content, customHeaders);
                if (httpResponseMessage.IsSuccessStatusCode)
                {
                    var httpData = httpResponseMessage.Content.ReadAsStringAsync().Result;
                    itemBomList = JsonConvert.DeserializeObject<ItemBomList>(httpData);
                }
            }
            catch (Exception exc)
            {
                string errorMessage = $"Exception occured while triggering PdslRequestUrl. | Exception Message: {exc.Message} | StackTrace: {exc.StackTrace}";
                _logger.Error(this, orderStatusInputViewModel.TraceId, orderStatusInputViewModel.EntityType, orderStatusInputViewModel.EntityValue, errorMessage);
            }

            return itemBomList;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// This method is responsible to validate PDSL response.
        /// TRUE: Valid Response | FALSE: Invalid Response
        /// </summary>
        /// <param name="itemBomList"></param>
        /// <returns></returns>
        public bool IsPDSLResponseValid(ItemBomList itemBomList)
        {
            bool isPdslResponseValid = true;
            if (itemBomList == null && itemBomList.Itembom.Count() == 0)
            {
                //_logger.Warning(this, "No BOM information is available for the given SKUs from PDSL Service", DateTime.Now);
                isPdslResponseValid = false;
            }
            string xmlOrderBomDetails = XmlHelper.Serialize<ItemBomList>(itemBomList);
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlOrderBomDetails);
            XmlNodeList xmlNodeList = xmlDoc.GetElementsByTagName("ITEMBOM_ERROR");
            if (xmlNodeList != null && xmlNodeList.Count > 0)
            {
                xmlNodeList = xmlDoc.GetElementsByTagName("ERROR_REASON");
                string errorReason = xmlNodeList[0].InnerText;
                xmlNodeList = xmlDoc.GetElementsByTagName("COMP_ITEM");
                string compItem = xmlNodeList[0].InnerText;
                string errorMsg = "PDSL Service returned an ITEMBOM Error: " + errorReason + " for this COMP_ITEM: " + compItem;
                //_ctx.ODRElement.IsErrorOccurred = true;
                //_ctx.ODRElement.ErrorMessage = errorMsg;
                //log.Error(_ctx.CustomLogParams, string.Format("Error Occurred in IsPDSLResponseValid() of OrderDataRequestHandler.cs for order {0}. The Synchro Message is as follows {1}. Error message is {2}", _ctx.ODRElement.OrderCount.Equals(1) ? _ctx.ODRElement.OrderList.FirstOrDefault() : string.Empty, _ctx.InMsg.InMessage, errorMsg), errorMsg);
                isPdslResponseValid = false;
            }
            return isPdslResponseValid;
        }
        #endregion
    }
}
