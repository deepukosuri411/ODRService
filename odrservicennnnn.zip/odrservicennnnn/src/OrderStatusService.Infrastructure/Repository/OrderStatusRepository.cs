﻿using Fsl.Utilities.Network.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.Global.Configs;
using OrderStatusService.Core.Interfaces.Logging;
using OrderStatusService.Core.Interfaces.Repository;
using OrderStatusService.Core.Model;
using OrderStatusService.Core.Model.SpSchemaDeclarations.Udt;
using OrderStatusService.Core.SpSchemaDeclarations;
using OrderStatusService.Core.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace OrderStatusService.Infrastructure.Repository
{
    [ExcludeFromCodeCoverage]
    public class OrderStatusRepository : IOrderStatusRepository
    {
        #region Private Properties

        readonly BrhSyncroMsg_Tbl Order = new BrhSyncroMsg_Tbl();
        readonly FGA_ITEM_BOM_TBL itemBomLibrary = new FGA_ITEM_BOM_TBL();
        public FSLContext ctx;
        private readonly ILogger<IOrderStatusRepository> _logger;

        private IOptionsSnapshot<GlobalConfigs> _configServerData { get; set; }
        #endregion

        #region Constructor
        public OrderStatusRepository(IOptionsSnapshot<GlobalConfigs> configServerData, ICommonLogger logger)
        {
            _configServerData = configServerData;
        }
        #endregion
        #region OrderStatus
        public async Task<OrderStatusProcResponse> PersistOrderStatusEntityAsync(OrderStatusInputViewModel orderStatusInputViewModel, OdrPayload odrPayload, string region, string traceId, bool isTest)
        {
            string Output = null;
            OracleExecution oracleExecution;

            if (orderStatusInputViewModel.OrderType == "DELL_SEED_ORDER" && orderStatusInputViewModel.SenderId == "SYNCHRO")
            {
                oracleExecution = await GetOracleExecution(OracleCommandKey.PERSISTORDERDATAFGASEED.ToString());
            }
            else
            {
                oracleExecution = await GetOracleExecution(OracleCommandKey.PERSISTORDERDATA.ToString());
            }
            OracleSettings oracleSettings = _configServerData?.Value?.OracleSettings;
            if (oracleSettings != null && oracleSettings.ConnKeyListSchemaNameNotNeeded != null && oracleSettings.ConnKeyListSchemaNameNotNeeded.Contains(region))
            {
                string oracleExec = JsonConvert.SerializeObject(oracleExecution);
                oracleExec = oracleExec.Replace($"{oracleExecution.SchemaName}.", string.Empty);
                oracleExecution = JsonConvert.DeserializeObject<OracleExecution>(oracleExec);
            }
            oracleExecution.ConnectionKey = region;

            var oracleWrapperReq = new OracleBaseServiceOrderValidation()
            {
                OdrPayload = odrPayload,
                OracleExecution = oracleExecution
            };

            OracleBaseApiSettings oracleBaseApiSettings = _configServerData?.Value?.OracleBaseApiSettings;
            //var requestUri = $"{oracleBaseApiSettings?.OracleBaseApiUrl}{oracleBaseApiSettings?.OrderStatusServiceRoute}";
            var requestUri = "http://localhost:44360/ODR/ODRService";

            var customHeader = new Dictionary<string, string>() {
                    { GlobalConstants.TraceIdHeaderName, traceId}
                };

            //FGA_ITEM_BOM_T[] fGA_ITEM_BOM_Ts = new FGA_ITEM_BOM_T[oracleWrapperReq.OdrPayload.ItemBom.Value.Length];
            //fGA_ITEM_BOM_Ts = oracleWrapperReq.OdrPayload.ItemBom.Value;

            //int maxLength = 50;
            //oracleWrapperReq.OdrPayload.ItemBom.Value = new FGA_ITEM_BOM_T[maxLength];
            //for (int i = 0; i< maxLength; i++)
            //{
            //    oracleWrapperReq.OdrPayload.ItemBom.Value[i] = fGA_ITEM_BOM_Ts[i];
            //}

            //string payload = JsonConvert.SerializeObject(oracleWrapperReq);
            var baseServiceResponse = await GetBaseServiceDataAsync(oracleWrapperReq, requestUri, customHeader, TimeSpan.FromMinutes(10));
            if (baseServiceResponse.IsSuccessStatusCode)
            {
                string result = baseServiceResponse.Content.ReadAsStringAsync().Result;
                if (!string.IsNullOrEmpty(result))
                    Output = JsonConvert.DeserializeObject<string>(result);
            }
            OrderStatusProcResponse orderStatusProcResponse = new OrderStatusProcResponse();
            return orderStatusProcResponse;
        }
        //public async Task<OrderStatusProcResponse> PersistOrderStatusErrorEntityAsync(string errorMessage, string orderNumber)
        //{
        //    string AppErrorMessage = string.IsNullOrEmpty(errorMessage) ? ctx.ODRElement.ErrorMessage : errorMessage;
        //    string AIorderNumber = string.IsNullOrEmpty(orderNumber) ? ctx.ODRElement.OrderList.FirstOrDefault() : orderNumber;
        //    IDbConnection conn = null;
        //    OracleExecution oracleExecution = await GetOracleExecution(OracleCommandKey.PERSISTODRERRORLOG.ToString());
        //    OrderStatusProcResponse orderStatusProcResponse = new OrderStatusProcResponse();
        //    return orderStatusProcResponse;
        //}


        private async Task<OracleExecution> GetOracleExecution(string commandKey)
        {
            OracleExecution oracleExecution = new OracleExecution();
            List<OracleExecution> oracleExecutionList = _configServerData?.Value?.OracleSettings?.OracleExecution;
            await Task.Run(() =>
            {
                oracleExecution = (from oracleExecution in oracleExecutionList
                                   where Equals(oracleExecution?.OracleCommandKey, commandKey)
                                   select oracleExecution)?.ToList()?.FirstOrDefault();
            });

            return oracleExecution;
        }
        private async Task<HttpResponseMessage> GetBaseServiceDataAsync<T>(T objViewModel, string requestUrl, Dictionary<string, string> customHeaders, TimeSpan timeOut)
        {
            HttpResponseMessage httpResponse = await HttpRequestFactory.PostWithCustomHeaderAndTimeOut(requestUrl, objViewModel, customHeaders, timeOut);
            return httpResponse;
        }

        #endregion

        #region common
        #endregion




    }
}
