﻿using Microsoft.Extensions.Options;
using OrderStatusService.Core.Common.Util;
using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.ExceptionModel.CustomException;
using OrderStatusService.Core.Global.Configs;
using OrderStatusService.Core.Interfaces.Logging;
using OrderStatusService.Core.Interfaces.Repository;
using OrderStatusService.Core.Model;
using OrderStatusService.Core.Model.SpSchemaDeclarations.Udt;
using OrderStatusService.Core.ViewModel;
using OrderStatusService.Infrastructure.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderStatusService.Infrastructure.Repository
{
    public class SyncroMessageRepository : ISyncroMessageRepository
    {
        #region Private Methods
        private IOptionsSnapshot<GlobalConfigs> _configServerData { get; }
        public IOrderStatusRepository _repository { get; set; }
        private ICommonLogger _logger { get; set; }
        private IPdslRepository _pdslRepository { get; set; }
        #endregion

        #region Constructor
        public SyncroMessageRepository(IOptionsSnapshot<GlobalConfigs> configServerData, IOrderStatusRepository repository, ICommonLogger logger, IPdslRepository pdslRepository)
        {
            _configServerData = configServerData;
            _repository = repository;
            _logger = logger;
            _pdslRepository = pdslRepository;
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Main method to start processing the syncro Messages
        /// </summary>
        /// <param name="orderStatusInputViewModel"></param>
        /// <param name="orderStatusOutputViewModel"></param>
        /// <returns></returns>
        public async Task<OrderStatusOutputViewModel> ProcessSyncroMessages(OrderStatusInputViewModel orderStatusInputViewModel, OrderStatusOutputViewModel orderStatusOutputViewModel, bool isTest)
        {
            StringBuilder sbSkuNum = new StringBuilder();
            ItemBomList itemBomList = new ItemBomList();

            /*Get the sky quantity*/
            var skuNumberListByOrder = OrderStatusServiceHelper.GetSkuNumListByOrder(orderStatusInputViewModel.RawRequestXml);

            /*Get order details*/
            var orderDetails = GetOrderDetails(orderStatusInputViewModel.RawRequestXml);

            /*Start the loop to process multiple orders*/
            foreach (var pair in skuNumberListByOrder)
            {
                string orderNum = pair.Key;
                List<FGA_ITEM_BOM_T> fgalItemBomList = new List<FGA_ITEM_BOM_T>();
                BrhSyncroMsg_Tbl Order = new BrhSyncroMsg_Tbl();

                //Fetching SKU details for this particular order from Syncro Message
                var synodr = orderDetails.Value.Where(odr => odr.ORDER_NUMBER == pair.Key);
                Order.Value = synodr.ToArray();

                pair.Value.ForEach(sku =>
                {
                    sbSkuNum = sbSkuNum.Append(sku + "|");
                });

                /*Check if PDSL call is required or not*/
                if (!OrderStatusServiceHelper.IsPdslCallRequired(orderStatusInputViewModel.OrderType, _configServerData?.Value?.BusinessSettings.OrderTypeKeys))
                {
                    FGA_ITEM_BOM_TBL itemBomLibrary = new FGA_ITEM_BOM_TBL()
                    {
                        Value = fgalItemBomList.ToArray()
                    };

                    OdrPayload odrPayload = new OdrPayload()
                    {
                        SyncroOrder = Order,
                        ItemBom = itemBomLibrary,
                        AI_Order_No = orderStatusInputViewModel.OrderList.FirstOrDefault(),
                        Sender_Id = orderStatusInputViewModel.SenderId,
                        CloB_XML = orderStatusInputViewModel.RawRequestXml,
                        Order_Type = orderStatusInputViewModel.OrderType,
                        Created_By = Environment.MachineName
                    };

                    await _repository.PersistOrderStatusEntityAsync(orderStatusInputViewModel, odrPayload, "DAO", orderStatusInputViewModel.TraceId, isTest);
                }
                else
                {
                    List<string> skuNumList = pair.Value;
                    itemBomList = await _pdslRepository.GetItemBomList(orderStatusInputViewModel, skuNumList, orderStatusInputViewModel.RegionCode, _configServerData?.Value?.BusinessSettings.BcrType);
                    await RetryProcessHandler(orderStatusInputViewModel, orderNum, itemBomList, Order, fgalItemBomList, skuNumList, isTest);
                }
            }

            return orderStatusOutputViewModel;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Gets the order details from the input data
        /// </summary>
        /// <param name="inputData"></param>
        /// <returns></returns>
        private BrhSyncroMsg_Tbl GetOrderDetails(string inputData)
        {
            DataMapper<BrhSyncroMsg_Tbl> odrMapper = new DataMapper<BrhSyncroMsg_Tbl>();
            BrhSyncroMsg_Tbl orderdetails = odrMapper.MapData(inputData, XslFileName.ODR_SYNCRO_V1);
            return orderdetails;
        }

        private async Task RetryProcessHandler(OrderStatusInputViewModel orderStatusInputViewModel, string OrderNum, ItemBomList ItemBomList, BrhSyncroMsg_Tbl Order, List<FGA_ITEM_BOM_T> fgalItemBomList, List<string> SkuNumList, bool isTest)
        {
            try
            {
                //Verifying PDSL Response
                bool isPDSLResponseValid = _pdslRepository.IsPDSLResponseValid(ItemBomList);
                if (isPDSLResponseValid)
                {
                    //logging PDSL Response into DB
                    //_ctx.CustomLogParams.InputData = XmlHelper.Serialize<ItemBomList>(ItemBomList);
                    //log.DebugIN(_ctx.CustomLogParams, "PDSL raw response received from PDSL Service");

                    //OrderNum = (string)Order.Value.First().ORDER_NUMBER;

                    //Framing PDSL response into UDT
                    ExtractItemBomDetails(ItemBomList, fgalItemBomList, OrderNum);
                    FGA_ITEM_BOM_TBL itemBomLibrary = new FGA_ITEM_BOM_TBL()
                    {
                        Value = fgalItemBomList.ToArray()
                    };

                    //Logging Syncro Order details into DB
                    //_ctx.CustomLogParams.InputData = XmlHelper.Serialize<BrhSyncroMsg_Tbl>(Order);
                    //log.DebugIN(_ctx.CustomLogParams, "SyncroOrder Persisting in DB");

                    //Logging UDT framed PDSL response into DB
                    //_ctx.CustomLogParams.InputData = XmlHelper.Serialize<FGA_ITEM_BOM_TBL>(itemBomLibrary);
                    //log.DebugIN(_ctx.CustomLogParams, "FGAItemBom Persisting in DB");

                    //log.InfoLOG(_ctx.CustomLogParams, "Calling DB procedure to Insert Order details");

                    //_ODRDAO.InsertOrderDetails(Order, itemBomLibrary);

                    OdrPayload odrPayload = new OdrPayload()
                    {
                        SyncroOrder = Order,
                        ItemBom = itemBomLibrary,
                        AI_Order_No = orderStatusInputViewModel.OrderList.FirstOrDefault(),
                        Sender_Id = orderStatusInputViewModel.SenderId,
                        CloB_XML = orderStatusInputViewModel.RawRequestXml,
                        Order_Type = orderStatusInputViewModel.OrderType,
                        Created_By = Environment.MachineName
                    };
                    await _repository.PersistOrderStatusEntityAsync(orderStatusInputViewModel, odrPayload, "DAO", orderStatusInputViewModel.TraceId, isTest);

                    //if (orderStatusInputViewModel.IsErrorOccurred)
                    //{
                    //    log.Error(_ctx.CustomLogParams, string.Format("Error ocurred while inserting Data into UDM for following Syncro Message {0}.", _ctx.InMsg.InMessage), orderStatusInputViewModel.ErrorMessage, string.IsNullOrEmpty(OrderNum) ? "AIDOMS OrderNum: " + string.Empty : "AIDOMS OrderNum: " + OrderNum);
                    //}

                    //setting the InputData Property with the original Syncro message to avoid verbose Flat file logging.
                    //_ctx.CustomLogParams.InputData = _ctx.InMsg.InMessage;
                }
                else
                {
                    //PDSL response is invalid. From here I need to throw an exception.
                    //log.InfoLOG(_ctx.CustomLogParams, "PDSL Service response invalid - IsRetryEnabled: " + orderStatusInputViewModel.IsRetryEnabled.ToString());
                    //Retry mechanism when PDSL response validation failed if configured YES
                    if (orderStatusInputViewModel.IsRetryEnabled &&
                        orderStatusInputViewModel.CurRetryCount < orderStatusInputViewModel.MaxRetryCount)
                    {
                        //log.InfoLOG(_ctx.CustomLogParams, "PDSL Service response invalid - current retry count: " + orderStatusInputViewModel.CurRetryCount);
                        orderStatusInputViewModel.CurRetryCount++;
                        ItemBomList = await GetItemBomList(orderStatusInputViewModel, SkuNumList);
                        await RetryProcessHandler(orderStatusInputViewModel, OrderNum, ItemBomList, Order, fgalItemBomList, SkuNumList, isTest);
                    }
                    else
                    {
                        //log.InfoLOG(_ctx.CustomLogParams, "PDSL Service returned error/empty response from RetryProcessHandler() in OrderDataRequestHandler.cs.");
                        //throw new NoDataFoundException(orderStatusInputViewModel.ErrorMessage);
                        //return;
                    }
                }
                //log.InfoLOG(_ctx.CustomLogParams, "Exited RetryProcessHandler() in OrderDataRequestHandler.cs");
            }
            catch (NoDataFoundException)
            {
                //log.Error(_ctx.CustomLogParams, string.Format("PDSL Service returned error/empty response from RetryProcessHandler() in OrderDataRequestHandler.cs for following Synchro Message {0}. Refer payload for Exception details {1}", _ctx.InMsg.InMessage, ex.Message), ex.StackTrace, string.IsNullOrEmpty(OrderNum) ? "AIDOMS OrderNum: " + string.Empty : "AIDOMS OrderNum: " + OrderNum);
                throw;
            }
            catch (Exception)
            {
                //log.Error(_ctx.CustomLogParams, string.Format("Error Occurred in Process() of OrderDataRequestHandler.cs for the following Synchro message {0}. Refer payload for Exception details {1}", _ctx.InMsg.InMessage, ex.Message), ex.StackTrace, string.IsNullOrEmpty(OrderNum) ? "AIDOMS OrderNum: " + string.Empty : "AIDOMS OrderNum: " + OrderNum);
                throw;
            }
        }

        /// <summary>
        /// This method frames PDSL response to the UDT
        /// </summary>
        /// <param name="ItemBomList"></param>
        /// <param name="itemBom"></param>
        /// <param name="fgaItemBomList"></param>
        private void ExtractItemBomDetails(ItemBomList ItemBomList, List<FGA_ITEM_BOM_T> fgaItemBomList, string OrderNum)
        {
            //log.InfoLOG(_ctx.CustomLogParams, "Entered ExtractItemBomDetails() in OrderDataRequestHandler.cs");

            foreach (ItemBom item in ItemBomList.Itembom)
            {
                ExtractItemBoms(item, fgaItemBomList, OrderNum);
            }

            //log.InfoLOG(_ctx.CustomLogParams, "Exited ExtractItemBomDetails() in OrderDataRequestHandler.cs");
        }

        /// <summary>
        /// Recursive function responsible to frame the FGA BOM UDT object
        /// </summary>
        /// <param name="itemBom"></param>
        /// <param name="fgaItemBomList"></param>
        /// <param name="OrderId"></param>
        private void ExtractItemBoms(ItemBom itemBom, List<FGA_ITEM_BOM_T> fgaItemBomList, string OrderNum)
        {
            FGA_ITEM_BOM_T fgaItemBom = new FGA_ITEM_BOM_T
            {
                ORDER_NUM = OrderNum,
                CCN = itemBom.CompItem,
                COMP_LEVEL = Convert.ToDecimal(itemBom.Level),
                PARENT_ITEM = itemBom.ParentItem,
                COMP_ITEM = itemBom.CompItem,
                COMP_QTY = itemBom.CompQty,
                LATE_REV = itemBom.LateRev,
                DMS_FLAG = itemBom.DmsFlag,
                ITEM_CLASS_CODE = itemBom.ItemClassCode,
                ITEM_SUB_CLASS_CODE = itemBom.ItemSubClassCode,
                MONITOR_CODE = itemBom.MonitorCode,
                LOB_CODE = itemBom.LobCode,
                ITEM_TYPE = itemBom.ItemType,
                ISSUE_CODE = itemBom.IssueCode,
                COMMODITY = itemBom.Commodity,
                BOX_CODE = itemBom.BoxCode,
                SUBSTITUTIONS_ALLOWED = itemBom.SubstitutionsAllowed,
                WEIGHT = Convert.ToDecimal(itemBom.Weight),
                IS_FGA_SKU = itemBom.IsFgaSku,
                LINE_SKU_REF = 0,
                IS_SYSTEM = itemBom.IsSystem
            };
            fgaItemBomList.Add(fgaItemBom);

            if (itemBom.ItembomItembom != null)
            {
                foreach (ItemBom childItemBom in itemBom.ItembomItembom)
                {
                    ExtractItemBoms(childItemBom, fgaItemBomList, OrderNum);
                }
            }
        }


        /// <summary>
        /// This method is an abstraction over PDSL service calling. Here we handle retry mechanism in case of any exception
        /// from PDSL service
        /// </summary>
        /// <param name="SkuNumList"></param>
        /// <returns></returns>
        public async Task<ItemBomList> GetItemBomList(OrderStatusInputViewModel orderStatusInputViewModel, List<string> SkuNumList)
        {
            //log.InfoLOG(_ctx.CustomLogParams, "Entered GetItemBomList() in OrderDataRequestHandler");
            //log.InfoLOG(_ctx.CustomLogParams, "Current PDSL Service invocation count: " + _ctx.InMsg.ODRElement.CurRetryCount);

            ItemBomList PDSLResponse = new ItemBomList();
            try
            {
                //Make a call to PDSL Webservice
                PDSLResponse = await GetItemBomListFromPDSL(orderStatusInputViewModel, SkuNumList);
                //log.InfoLOG(_ctx.CustomLogParams, "Exited GetItemBomList() in OrderDataRequestHandler.cs");
                return PDSLResponse;
            }
            catch (Exception)
            {
                //log.InfoLOG(_ctx.CustomLogParams, "Current PDSL Service invocation retry count: " + orderStatusInputViewModel.CurRetryCount);
                throw;
            }
        }

        /// <summary>
        /// This method actually calls the PDSL proxy and get the response
        /// </summary>
        /// <param name="SkuNumList"></param>
        /// <returns></returns>
        private async Task<ItemBomList> GetItemBomListFromPDSL(OrderStatusInputViewModel orderStatusInputViewModel, List<string> SkuNumList)
        {
            BusinessSettings businessSettings = _configServerData?.Value?.BusinessSettings;
            bool isPdslRetryEnalbed = businessSettings.IsPdslRetryEnabled;
            int pdslRetrySleepTime = businessSettings.PdslRetrySleepTime;
            int pdslMaxRetryCount = businessSettings.PdslMaxRetryCount;

            //Dell.FSL.DataService.PDSLClient PDSLClient = new Dell.FSL.DataService.PDSLClient(_ctx.InMsg.ODRElement.ServiceAddressUrl.ToString());
            ItemBomList PDSLResponse = new ItemBomList();
            try
            {
                //PDSLResponse = _PDSLClient.GetItemBomList(SkuNumList, orderStatusInputViewModel.RegionCode, orderStatusInputViewModel.BCRType);
                PDSLResponse = await _pdslRepository.GetItemBomList(orderStatusInputViewModel, SkuNumList, orderStatusInputViewModel.RegionCode, _configServerData?.Value?.BusinessSettings.BcrType);
                return PDSLResponse;
            }
            catch (Exception)
            {
                //log.InfoLOG(_ctx.CustomLogParams, "Current PDSL Service invocation retry count: " + orderStatusInputViewModel.CurRetryCount);
                if (isPdslRetryEnalbed && (orderStatusInputViewModel.CurPdslRetryCount < pdslMaxRetryCount))
                {
                    orderStatusInputViewModel.CurPdslRetryCount++;
                    //log.Error("Retrying to connect the PDSLService for the " + orderStatusInputViewModel.CurPdslRetryCount + " Time and sleeping for " + pdslRetrySleepTime + " Seconds");

                    //Thread.Sleep(pdslRetrySleepTime * 1000);
                    Task.Delay(pdslRetrySleepTime * 1000).Wait(); //5 Seconds
                    PDSLResponse = await GetItemBomListFromPDSL(orderStatusInputViewModel, SkuNumList);
                    return PDSLResponse;
                }
                else
                {
                    throw;
                }
            }
        }

        #endregion
    }
}
