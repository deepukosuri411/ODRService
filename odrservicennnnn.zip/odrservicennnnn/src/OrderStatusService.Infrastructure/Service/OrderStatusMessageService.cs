﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.Global.Configs;
using OrderStatusService.Core.Interfaces.Logging;
using OrderStatusService.Core.Interfaces.Repository;
using OrderStatusService.Core.Interfaces.Service;
using OrderStatusService.Core.ViewModel;
using OrderStatusService.Infrastructure.Helper;
using OrderStatusService.Infrastructure.Utility;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace OrderStatusService.Infrastructure.Service
{
    public class OrderStatusMessageService : IOrderStatusMessageService
    {
        #region Private Properties

        private IOptionsSnapshot<GlobalConfigs> _configServerData { get; }
        private IOrderStatusRepository _repository { get; set; }
        private ICommonLogger _logger { get; set; }
        private ISyncroMessageRepository _syncroMessageRepository { get; set; }

        readonly XmlHelper xmlHelper;

        #endregion

        #region Constructor
        public OrderStatusMessageService(ICommonLogger logger, IOptionsSnapshot<GlobalConfigs> configServerData, ISyncroMessageRepository syncroMessageRepository)
        {
            _logger = logger;
            xmlHelper = new XmlHelper();
            _configServerData = configServerData;
            _syncroMessageRepository = syncroMessageRepository;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Main Execution Method to run the service
        /// </summary>
        /// <param name="formFile"></param>
        /// <param name="isTest"></param>
        /// <returns></returns>
        public async Task<OrderStatusOutputViewModel> OrderStatusServiceAsync(IFormFile formFile, bool isTest)
        {
            /*Set the input and output view model*/
            OrderStatusInputViewModel orderStatusInputViewModel = new OrderStatusInputViewModel();
            OrderStatusOutputViewModel orderStatusOutputViewModel = new OrderStatusOutputViewModel();
            StringBuilder strborders = new StringBuilder();
            orderStatusInputViewModel.TraceId = Guid.NewGuid().ToString();

            
            /*Convert the formfile to xdoc and get the inner xml*/
            XmlDocument xmlDocument = XmlHelper.GetXmlDocument(formFile);
            string rawRequestXml = xmlDocument.InnerXml;

            InitializeContext(rawRequestXml, ref orderStatusInputViewModel);

            //Removing NameSpace
            rawRequestXml = xmlHelper.RemoveAllNS(rawRequestXml);

            //Getting Region Code
            string inboundOdrRegion = _configServerData?.Value?.BusinessSettings?.InboundOdrRegion;
            string regionCode = (string.IsNullOrWhiteSpace(inboundOdrRegion)) ? GlobalConstants.InboundOdrRegion : inboundOdrRegion;
            orderStatusInputViewModel.RegionCode = regionCode;
            orderStatusInputViewModel.Region = (Region)Enum.Parse(typeof(Region), regionCode.Substring(0, 1));

            var orderlist = OrderStatusServiceHelper.GetOrderIds(orderStatusInputViewModel.RawRequestXml);
            if (!orderlist.Any())
            {
                orderStatusInputViewModel.IsErrorOccurred = true;
                orderStatusInputViewModel.ErrorMessage = GlobalConstants.NoOrderFoundMessage;
                _logger.Warning(this, orderStatusInputViewModel.TraceId, GlobalConstants.XmlEntityType, orderStatusInputViewModel.RawRequestXml, GlobalConstants.NoOrderFoundMessage);
                return OrderStatusServiceHelper.SetOutputViewModel(orderStatusOutputViewModel, true, GlobalConstants.NoOrderFoundMessage);
            }

            //Framing OrderNumber List for logging
            orderlist.ForEach(ord =>
            {
                strborders = strborders.Append("AIDOMSORDERNUMBERS|" + ord + ";");
            });

            orderStatusInputViewModel.OrderList = orderlist;
            orderStatusInputViewModel.OrderCount = orderlist.Count();

            /*Validate Message Is Sent From which source*/
            if (OrderStatusServiceHelper.IsMessageFromDoms(orderStatusInputViewModel.RawRequestXml))
            {
                orderStatusInputViewModel.MessageType = MsgType.DomsMessage;
                orderStatusInputViewModel.IsPDSLCallRequired = false;
                orderStatusInputViewModel.SenderId = ValidSenderId.AIDOMS.ToString();
            }
            else
            {
                orderStatusInputViewModel.MessageType = MsgType.SyncroMessage;
            }

            /*Get the order type*/
            orderStatusInputViewModel.OrderType = OrderStatusServiceHelper.GetOrderType(orderStatusInputViewModel.RawRequestXml);

            /*Code to validate xml if it send by syncro*/
            if (!OrderStatusServiceHelper.IsXmlValidationNeededForSyncro(orderStatusInputViewModel, orderStatusInputViewModel.OrderType, _configServerData?.Value?.BusinessSettings.BypassValidationForOrderType))
            {
                /*Pending*/
                // ValidateIncomingMessage & PersistErrorMessages
            }

            /*Code to validate base flag is present in Synchro Message*/
            if (orderStatusInputViewModel.MessageType.Equals(MsgType.SyncroMessage))
            {
                if (!OrderStatusServiceHelper.IsValidSynchroRequest(orderStatusInputViewModel.RawRequestXml, _configServerData?.Value?.BusinessSettings.ValidBaseFlagKeys))
                {
                    _logger.Warning(this, orderStatusInputViewModel.TraceId, GlobalConstants.XmlEntityType, orderStatusInputViewModel.RawRequestXml, GlobalConstants.SyncoInValidBaseFlagMessage);
                    return OrderStatusServiceHelper.SetOutputViewModel(orderStatusOutputViewModel, true, GlobalConstants.SyncoInValidBaseFlagMessage);
                }
            }

            /*Call the syncro repro to take the processing further*/
            orderStatusOutputViewModel = await _syncroMessageRepository.ProcessSyncroMessages(orderStatusInputViewModel, orderStatusOutputViewModel, isTest);

            return orderStatusOutputViewModel;
        }

        private void InitializeContext(string rawRequestXml, ref OrderStatusInputViewModel orderStatusInputViewModel)
        {
            orderStatusInputViewModel.RawRequestXml = rawRequestXml;

            BusinessSettings businessSettings = _configServerData?.Value?.BusinessSettings;
            if(businessSettings != null)
            {
                orderStatusInputViewModel.ValidBaseFlagsForSynchro = businessSettings.ValidBaseFlagKeys;
                orderStatusInputViewModel.ValidOrderTypesForSynchro = businessSettings.OrderTypeKeys;
                orderStatusInputViewModel.OrderTypeToBypassXSDValidation = businessSettings.BypassValidationForOrderType;
            }
            
            orderStatusInputViewModel.IsPDSLCallRequired = true;
            orderStatusInputViewModel.IsErrorOccurred = false;
            orderStatusInputViewModel.ErrorMessage = string.Empty;
            orderStatusInputViewModel.TargetNamespace = "http://schemas.dell.com/dbi/fsl/OrderDataRequest";
        }
        #endregion
    }
}