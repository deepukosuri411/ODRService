﻿using OrderStatusService.Core.Constants;
using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace OrderStatusService.Infrastructure.Helper
{
    public class OrderStatusServiceHelper
    {
        /// <summary>
        /// Gets the list of order Ids from the input xml
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static List<string> GetOrderIds(string message)
        {
            XElement root = XElement.Parse(message);
            var orders = from XElement order in root.Elements(GlobalConstants.XmlPathForOrder)
                         select (string)order.Element(GlobalConstants.XmlPathForOrderNumber);

            return orders.ToList();
        }

        /// <summary>
        /// Checks if the incoming message is a Doms Message
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool IsMessageFromDoms(string message)
        {
            bool isDomsMessages = false;
            string senderId = string.Empty;
            XElement root = XElement.Parse(message);
            if (root.DescendantsAndSelf("Order").Elements("SenderId").Any())
            {
                senderId = root.DescendantsAndSelf("Order").Elements("SenderId").Select(r => r.Value).SingleOrDefault();
            }

            if (Convert.ToString(senderId).ToUpper().Equals(ValidSenderId.AIDOMS.ToString()))
            {
                isDomsMessages = true;
            }
            return isDomsMessages;
        }

        /// <summary>
        /// Gets the Order Type.
        /// </summary>
        /// <param name="inputData"></param>
        /// <param name="validOrderTypesForSyncro"></param>
        /// <param name="OrderType"></param>
        public static string GetOrderType(string inputData)
        {
            XElement root = XElement.Parse(inputData);
            string orderType = string.IsNullOrEmpty(root.DescendantsAndSelf("Order").Elements("OrderType").Select(r => r.Value).SingleOrDefault())
                                     ? string.Empty
                                     : root.DescendantsAndSelf("Order").Elements("OrderType").Select(r => r.Value).SingleOrDefault().ToUpper();

            return orderType;
        }

        /// <summary>
        /// Checks if Pdsl call is required or not
        /// </summary>
        /// <param name="ordertype"></param>
        /// <param name="validOrderTypesForSyncro"></param>
        /// <returns></returns>
        public static bool IsPdslCallRequired(string ordertype, string validOrderTypesForSyncro)
        {
            if (validOrderTypesForSyncro.Split('|').Contains(ordertype))  //PDSL call not required if ORDER_TYPE is either DELL_PRODUCTS|SPAREPARTS_WARRANTY|ARB_WTM
                return false;
            else
                return true;
        }

        /// <summary>
        /// Checks if XML validation is needed for the incoming message sent my Syncro.
        /// </summary>
        /// <param name="orderStatusInputViewModel"></param>
        /// <param name="orderType"></param>
        /// <param name="orderTypeToByPassValidation"></param>
        /// <returns></returns>
        public static bool IsXmlValidationNeededForSyncro(OrderStatusInputViewModel orderStatusInputViewModel, string orderType, string orderTypeToByPassValidation)
        {
            if (orderStatusInputViewModel.MessageType.Equals(MsgType.SyncroMessage) && orderType.Equals(orderTypeToByPassValidation))
                return true;
            else
                return false;
        }

        /// <summary>
        /// Checks if the incoming message send my syncro is having valid base flag information
        /// </summary>
        /// <param name="inputData"></param>
        /// <param name="validBaseFlagsForSyncro"></param>
        /// <returns></returns>
        public static bool IsValidSynchroRequest(string inputData, string validBaseFlagsForSyncro)
        {
            bool isValidSyncroRequest = false;
            XElement root = XElement.Parse(inputData);

            //Removing empty elements for the request xml
            root.Descendants().Where(e => string.IsNullOrEmpty(e.Value)).Remove();

            //Checking if number of SKU element and Number of BASEFLAG element is same or not. 
            //If not same then we have BaseFlag missing into the SKU.
            bool isBaseFlagPresentForAllSkus = root.DescendantsAndSelf("SKU").Count() == root.DescendantsAndSelf("SKU").Elements("BaseFlag").Count();

            //Checking if there exist a BaseFlag which doesn't consist of the valid BaseFlag list of Y|N|R
            var list = root.DescendantsAndSelf("SKU").Elements("BaseFlag").ToList()
                           .Where(bf => !validBaseFlagsForSyncro.Split('|').Contains(bf.Value));

            //If below AND condition returns true then valid Synchro request
            isValidSyncroRequest = isBaseFlagPresentForAllSkus && list.Count() == 0;

            return isValidSyncroRequest;
        }

        /// <summary>
        /// Retrieves SKU Numbers per order basis
        /// </summary>
        /// <param name="inputData"></param>
        /// <returns>Dictionary of ordernumber and SKUList</returns>
        public static Dictionary<string, List<string>> GetSkuNumListByOrder(string inputData)
        {
            Dictionary<string, List<string>> SkuNumListByOrder = new Dictionary<string, List<string>>();
            XElement root = XElement.Parse(inputData);

            var Orders = from XElement order in root.Elements("Order")
                         select order;

            foreach (XElement order in Orders)
            {
                string OrderNumber = string.Empty;
                List<string> SkuNumLIst = new List<string>();

                OrderNumber = (string)order.Element(GlobalConstants.XmlPathForOrderNumber);

                var Skus = from XElement Sku in order.Descendants("SKU")
                           select Sku;

                foreach (XElement Sku in Skus)
                {
                    SkuNumLIst.Add((string)Sku.Element(GlobalConstants.XmlPathForSkuNumber));
                }
                SkuNumListByOrder.Add(OrderNumber, SkuNumLIst);
            }

            return SkuNumListByOrder;
        }

        /// <summary>
        /// Sets and returns the output view model
        /// </summary>
        /// <param name="orderStatusOutputViewModel"></param>
        /// <param name="hasErrorOccured"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        public static OrderStatusOutputViewModel SetOutputViewModel(OrderStatusOutputViewModel orderStatusOutputViewModel, bool hasErrorOccured, string errorMessage)
        {
            orderStatusOutputViewModel.ErrorMessage = errorMessage;
            orderStatusOutputViewModel.HasErrorOccured = hasErrorOccured;
            return orderStatusOutputViewModel;
        }
    }
}
