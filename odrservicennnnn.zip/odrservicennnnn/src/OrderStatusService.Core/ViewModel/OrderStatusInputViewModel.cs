﻿using OrderStatusService.Core.Enumeration;
using System.Collections.Generic;

namespace OrderStatusService.Core.ViewModel
{
    public class OrderStatusInputViewModel
    {
        public string EntityType { get; set; }
        public string EntityValue { get; set; }
        public string TraceId { get; set; }
        public string RegionCode { get; set; }
        public Region Region { get; set; }
        public string RawRequestXml { get; set; }
        public bool IsMessageFromDoms { get; set; }
        public string SenderId { get; set; }
        public MsgType MessageType { get; set; }
        public string OrderType { get; set; }
        public string ValidBaseFlagsForSynchro { get; set; }
        public string ValidOrderTypesForSynchro { get; set; }
        public string OrderTypeToBypassXSDValidation { get; set; }
        public bool IsPDSLCallRequired { get; set; }
        public bool IsErrorOccurred { get; set; }
        public string ErrorMessage { get; set; }
        public string TargetNamespace { get; set; }
        public int OrderCount { get; set; }
        public List<string> OrderList { get; set; }
        public List<string> SkuNumList { get; set; }
        public Dictionary<string, List<string>> SkuNumListByOrder { get; set; }
        public Dictionary<string, List<SKU>> SkuObjListByOrder { get; set; }
        public int MaxRetryCount { get; set; }
        public int CurRetryCount { get; set; }
        public string BCRType { get; set; }
        public bool IsRetryEnabled { get; set; }
        public int CurPdslRetryCount { get; set; }
    }

    public class SKU
    {
        public string SKUNumber { get; set; }
        public string FGID { get; set; }
        public string BaseFlag { get; set; }
        public string SkuQty { get; set; }
        public string TieNumber { get; set; }
    }
}
