﻿using System.Collections.Concurrent;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.ViewModel
{
    [ExcludeFromCodeCoverage]
    public class OrderStatusOutputViewModel
    {
        public OrderStatusOutputViewModel()
        {
            HasErrorOccured = false;
            ErrorTrace = new ConcurrentBag<string>();
        }
        public dynamic ResultData { get; set; }
        public bool HasErrorOccured { get; set; }
        public string ErrorMessage { get; set; }
        public ConcurrentBag<string> ErrorTrace { get; set; }
        public string OtherInformation { get; set; }
    }
}
