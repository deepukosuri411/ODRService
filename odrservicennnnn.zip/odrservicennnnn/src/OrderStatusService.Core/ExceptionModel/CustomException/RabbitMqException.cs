﻿using System;
using System.Runtime.Serialization;

namespace OrderStatusService.Core.ExceptionModel.CustomException
{
    [Serializable]
    public class RabbitMqException : Exception
    {
        public RabbitMqException() : base() { }
        public RabbitMqException(string message) : base(message) { }
        public RabbitMqException(string message, Exception inner) : base(message, inner) { }

        // A constructor is needed for serialization when an
        // exception propagates from a remoting server to the client.
        protected RabbitMqException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
