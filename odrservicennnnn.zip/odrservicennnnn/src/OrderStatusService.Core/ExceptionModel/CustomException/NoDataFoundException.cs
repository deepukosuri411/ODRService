﻿using System;

namespace OrderStatusService.Core.ExceptionModel.CustomException
{

    public class NoDataFoundException : Exception
        {
            public string ErrorCode { get; set; }

            public NoDataFoundException(string errorCode, string errorDescription)
                : base(errorDescription)
            {
                ErrorCode = errorCode;
            }
            public NoDataFoundException() { }
            public NoDataFoundException(string message) : base(message) { }
            public NoDataFoundException(string message, Exception inner) : base(message, inner) { }
            protected NoDataFoundException(
              System.Runtime.Serialization.SerializationInfo info,
              System.Runtime.Serialization.StreamingContext context)
                : base(info, context) { }
        }
}
