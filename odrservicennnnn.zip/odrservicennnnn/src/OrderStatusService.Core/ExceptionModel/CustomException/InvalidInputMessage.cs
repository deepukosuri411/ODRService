﻿using System;

namespace OrderStatusService.Core.ExceptionModel.CustomException
{
    public class InvalidInputMessage : Exception
    {
        InvalidInputMessage(string message) : base(message)
        {

        }
    }
}
