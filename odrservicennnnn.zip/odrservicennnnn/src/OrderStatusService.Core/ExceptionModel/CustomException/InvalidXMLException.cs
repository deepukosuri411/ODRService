﻿using System;

namespace OrderStatusService.Core.ExceptionModel.CustomException
{
    public class InvalidXMLException:Exception
    {
        public InvalidXMLException(string message):base(message)
        {
          
        }
    }
}
