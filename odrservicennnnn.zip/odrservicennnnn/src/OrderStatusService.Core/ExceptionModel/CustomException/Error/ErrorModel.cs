﻿namespace OrderStatusService.Core.ExceptionModel.CustomException.Error
{
    public class ErrorModel
    {
        public string FieldName { get; set; }
        public string Message { get; set; }
    }
}
