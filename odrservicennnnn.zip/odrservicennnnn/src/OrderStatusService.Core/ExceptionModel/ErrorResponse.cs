﻿using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.ExceptionModel
{
    [ExcludeFromCodeCoverage]
    public class ErrorResponse
    {
        public string Message { get; set; }
        public int StatusCode { get; set; }
        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
