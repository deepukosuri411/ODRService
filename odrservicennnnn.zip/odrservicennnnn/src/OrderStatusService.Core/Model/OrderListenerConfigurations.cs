﻿using Fsl.Utilities.Models;
using LogIt;

namespace OrderStatusService.Core.Model
{
    public class OrderListenerConfigurations
    {

        public ConfigConstants ConfigConstants { get; set; }
        public LogConfigs LogConfigs { get; set; }
        ////public ConnectionStrings ConnectionStrings { get; set; }
        public OracleTlsConfigurations OracleTlsConfigurations { get; set; }
        public IbmMqConfigrations IbmMqConfigrations { get; set; }
        public IbmMqCertConfig IbmMqCertConfig { get; set; }
    }

    //public class ConnectionStrings
    //{
    //    public string Scdh { get; set; }
    //    public string Emea { get; set; }
    //}
    public class ConfigConstants
    {
        public string WeekEndLogicCheck { get; set; }
        public string IsRampupEnabled { get; set; }
        public string Retailorder { get; set; }
        public string DlyDatBufferAddition { get; set; }
        public string MaxRetries { get; set; }
        public string SleepTime { get; set; }
        public string IsLobCheck { get; set; }
        public string ShipFromLocation { get; set; }
    }

    public class IbmMqConfigrations
    {
        public string MqGolfToFsl { get; set; }
        public string MqFslToOfs { get; set; }
        public string MqHost { get; set; }
        public string MqChannel { get; set; }
        public int MqPort { get; set; }
        public string MqCiperSpecProperty { get; set; }
        public string MqCertStoreProperty { get; set; }
        public string MqQueueManager { get; set; }
        public int CharacterSetId { get; set; }
        public string Direction { get; set; }
        public string SenderId { get; set; }
        public string ReceiverId { get; set; }
    }
}


