﻿namespace OrderStatusService.Core.Model
{
    public class OrderValReqAckTbl
    {
        private OrderValReqAckT[] m_OrderValReqAckT;

        public OrderValReqAckTbl()
        {
        }


        public virtual OrderValReqAckT[] Value
        {
            get => m_OrderValReqAckT;
            set => m_OrderValReqAckT = value;
        }
    }
}
