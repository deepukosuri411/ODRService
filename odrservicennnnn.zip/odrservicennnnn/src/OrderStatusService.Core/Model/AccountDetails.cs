﻿namespace OrderStatusService.Core.Model
{
    public class AccountDetails
    {
        public string MessageID { get; set; }
        public string TransactionID { get; set; }
        public string FromFacility { get; set; }
        public string ToFacility { get; set; }
        public string FromStockroom { get; set; }
        public string ToStockroom { get; set; }
        public string FromMasterStockroom { get; set; }
        public string ToMasterStockroom { get; set; }
        public string FromCCN { get; set; }
        public string ToCCN { get; set; }
        public string ReasonCode { get; set; }
    }

    public class Reason
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }

    public class MessagerHeader
    {
        public string MessageID { get; set; }
        public string MessageTimeStamp { get; set; }
        public string SenderID { get; set; }
        public string ReceiverID { get; set; }
        public string MessageType { get; set; }
        public string CorrelationID { get; set; }

    }
}
