﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public  class FSLITPDeadLetterT
    {
        private bool m_IsNull;

        private string m_SRVC_KEY1_VALUE;

        private decimal m_ERROR_CODE;

        private bool m_ERROR_CODEIsNull;

        private string m_MESSAGE;

        private string m_SRVC_KEY1;

        private string m_MESSAGE_TYPE;

        private string m_ERROR_MESG;

        private decimal m_RETRY_COUNT;

        private bool m_RETRY_COUNTIsNull;

        public FSLITPDeadLetterT()
        {
            // TODO : Add code to initialise the object
            //this.m_ERROR_CODEIsNull = true;
            //this.m_RETRY_COUNTIsNull = true;
        }

        public FSLITPDeadLetterT(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPDeadLetterT Null
        {
            get
            {
                FSLITPDeadLetterT obj = new FSLITPDeadLetterT();
                obj.m_IsNull = true;
                return obj;
            }
        }

     
        public string SRVC_KEY1_VALUE
        {
            get
            {
                return this.m_SRVC_KEY1_VALUE;
            }
            set
            {
                this.m_SRVC_KEY1_VALUE = value;
            }
        }

        
        public decimal ERROR_CODE
        {
            get
            {
                return this.m_ERROR_CODE;
            }
            set
            {
                this.m_ERROR_CODE = value;
            }
        }

        public bool ERROR_CODEIsNull
        {
            get
            {
                return this.m_ERROR_CODEIsNull;
            }
            set
            {
                this.m_ERROR_CODEIsNull = value;
            }
        }

      
        public string MESSAGE
        {
            get
            {
                return this.m_MESSAGE;
            }
            set
            {
                this.m_MESSAGE = value;
            }
        }

       
        public string SRVC_KEY1
        {
            get
            {
                return this.m_SRVC_KEY1;
            }
            set
            {
                this.m_SRVC_KEY1 = value;
            }
        }

      
        public string MESSAGE_TYPE
        {
            get
            {
                return this.m_MESSAGE_TYPE;
            }
            set
            {
                this.m_MESSAGE_TYPE = value;
            }
        }

       
        public string ERROR_MESG
        {
            get
            {
                return this.m_ERROR_MESG;
            }
            set
            {
                this.m_ERROR_MESG = value;
            }
        }

      
        public decimal RETRY_COUNT
        {
            get
            {
                return this.m_RETRY_COUNT;
            }
            set
            {
                this.m_RETRY_COUNT = value;
            }
        }

        public bool RETRY_COUNTIsNull
        {
            get
            {
                return this.m_RETRY_COUNTIsNull;
            }
            set
            {
                this.m_RETRY_COUNTIsNull = value;
            }
        }
    }
}
