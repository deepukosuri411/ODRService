﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    class FSLITPEDOMSItemT
    {
        private bool m_IsNull;

        private string m_HASBASE;

        private string m_CLASSCODE;

        private string m_MFGPARTNUMBER;

        private decimal m_TIEQUANTITY;

        private bool m_TIEQUANTITYIsNull;

        private string m_SYSTEMFLAG;

        private decimal m_TIEWARRANTYCOST;

        private bool m_TIEWARRANTYCOSTIsNull;

        private decimal m_TIENUMBER;

        private bool m_TIENUMBERIsNull;

        private decimal m_TRANSFERPRICE;

        private bool m_TRANSFERPRICEIsNull;

        private string m_LOBCODE;

        private string m_PRODUCTTYPE;

        private decimal m_SKUQUANTITY;

        private bool m_SKUQUANTITYIsNull;

        private decimal m_WARRANTYCOST;

        private bool m_WARRANTYCOSTIsNull;

        public FSLITPEDOMSItemT()
        {
            // TODO : Add code to initialise the object
            this.m_TIEQUANTITYIsNull = true;
            this.m_TIEWARRANTYCOSTIsNull = true;
            this.m_TIENUMBERIsNull = true;
            this.m_TRANSFERPRICEIsNull = true;
            this.m_SKUQUANTITYIsNull = true;
            this.m_WARRANTYCOSTIsNull = true;
        }

        public FSLITPEDOMSItemT(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPEDOMSItemT Null
        {
            get
            {
                FSLITPEDOMSItemT obj = new FSLITPEDOMSItemT();
                obj.m_IsNull = true;
                return obj;
            }
        }

       
        public string HASBASE
        {
            get
            {
                return this.m_HASBASE;
            }
            set
            {
                this.m_HASBASE = value;
            }
        }

        public string CLASSCODE
        {
            get
            {
                return this.m_CLASSCODE;
            }
            set
            {
                this.m_CLASSCODE = value;
            }
        }

       
        public string MFGPARTNUMBER
        {
            get
            {
                return this.m_MFGPARTNUMBER;
            }
            set
            {
                this.m_MFGPARTNUMBER = value;
            }
        }

      
        public decimal TIEQUANTITY
        {
            get
            {
                return this.m_TIEQUANTITY;
            }
            set
            {
                this.m_TIEQUANTITY = value;
            }
        }

        public bool TIEQUANTITYIsNull
        {
            get
            {
                return this.m_TIEQUANTITYIsNull;
            }
            set
            {
                this.m_TIEQUANTITYIsNull = value;
            }
        }

       
        public string SYSTEMFLAG
        {
            get
            {
                return this.m_SYSTEMFLAG;
            }
            set
            {
                this.m_SYSTEMFLAG = value;
            }
        }

     
        public decimal TIEWARRANTYCOST
        {
            get
            {
                return this.m_TIEWARRANTYCOST;
            }
            set
            {
                this.m_TIEWARRANTYCOST = value;
            }
        }

        public bool TIEWARRANTYCOSTIsNull
        {
            get
            {
                return this.m_TIEWARRANTYCOSTIsNull;
            }
            set
            {
                this.m_TIEWARRANTYCOSTIsNull = value;
            }
        }

        public decimal TIENUMBER
        {
            get
            {
                return this.m_TIENUMBER;
            }
            set
            {
                this.m_TIENUMBER = value;
            }
        }

        public bool TIENUMBERIsNull
        {
            get
            {
                return this.m_TIENUMBERIsNull;
            }
            set
            {
                this.m_TIENUMBERIsNull = value;
            }
        }

        public decimal TRANSFERPRICE
        {
            get
            {
                return this.m_TRANSFERPRICE;
            }
            set
            {
                this.m_TRANSFERPRICE = value;
            }
        }

        public bool TRANSFERPRICEIsNull
        {
            get
            {
                return this.m_TRANSFERPRICEIsNull;
            }
            set
            {
                this.m_TRANSFERPRICEIsNull = value;
            }
        }

        public string LOBCODE
        {
            get
            {
                return this.m_LOBCODE;
            }
            set
            {
                this.m_LOBCODE = value;
            }
        }

        public string PRODUCTTYPE
        {
            get
            {
                return this.m_PRODUCTTYPE;
            }
            set
            {
                this.m_PRODUCTTYPE = value;
            }
        }

        public decimal SKUQUANTITY
        {
            get
            {
                return this.m_SKUQUANTITY;
            }
            set
            {
                this.m_SKUQUANTITY = value;
            }
        }

        public bool SKUQUANTITYIsNull
        {
            get
            {
                return this.m_SKUQUANTITYIsNull;
            }
            set
            {
                this.m_SKUQUANTITYIsNull = value;
            }
        }

        public decimal WARRANTYCOST
        {
            get
            {
                return this.m_WARRANTYCOST;
            }
            set
            {
                this.m_WARRANTYCOST = value;
            }
        }

        public bool WARRANTYCOSTIsNull
        {
            get
            {
                return this.m_WARRANTYCOSTIsNull;
            }
            set
            {
                this.m_WARRANTYCOSTIsNull = value;
            }
        }
    }
}
