﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPEDOMSItemTBL
    {
        private bool m_IsNull;

        private readonly FSLITPEDOMSItemT[] m_FSL_ITP_EDOMS_ITEM_TYP;

        public FSLITPEDOMSItemTBL()
        {
            // TODO : Add code to initialise the object
        }

        public FSLITPEDOMSItemTBL(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPEDOMSItemTBL Null
        {
            get
            {
                FSLITPEDOMSItemTBL obj = new FSLITPEDOMSItemTBL();
                obj.m_IsNull = true;
                return obj;
            }
        }

       

    }
}
