﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPAttributeTBL
    {
        private bool m_IsNull;

        private FSLITPAttributeT[] m_ITP_ATTR_T;

        public FSLITPAttributeTBL()
        {
            // TODO : Add code to initialise the object
        }

        public FSLITPAttributeTBL(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPAttributeTBL Null
        {
            get
            {
                FSLITPAttributeTBL obj = new FSLITPAttributeTBL();
                obj.m_IsNull = true;
                return obj;
            }
        }

      
        public virtual FSLITPAttributeT[] Value
        {
            get
            {
                return this.m_ITP_ATTR_T;
            }
            set
            {
                this.m_ITP_ATTR_T = value;
            }
        }
    }
}
