﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPTrialTBL
    {
        private bool m_IsNull;

        private FSLITPTrialT[] m_FSLITPTrialT;

        public FSLITPTrialTBL()
        {
            // TODO : Add code to initialise the object
        }

        public FSLITPTrialTBL(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPTrialTBL Null
        {
            get
            {
                FSLITPTrialTBL obj = new FSLITPTrialTBL();
                obj.m_IsNull = true;
                return obj;
            }
        }

      
        public virtual FSLITPTrialT[] Value
        {
            get
            {
                return this.m_FSLITPTrialT;
            }
            set
            {
                this.m_FSLITPTrialT = value;
            }
        }
    }
}
