﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPAttributeT
    {
        private bool m_IsNull;

        private string m_ATTRIBUTE_VALUE;

        private string m_ATTRIBUTE_NAME;

        public FSLITPAttributeT()
        {
            // TODO : Add code to initialise the object
        }

        public FSLITPAttributeT(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPAttributeT Null
        {
            get
            {
                FSLITPAttributeT obj = new FSLITPAttributeT();
                obj.m_IsNull = true;
                return obj;
            }
        }

      
        public string ATTRIBUTE_VALUE
        {
            get
            {
                return this.m_ATTRIBUTE_VALUE;
            }
            set
            {
                this.m_ATTRIBUTE_VALUE = value;
            }
        }

       
        public string ATTRIBUTE_NAME
        {
            get
            {
                return this.m_ATTRIBUTE_NAME;
            }
            set
            {
                this.m_ATTRIBUTE_NAME = value;
            }
        }
    }
}
