﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPEDOMSHeaderTBL 
    {
        private bool m_IsNull;

        private FSLITPEDOMSHeaderT[] m_FSL_ITP_EDOMS_HDR_TYP;

        public FSLITPEDOMSHeaderTBL()
        {
            // TODO : Add code to initialise the object
        }

        public FSLITPEDOMSHeaderTBL(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPEDOMSHeaderTBL Null
        {
            get
            {
                FSLITPEDOMSHeaderTBL obj = new FSLITPEDOMSHeaderTBL();
                obj.m_IsNull = true;
                return obj;
            }
        }

       
        public virtual FSLITPEDOMSHeaderT[] Value
        {
            get
            {
                return this.m_FSL_ITP_EDOMS_HDR_TYP;
            }
            set
            {
                this.m_FSL_ITP_EDOMS_HDR_TYP = value;
            }
        }
    }
}