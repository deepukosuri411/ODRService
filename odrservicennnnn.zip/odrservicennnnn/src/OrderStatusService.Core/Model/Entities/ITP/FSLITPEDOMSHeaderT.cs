﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPEDOMSHeaderT
    {
        private bool m_IsNull;

        private string m_SUBCHANNEL;

        private decimal m_BUID;

        private bool m_BUIDIsNull;

        private string m_SALESORDERNUM;

        private string m_QUOTATIONPREFIX;

        private string m_WORKORDERID;

        private string m_QUOTATIONNUMBER;

        private decimal m_TOTALPRICE;

        private bool m_TOTALPRICEIsNull;

        private string m_FACILITY;

        private string m_PONUMBER;

        private string m_CCN;

        private string m_MASTERLOCATION;

        private string m_CUSTOMERNUMBER;

        private decimal m_CORRELATIONID;

        private bool m_CORRELATIONIDIsNull;

        private string m_FULFILLMENTCHANNEL;

        public FSLITPEDOMSHeaderT()
        {
            // TODO : Add code to initialise the object
            this.m_BUIDIsNull = true;
            this.m_TOTALPRICEIsNull = true;
            this.m_CORRELATIONIDIsNull = true;
        }

        public FSLITPEDOMSHeaderT(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPEDOMSHeaderT Null
        {
            get
            {
                FSLITPEDOMSHeaderT obj = new FSLITPEDOMSHeaderT();
                obj.m_IsNull = true;
                return obj;
            }
        }

     
        public string SUBCHANNEL
        {
            get
            {
                return this.m_SUBCHANNEL;
            }
            set
            {
                this.m_SUBCHANNEL = value;
            }
        }

     
        public decimal BUID
        {
            get
            {
                return this.m_BUID;
            }
            set
            {
                this.m_BUID = value;
            }
        }

        public bool BUIDIsNull
        {
            get
            {
                return this.m_BUIDIsNull;
            }
            set
            {
                this.m_BUIDIsNull = value;
            }
        }

     
        public string SALESORDERNUM
        {
            get
            {
                return this.m_SALESORDERNUM;
            }
            set
            {
                this.m_SALESORDERNUM = value;
            }
        }

      
        public string QUOTATIONPREFIX
        {
            get
            {
                return this.m_QUOTATIONPREFIX;
            }
            set
            {
                this.m_QUOTATIONPREFIX = value;
            }
        }

    
        public string WORKORDERID
        {
            get
            {
                return this.m_WORKORDERID;
            }
            set
            {
                this.m_WORKORDERID = value;
            }
        }

       
        public string QUOTATIONNUMBER
        {
            get
            {
                return this.m_QUOTATIONNUMBER;
            }
            set
            {
                this.m_QUOTATIONNUMBER = value;
            }
        }

       
        public decimal TOTALPRICE
        {
            get
            {
                return this.m_TOTALPRICE;
            }
            set
            {
                this.m_TOTALPRICE = value;
            }
        }

        public bool TOTALPRICEIsNull
        {
            get
            {
                return this.m_TOTALPRICEIsNull;
            }
            set
            {
                this.m_TOTALPRICEIsNull = value;
            }
        }

       
        public string FACILITY
        {
            get
            {
                return this.m_FACILITY;
            }
            set
            {
                this.m_FACILITY = value;
            }
        }

       
        public string PONUMBER
        {
            get
            {
                return this.m_PONUMBER;
            }
            set
            {
                this.m_PONUMBER = value;
            }
        }

       
        public string CCN
        {
            get
            {
                return this.m_CCN;
            }
            set
            {
                this.m_CCN = value;
            }
        }


        public string MASTERLOCATION
        {
            get
            {
                return this.m_MASTERLOCATION;
            }
            set
            {
                this.m_MASTERLOCATION = value;
            }
        }

       
        public string CUSTOMERNUMBER
        {
            get
            {
                return this.m_CUSTOMERNUMBER;
            }
            set
            {
                this.m_CUSTOMERNUMBER = value;
            }
        }

       
        public decimal CORRELATIONID
        {
            get
            {
                return this.m_CORRELATIONID;
            }
            set
            {
                this.m_CORRELATIONID = value;
            }
        }

        public bool CORRELATIONIDIsNull
        {
            get
            {
                return this.m_CORRELATIONIDIsNull;
            }
            set
            {
                this.m_CORRELATIONIDIsNull = value;
            }
        }

       
        public string FULFILLMENTCHANNEL
        {
            get
            {
                return this.m_FULFILLMENTCHANNEL;
            }
            set
            {
                this.m_FULFILLMENTCHANNEL = value;
            }
        }

    }
}
