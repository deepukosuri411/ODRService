﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPDetailT
    {
        private bool m_IsNull;

        private decimal m_SALES_ORDER_REF;

        private bool m_SALES_ORDER_REFIsNull;

        private string m_ORG_MOD_NUM;

        private string m_MOD_NUM;

        private decimal m_DETAIL_SEQ_NUMBER;

        private bool m_DETAIL_SEQ_NUMBERIsNull;

        private decimal m_TRANSFER_PRICE;

        private bool m_TRANSFER_PRICEIsNull;

        private decimal m_SO_MOD_PRICE_REF;

        private bool m_SO_MOD_PRICE_REFIsNull;

        private decimal m_ITP_UNIT_PRICE;

        private bool m_ITP_UNIT_PRICEIsNull;

        private decimal m_QUANTITY;

        private bool m_QUANTITYIsNull;

        private string m_FGA_MOD;

        public FSLITPDetailT()
        {
            //// TODO : Add code to initialise the object
            //this.m_SALES_ORDER_REFIsNull = true;
            //this.m_DETAIL_SEQ_NUMBERIsNull = true;
            //this.m_TRANSFER_PRICEIsNull = true;
            //this.m_SO_MOD_PRICE_REFIsNull = true;
            //this.m_ITP_UNIT_PRICEIsNull = true;
            //this.m_QUANTITYIsNull = true;
        }

        public FSLITPDetailT(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPDetailT Null
        {
            get
            {
                FSLITPDetailT obj = new FSLITPDetailT();
                obj.m_IsNull = true;
                return obj;
            }
        }

        
        public decimal SALES_ORDER_REF
        {
            get
            {
                return this.m_SALES_ORDER_REF;
            }
            set
            {
                this.m_SALES_ORDER_REF = value;
            }
        }

        public bool SALES_ORDER_REFIsNull
        {
            get
            {
                return this.m_SALES_ORDER_REFIsNull;
            }
            set
            {
                this.m_SALES_ORDER_REFIsNull = value;
            }
        }

      
        public string ORG_MOD_NUM
        {
            get
            {
                return this.m_ORG_MOD_NUM;
            }
            set
            {
                this.m_ORG_MOD_NUM = value;
            }
        }

       
        public string MOD_NUM
        {
            get
            {
                return this.m_MOD_NUM;
            }
            set
            {
                this.m_MOD_NUM = value;
            }
        }

      
        public decimal DETAIL_SEQ_NUMBER
        {
            get
            {
                return this.m_DETAIL_SEQ_NUMBER;
            }
            set
            {
                this.m_DETAIL_SEQ_NUMBER = value;
            }
        }

        public bool DETAIL_SEQ_NUMBERIsNull
        {
            get
            {
                return this.m_DETAIL_SEQ_NUMBERIsNull;
            }
            set
            {
                this.m_DETAIL_SEQ_NUMBERIsNull = value;
            }
        }

        
        public decimal TRANSFER_PRICE
        {
            get
            {
                return this.m_TRANSFER_PRICE;
            }
            set
            {
                this.m_TRANSFER_PRICE = value;
            }
        }

        public bool TRANSFER_PRICEIsNull
        {
            get
            {
                return this.m_TRANSFER_PRICEIsNull;
            }
            set
            {
                this.m_TRANSFER_PRICEIsNull = value;
            }
        }

      
        public decimal SO_MOD_PRICE_REF
        {
            get
            {
                return this.m_SO_MOD_PRICE_REF;
            }
            set
            {
                this.m_SO_MOD_PRICE_REF = value;
            }
        }

        public bool SO_MOD_PRICE_REFIsNull
        {
            get
            {
                return this.m_SO_MOD_PRICE_REFIsNull;
            }
            set
            {
                this.m_SO_MOD_PRICE_REFIsNull = value;
            }
        }

       
        public decimal ITP_UNIT_PRICE
        {
            get
            {
                return this.m_ITP_UNIT_PRICE;
            }
            set
            {
                this.m_ITP_UNIT_PRICE = value;
            }
        }

        public bool ITP_UNIT_PRICEIsNull
        {
            get
            {
                return this.m_ITP_UNIT_PRICEIsNull;
            }
            set
            {
                this.m_ITP_UNIT_PRICEIsNull = value;
            }
        }

       
        public decimal QUANTITY
        {
            get
            {
                return this.m_QUANTITY;
            }
            set
            {
                this.m_QUANTITY = value;
            }
        }

        public bool QUANTITYIsNull
        {
            get
            {
                return this.m_QUANTITYIsNull;
            }
            set
            {
                this.m_QUANTITYIsNull = value;
            }
        }

       
        public string FGA_MOD
        {
            get
            {
                return this.m_FGA_MOD;
            }
            set
            {
                this.m_FGA_MOD = value;
            }
        }
    }
}
