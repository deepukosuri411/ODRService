﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPTrialT
    {

        private bool m_IsNull;

        private string m_ERROR_CODE;

        private string m_CORRELATION_ID;

        private string m_ATTRIBUTE1;

        private string m_ERROR_DESC;

        private string m_SRVC_KEY1;

        private string m_SRVC_KEY2;

        private string m_STATUS_CODE;

        private string m_SRVC_KEY2_VALUE;

        private string m_MSG_ID;

        private string m_TRANS_STATUS;

        private string m_SRVC_KEY1_VALUE;

        private string m_RESPONSE_MSG_ID;

        public FSLITPTrialT()
        {
            // TODO : Add code to initialise the object
        }

        public FSLITPTrialT(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPTrialT Null
        {
            get
            {
                FSLITPTrialT obj = new FSLITPTrialT();
                obj.m_IsNull = true;
                return obj;
            }
        }

        public string ERROR_CODE
        {
            get
            {
                return this.m_ERROR_CODE;
            }
            set
            {
                this.m_ERROR_CODE = value;
            }
        }

        public string CORRELATION_ID
        {
            get
            {
                return this.m_CORRELATION_ID;
            }
            set
            {
                this.m_CORRELATION_ID = value;
            }
        }

        public string ATTRIBUTE1
        {
            get
            {
                return this.m_ATTRIBUTE1;
            }
            set
            {
                this.m_ATTRIBUTE1 = value;
            }
        }

        public string ERROR_DESC
        {
            get
            {
                return this.m_ERROR_DESC;
            }
            set
            {
                this.m_ERROR_DESC = value;
            }
        }

        public string SRVC_KEY1
        {
            get
            {
                return this.m_SRVC_KEY1;
            }
            set
            {
                this.m_SRVC_KEY1 = value;
            }
        }

        public string SRVC_KEY2
        {
            get
            {
                return this.m_SRVC_KEY2;
            }
            set
            {
                this.m_SRVC_KEY2 = value;
            }
        }

        public string STATUS_CODE
        {
            get
            {
                return this.m_STATUS_CODE;
            }
            set
            {
                this.m_STATUS_CODE = value;
            }
        }

        public string SRVC_KEY2_VALUE
        {
            get
            {
                return this.m_SRVC_KEY2_VALUE;
            }
            set
            {
                this.m_SRVC_KEY2_VALUE = value;
            }
        }

        public string MSG_ID
        {
            get
            {
                return this.m_MSG_ID;
            }
            set
            {
                this.m_MSG_ID = value;
            }
        }

        public string TRANS_STATUS
        {
            get
            {
                return this.m_TRANS_STATUS;
            }
            set
            {
                this.m_TRANS_STATUS = value;
            }
        }

        public string SRVC_KEY1_VALUE
        {
            get
            {
                return this.m_SRVC_KEY1_VALUE;
            }
            set
            {
                this.m_SRVC_KEY1_VALUE = value;
            }
        }

        public string RESPONSE_MSG_ID
        {
            get
            {
                return this.m_RESPONSE_MSG_ID;
            }
            set
            {
                this.m_RESPONSE_MSG_ID = value;
            }
        }

    }
}
