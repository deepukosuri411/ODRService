﻿namespace OrderStatusService.Core.Model.Entities.ITP.HelperEntities
{
    public  class InterCompanyPriceResponseEntity
    {

        public FSL2LGSTriggerEntity fslLGSTriggerEntity { get; set; }

        public FSLITPHeaderTBL fslITPHeaderTbl { get; set; }

        public FSLITPDetailTBL fslITPDetailTbl { get; set; }

        public FSLITPTrialTBL fslITPTrialTbl { get; set; }

        public FSLITPAttributeTBL fslITPAttributeTbl { get; set; }
    }
}
