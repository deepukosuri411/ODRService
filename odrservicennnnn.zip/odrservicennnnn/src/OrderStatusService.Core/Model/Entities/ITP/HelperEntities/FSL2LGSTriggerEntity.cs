﻿namespace OrderStatusService.Core.Model.Entities.ITP.HelperEntities
{
    public class FSL2LGSTriggerEntity
    {
        public string Source { get; set; }
        public string MessageId { get; set; }
        public string MessageType { get; set; }
        public string Version { get; set; }
        public string CorrelationId { get; set; }
        public string CreationTime { get; set; }
        public string Region { get; set; }
        public string SalesOrderId { get; set; }
        public string BUID { get; set; }
    }
}
