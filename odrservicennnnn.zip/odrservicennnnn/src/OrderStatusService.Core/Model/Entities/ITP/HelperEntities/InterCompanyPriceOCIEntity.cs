﻿namespace OrderStatusService.Core.Model.Entities.ITP.HelperEntities
{
    public  class InterCompanyPriceOCIEntity
    {
        public FSLITPHeaderTBL fslITPHeaderTbl { get; set; }

        public FSLITPDetailTBL fslITPDetailTbl { get; set; }
    }
}
