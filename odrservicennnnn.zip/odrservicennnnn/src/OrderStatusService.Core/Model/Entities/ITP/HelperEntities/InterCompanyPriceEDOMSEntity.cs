﻿namespace OrderStatusService.Core.Model.Entities.ITP.HelperEntities
{
    public  class InterCompanyPriceEDOMSEntity
    {
        public FSLITPEDOMSHeaderTBL fslITPEDOMSHeaderTbl { get; set; }

        public FSLITPEDOMSItemTBL fslITPEDOMSItemTbl { get; set; }
    }
}
