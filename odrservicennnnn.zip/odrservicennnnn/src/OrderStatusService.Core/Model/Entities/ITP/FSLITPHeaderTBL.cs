﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPHeaderTBL
    {
        private bool m_IsNull;

        private readonly FSLITPHeaderT[] m_FSLITPHeaderT;

        public FSLITPHeaderTBL()
        {
            // TODO : Add code to initialise the object
        }

        public FSLITPHeaderTBL(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPHeaderTBL Null
        {
            get
            {
                FSLITPHeaderTBL obj = new FSLITPHeaderTBL();
                obj.m_IsNull = true;
                return obj;
            }
        }

       
    }
}
