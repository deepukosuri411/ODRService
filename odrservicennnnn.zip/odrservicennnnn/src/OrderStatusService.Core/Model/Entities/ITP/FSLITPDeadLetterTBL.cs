﻿namespace OrderStatusService.Core.Model.Entities.ITP
{
    public class FSLITPDeadLetterTBL
    {
        private bool m_IsNull;

        private FSLITPDeadLetterT[] m_FSLITPDeadLetterT;

        public FSLITPDeadLetterTBL()
        {
            // TODO : Add code to initialise the object
        }

        public FSLITPDeadLetterTBL(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPDeadLetterTBL Null
        {
            get
            {
                FSLITPDeadLetterTBL obj = new FSLITPDeadLetterTBL();
                obj.m_IsNull = true;
                return obj;
            }
        }

      
        public virtual FSLITPDeadLetterT[] Value
        {
            get
            {
                return this.m_FSLITPDeadLetterT;
            }
            set
            {
                this.m_FSLITPDeadLetterT = value;
            }
        }
    }
}
