﻿namespace OrderStatusService.Core.Model.Entities.AsnEventLog
{
    public  class DeqBossMsgTbl
    {
        private bool m_IsNull;

        private DeqBossMsgT[] m_DEQ_BOSS_MSG_T;

        public DeqBossMsgTbl()
        {
            // TODO : Add code to initialise the object
        }

        public DeqBossMsgTbl(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static DeqBossMsgTbl Null
        {
            get
            {
                DeqBossMsgTbl obj = new DeqBossMsgTbl();
                obj.m_IsNull = true;
                return obj;
            }
        }

     
        public virtual DeqBossMsgT[] Value
        {
            get
            {
                return this.m_DEQ_BOSS_MSG_T;
            }
            set
            {
                this.m_DEQ_BOSS_MSG_T = value;
            }
        }
    }

}
