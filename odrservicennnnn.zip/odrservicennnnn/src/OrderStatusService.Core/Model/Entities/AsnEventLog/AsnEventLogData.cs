﻿namespace OrderStatusService.Core.Model.Entities.AsnEventLog
{
    public class AsnEventLogData
    {
        public DeqBossMsgTbl DeqBossMsgTbl { get; set; }

    }
}
