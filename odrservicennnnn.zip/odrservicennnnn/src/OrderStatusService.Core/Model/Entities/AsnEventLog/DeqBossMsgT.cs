﻿namespace OrderStatusService.Core.Model.Entities.AsnEventLog
{
    public class DeqBossMsgT
    {
        private bool m_IsNull;

        private string m_PAY_LOAD;

        private string m_SERVICE_GROUP;

        private string m_PROCESS_ID;

        private string m_SERVICE_NAME;

        public DeqBossMsgT()
        {
            // TODO : Add code to initialise the object
        }

        public DeqBossMsgT(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static DeqBossMsgT Null
        {
            get
            {
                DeqBossMsgT obj = new DeqBossMsgT();
                obj.m_IsNull = true;
                return obj;
            }
        }

       
        public string PAY_LOAD
        {
            get
            {
                return this.m_PAY_LOAD;
            }
            set
            {
                this.m_PAY_LOAD = value;
            }
        }

      
        public string SERVICE_GROUP
        {
            get
            {
                return this.m_SERVICE_GROUP;
            }
            set
            {
                this.m_SERVICE_GROUP = value;
            }
        }

      
        public string PROCESS_ID
        {
            get
            {
                return this.m_PROCESS_ID;
            }
            set
            {
                this.m_PROCESS_ID = value;
            }
        }

       
        public string SERVICE_NAME
        {
            get
            {
                return this.m_SERVICE_NAME;
            }
            set
            {
                this.m_SERVICE_NAME = value;
            }
        }
    }
}
