﻿using OrderStatusService.Core.Model.Entities;

namespace OrderStatusService.Core.Model
{
    public class FSLContext
    {
       // public bool HasErrorOccurred { get; set; }
       // public string OrchestrationAPIRequest;
       // public string OrchestrationErrorCode { get; set; }
       // public string OrchestrationErrorDescription { get; set; }
       // public string NewGuid;
       // public HttpStatusCode statusCode { get; set; }
       // private string _qName;
       // private FSLMessage _inMsg;
       // private string _transformationMessage;
       // private bool _isValidOutMessage;
       // private string _schemaValidationErrors;
       // Dictionary<string, string> _xsltArgumentKeyValue;
       // private GloviaMsgType _gloviaMsgType;
       // private string _poStatus;
       // private string _ackType;
       // private QueueConfig _config;
       // private AccountDetails _accountDetail;
       // private Reason _reason;
       // private MessagerHeader _messagerHeader;
       // private List<FSLMessage> _fSLMessageList;
       // //private OrderStatusService.Infrastructure.Common.CustomLog.LogParameters _params;
       //// private OrderStatusService.Infrastructure.Common.CustomLog.LogParameters _customLogParams;
       // private GRPMessage _grpMessage;
       // private PedimentoData _pedimentoData;
       // private FAASAsnDetailsData _faasAsnDetailsData;
       // public OrderListenerConfigurations grpListenerConfigurations { get; set; }



       // public AsnEventLogData AsnEventLogData { get; set; }

       public ODRElements ODRElement { get; set; }

       



       // public OrderStatusService.Infrastructure.Common.CustomLog.LogParameters LogParameters
       // {
       //     get { return _params; }
       //     set { _params = value; }
       // }
       // public OrderStatusService.Infrastructure.Common.CustomLog.LogParameters CustomLogParams
       // {
       //     get { return _customLogParams; }
       //     set { _customLogParams = value; }
       // }
       // public FSLContext()
       // {
       //     _xsltArgumentKeyValue = new Dictionary<string, string>();
       //     _config = new QueueConfig();
       //     NewGuid = Guid.NewGuid().ToString();
       // }
       // public string MQName
       // {
       //     get { return _qName; }
       //     set { _qName = value; }
       // }
       // public MessagerHeader MsgHeader
       // {
       //     get { return _messagerHeader; }
       //     set { _messagerHeader = value; }
       // }
       // public Reason ReasonDetails
       // {
       //     get { return _reason; }
       //     set { _reason = value; }
       // }
       // public AccountDetails AccountDetail
       // {
       //     get { return _accountDetail; }
       //     set { _accountDetail = value; }
       // }
       // public FSLMessage InMsg
       // {
       //     get { return _inMsg; }
       //     set { _inMsg = value; }
       // }
       // public string TransformedMessage
       // {
       //     get { return _transformationMessage; }
       //     set { _transformationMessage = value; }
       // }
       // public bool IsValidOutMessage
       // {
       //     get { return _isValidOutMessage; }
       //     set { _isValidOutMessage = value; }
       // }
       // public string SchemaValidationErrors
       // {
       //     get { return _schemaValidationErrors; }
       //     set { _schemaValidationErrors = value; }
       // }
       // public Dictionary<string, string> XSLTArgumentKeyValue
       // {
       //     get { return _xsltArgumentKeyValue; }
       //     set { _xsltArgumentKeyValue = value; }
       // }
       // public GloviaMsgType GloviaMessageType
       // {
       //     get { return _gloviaMsgType; }
       //     set { _gloviaMsgType = value; }
       // }
       // public string POStatus
       // {
       //     get { return _poStatus; }
       //     set { _poStatus = value; }
       // }

       // //Added for GOP NOV release
       // //These properties will be used in GOPRequestHandler
       // public bool GOPEnabled { get; set; }
       // public bool GOPResponseEnabled { get; set; }
       // public string SourcePlan { get; set; }
       // public bool Isbacklogorder { get; set; }
       // //The Backlog orders was pushed to Feb release
       // //public RequestEndPoint MessageEndpoint { get; set; }

       // public string AckType
       // {
       //     get { return _ackType; }
       //     set { _ackType = value; }
       // }
       // public QueueConfig QueueConfig
       // {
       //     get { return _config; }
       //     set { _config = value; }
       // }
       // public List<FSLMessage> FSLMessageList
       // {
       //     get { return _fSLMessageList; }
       //     set { _fSLMessageList = value; }
       // }

       // public GRPMessage GRPMessage
       // {
       //     get { return _grpMessage; }
       //     set { _grpMessage = value; }
       // }

       // public PedimentoData PedimentoData
       // {
       //     get { return _pedimentoData; }
       //     set { _pedimentoData = value; }
       // }

       // public FAASAsnDetailsData FaasAsnDetailsData
       // {
       //     get { return _faasAsnDetailsData; }
       //     set { _faasAsnDetailsData = value; }
       // }



       // public string FILAPIRequest;
    }
}
