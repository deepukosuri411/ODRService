﻿namespace OrderStatusService.Core.Model
{
    public  class FSLITPHeaderT
    {
        private bool m_IsNull;

        private string m_SALES_ORDER_ID;

        private string m_AUTOMANIFEST;

        private string m_FACILITY;

        private string m_PILOT_FLAG;

        private string m_REGION;

        private decimal m_SALES_ORDER_REF;

        private bool m_SALES_ORDER_REFIsNull;

        private decimal m_BUID;

        private bool m_BUIDIsNull;

        public FSLITPHeaderT()
        {
            // TODO : Add code to initialise the object
            //this.m_SALES_ORDER_REFIsNull = true;
            //this.m_BUIDIsNull = true;
        }

        public FSLITPHeaderT(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static FSLITPHeaderT Null
        {
            get
            {
                FSLITPHeaderT obj = new FSLITPHeaderT();
                obj.m_IsNull = true;
                return obj;
            }
        }

        public string SALES_ORDER_ID
        {
            get
            {
                return this.m_SALES_ORDER_ID;
            }
            set
            {
                this.m_SALES_ORDER_ID = value;
            }
        }

        public string AUTOMANIFEST
        {
            get
            {
                return this.m_AUTOMANIFEST;
            }
            set
            {
                this.m_AUTOMANIFEST = value;
            }
        }

        public string FACILITY
        {
            get
            {
                return this.m_FACILITY;
            }
            set
            {
                this.m_FACILITY = value;
            }
        }

        public string PILOT_FLAG
        {
            get
            {
                return this.m_PILOT_FLAG;
            }
            set
            {
                this.m_PILOT_FLAG = value;
            }
        }

        public string REGION
        {
            get
            {
                return this.m_REGION;
            }
            set
            {
                this.m_REGION = value;
            }
        }

        public decimal SALES_ORDER_REF
        {
            get
            {
                return this.m_SALES_ORDER_REF;
            }
            set
            {
                this.m_SALES_ORDER_REF = value;
            }
        }

        public bool SALES_ORDER_REFIsNull
        {
            get
            {
                return this.m_SALES_ORDER_REFIsNull;
            }
            set
            {
                this.m_SALES_ORDER_REFIsNull = value;
            }
        }

        public decimal BUID
        {
            get
            {
                return this.m_BUID;
            }
            set
            {
                this.m_BUID = value;
            }
        }

        public bool BUIDIsNull
        {
            get
            {
                return this.m_BUIDIsNull;
            }
            set
            {
                this.m_BUIDIsNull = value;
            }
        }

    }
}
