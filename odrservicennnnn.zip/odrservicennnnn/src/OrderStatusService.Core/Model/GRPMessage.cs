﻿using OrderStatusService.Core.Enumeration;
using System;
using System.Collections.Generic;

namespace OrderStatusService.Core.Model
{
    public class GRPMessage
    {
       

        public string PreGPO { get; set; }
        public string IsOTMDeterminedByOFS { get; set; }
        public string UpdateMessage { get; set; }
        public string SOOrderType { get; set; }
        public string Retailer_Name { get; set; }
        public string DOMS_Company { get; set; }
        public string PilotOTMOrder { get; set; }
        public string FIMSInput { get; set; }
   
        public string DemandRegion { get; set; }
        public string MessagePurpose { get; set; }
       
        public string ErrorDescription { get; set; }
        public string ErrorCode { get; set; }
      
        public string PilotOTMOrder3A { get; set; }
        public List<string> BaseType { get; set; }
        public string ConfigType { get; set; }
        public DateTime? OrderDate { get; set; }
        public string AFFOrderType { get; set; }
        public string LeadTimesXml { get; set; }
  
        public string ShipToFacilityBFC { get; set; }
        public bool IsVxRail { get; set; }
        public string QuotationPrefix { get; set; }
        public bool IsFGADirectShip { get; set; }
        public string LogisticAckShipCode { get; set; }
        public bool IsVxOrderOTMEnabled { get; set; }
        public bool IsHardMerge { get; set; }
        public bool IsCIFOrder { get; set; }
        public bool IsExWorkOrder { get; set; }
        public string IsOTMAPJRampUp { get; set; }
        public string IsReassignedTo3PL { get; set; }
        public bool IsRetailOrder { get; set; }
        public DateTime? RoutedDate { get; set; }
        public string MIT_ID { get; set; }
        public string LogisticResponse { get; set; }
        public bool IsULMEnabled { get; set; }
        public string InboundMessage { get; set; }
        public string OrderType { get; set; }
        public string SalesOrderId { get; set; }
        public string BUID { get; set; }
        public string SubRegion { get; set; }
        public Region Region { get; set; }
        public bool IsOceanEligible { get; }
        public bool IsValidMABD { get; set; }
        public DateTime? MABD { get; set; }
        public DateTime? EABD { get; set; }
        public string Channel { get; set; }
        public string AIDOMSBUID { get; set; }
        public string AMFInvoiceFlag { get; set; }
        public string MCID { get; set; }
        public string CorrelationId { get; set; }
        public string MessageId { get; set; }
        public MsgType MessageType { get; set; }
        public bool Is3PP { get; set; }
        public MsgType DateCalculatorType { get; set; }
        public string ThreePLFacility { get; set; }
        public string DestinationCountry { get; set; }
        public string LOB { get; set; }
        public string CategoryCode { get; set; }
        public string SourceType { get; set; }
        public string Mode { get; set; }
        public string SCRReponseTemp { get; set; }
        public string ODMFacility { get; set; }
        public bool IsSalesOrderLevelOTMEnabled { get; set; }
        public bool DetermineRoutePlan { get; set; }
        public string ShipToState { get; set; }
        public string ShipToCountry { get; set; }
        public string ShipCode { get; set; }
        public string ShipMode { get; set; }
        public DateTime? DLYDAT { get; set; }
        public bool CustomerExists { get; set; }
        public bool IsMIT { get; set; }

      
    }
}
