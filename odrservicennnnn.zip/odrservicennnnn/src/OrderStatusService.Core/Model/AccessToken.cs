﻿namespace OrderStatusService.Core.Model
{
    public class AccesToken
    {
        public string access_token { get; set; }
    }
}
