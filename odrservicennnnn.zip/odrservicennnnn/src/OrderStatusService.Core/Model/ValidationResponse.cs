﻿using Newtonsoft.Json;
using OrderStatusService.Core.ExceptionModel.CustomException.Error;
using System.Collections.Generic;

namespace OrderStatusService.Core.Model
{
    public class ValidationResponse
    {
        [JsonProperty(Order = 1)]
        public List<ErrorModel> Errors { get; set; } = new List<ErrorModel>();

        [JsonIgnore]
        [JsonProperty(Order = 2)]
        public bool IsValid { get; set; }
    }
}