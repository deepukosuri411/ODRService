﻿namespace OrderStatusService.Core.Model
{

}
