﻿namespace OrderStatusService.Core.Model.Token
{
    public class QueueConfig
    {
        private string name;
        private string server;
        private string queueManager;
        private string channel;
        private string queueName;
        private string direction;

        public QueueConfig()
        {
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string Server
        {
            get
            {
                return server;
            }
            set
            {
                server = value;
            }
        }

        public string QueueManager
        {
            get
            {
                return queueManager;
            }
            set
            {
                queueManager = value;
            }
        }

        public string Channel
        {
            get
            {
                return channel;
            }
            set
            {
                channel = value;
            }
        }

        public string QueueName
        {
            get
            {
                return queueName;
            }
            set
            {
                queueName = value;
            }
        }

        public string Direction
        {
            get { return direction; }
            set { direction = value; }
        }

    }
}
