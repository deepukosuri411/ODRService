﻿using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.Model.Entities.AsnEventLog;
using OrderStatusService.Core.Model.Entities.ITP;
using OrderStatusService.Core.Model.Entities.ITP.HelperEntities;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace OrderStatusService.Core.Model.Token
{
    public class FSLMessage
    {
        public string InMessage { get; set; }

        public string MessageId { get; set; }

        public string SalesOrderId { get; set; }

        public string FileName { get; set; }

        public MsgType MsgType { get; set; }

        public Region Region { get; set; }

        public ServiceName ServiceName { get; set; }

        public string SubRegion { get; set; }

        public string Channel { get; set; }

        public string QueueName { get; set; }

        public string OutMessage { get; set; }

        public string SubscriberName { get; set; }

        public string MessageType { get; set; }

        public ITPMessage ITPMessage { get; set; }

        public ITPElements ITPElements { get; set; }

       

       

        public FSLPODElements FSLPODElements { get; set; }

        public AsnEventLogData AsnEventLogData { get; set; }

       
        public CarrierMilestoneAPJElements CarrierMilestoneAPJElements { get; set; }

    }

    public class ITPMessage
    {
        public InterCompanyPriceOCIEntity ITPOCIEntity { get; set; }

        public InterCompanyPriceEDOMSEntity ITPEDOMSEntity { get; set; }

        public InterCompanyPriceResponseEntity ITPResponseEntity { get; set; }

        public FSL2LGSTriggerEntity LGSEnity { get; set; }

        public FSLITPDeadLetterTBL DeadLetterTBL { get; set; }

        public FSLITPTrialTBL FSLITPTrialTbl { get; set; }
    }

    public class ITPElements
    {
        public string BUID { get; set; }

        public string SalesOrderId { get; set; }

        public string CorrelationId { get; set; }

        public string MessageId { get; set; }
        public string OrderId { get; set; }
        public string RetryCount { get; set; }

        public string AutoManisfest { get; set; }

        public string StatusCode { get; set; }

        public string TransactionStatus { get; set; }

        public string Region { get; set; }

        public string ErrorCode { get; set; }

        public string ErrorDescription { get; set; }

        public string GetStatusCode()
        {
            return StatusCode;
        }

        public string GetTransactionStatus()
        {
            return TransactionStatus;
        }

    }

    
   

    public class CarrierMilestoneAPJElements
    {
        public string SenderTransmissionNo { get; set; }

        public string DragonMessage { get; set; }

        public string FoeeMessage { get; set; }
        public List<string> DragonMessageCollection { get; set; }
        public List<string> FoeeMessageCollection { get; set; }

        public string TranactionSequenceNo { get; set; }

    }

    public class PedimentoMessage
    {
        public string LAOrderNumber { get; set; }

        public decimal SequenceNumber { get; set; }

        public string PedimentoNumber { get; set; }

        public string Location { get; set; }

        public string PedimentoDate { get; set; }

        public string ServiceTag { get; set; }
    }
    public class FaasMessage
    {
        public FaasOrderSvcTagResponse FaasOrderSvcTagResponse { get; set; }
    }


    //[XmlRootAttribute("FaasOrderSvcTagResponse", Namespace = "http://schemas.dell.com/fsl/FaasOrderSvcTagResponse/1.0")] 
    [DataContract(Namespace = "http://schemas.dell.com/fsl/FaasOrderSvcTagResponse/1.0")]
    public class FaasOrderSvcTagResponse
    {
        [DataMember]
        public FaasMessageHeader MessageHeader { get; set; }

        [DataMember]
        public FaasMessageBody Response { get; set; }

    }

    [DataContract]
    public class FaasMessageBody
    {
        [DataMember(Order = 1)]
        public string SalesOrderId { get; set; }

        [DataMember(Order = 2)]
        public decimal Buid { get; set; }

        [DataMember(Order = 3)]
        public SalesOrderTies SalesOrderTies { get; set; }
    }

    [DataContract]
    public class FaasMessageHeader
    {
        [DataMember(Order = 1)]
        public string MessageId { get; set; }
        [DataMember(Order = 2)]
        public string MessageTimeStamp { get; set; }
        [DataMember(Order = 3)]
        public string Region { get; set; }
        [DataMember(Order = 4)]
        public string SenderID { get; set; }
        [DataMember(Order = 5)]
        public string ReceiverID { get; set; }
        [DataMember(Order = 6)]
        public string Version { get; set; }
        [DataMember(Order = 7)]
        public string CorrelationId { get; set; }
    }

    [DataContract]
    public class SalesOrderTies
    {
        //[System.Xml.Serialization.XmlArrayAttribute()]
        //[System.Xml.Serialization.XmlArrayItemAttribute("SalesOrderTie")]
        [DataMember]
        public List<SalesOrderTieData> SalesOrderTie { get; set; }

    }
    [DataContract]
    public class SalesOrderTieData
    {
        [DataMember(Order = 1)]
        public string TieNumber { get; set; }

        [DataMember(Order = 2)]
        public string SINumber { get; set; }

        [DataMember(Order = 3)]
        public ServiceTags ServiceTags { get; set; }
    }

    [DataContract]
    public class ServiceTags
    {
        [DataMember]
        public List<ServiceTagData> ServiceTag { get; set; }

    }

    [DataContract]
    public class ServiceTagData
    {
        [DataMember(Order = 1)]
        public string ServiceTagNumber { get; set; }

        [DataMember(Order = 2)]
        public string BasePart { get; set; }
    }

    [DataContract]
    public class PEFMessageBody
    {
        [DataMember(Order = 1)]
        public string SalesOrderId { get; set; }

        [DataMember(Order = 2)]
        public decimal Buid { get; set; }

        [DataMember(Order = 3)]
        public PEFSalesOrderTies SalesOrderTies { get; set; }
    }


    public class UEMMessageBody
    {
        [IgnoreDataMember]
        public string ASNNumber { get; set; }

        [DataMember(Order = 1)]
        public string SalesOrderId { get; set; }

        [DataMember(Order = 2)]
        public decimal Buid { get; set; }


        [DataMember(Order = 3)]
        public string MCID { get; set; }

        [DataMember(Order = 4)]
        public string GCSOrderType { get; set; }


        [DataMember(Order = 5)]
        public PEFSalesOrderTies SalesOrderTies { get; set; }
    }

    [DataContract]
    public class PEFSalesOrderTies
    {
        //[System.Xml.Serialization.XmlArrayAttribute()]
        //[System.Xml.Serialization.XmlArrayItemAttribute("SalesOrderTie")]
        [DataMember]
        public List<PEFSalesOrderTieData> SalesOrderTie { get; set; }

    }

    [DataContract]
    public class PEFSalesOrderTieData
    {
        [DataMember(Order = 1)]
        public string TieNumber { get; set; }

        //[DataMember(Order = 2)]
        //public string SINumber { get; set; }

        [DataMember(Order = 3)]
        public Items Items { get; set; }
    }

    [DataContract]
    public class Items
    {
        [DataMember]
        public List<ItemData> Item { get; set; }

    }

    [DataContract]
    public class ItemData
    {
        [DataMember(Order = 1)]
        public string ServiceTagNumber { get; set; }

        [DataMember(Order = 2)]
        public string PPID { get; set; }

        [DataMember(Order = 3)]
        public string SerialNumber { get; set; }

        [DataMember(Order = 4)]
        public string BasePart { get; set; }
    }

    public class PedimentoData
    {
        public List<PedimentoMessage> PedimentoMSG { get; set; }

        public string ASNNumber { get; set; }

        public string VendorID { get; set; }
    }

    public class FAASAsnDetailsData
    {
        public List<FaasMessage> FaasMSGS { get; set; }

        public string AsnNum;
    }

   

    public class FSLPODElements
    {
        public string ORDERNUMBER { get; set; }

        public string ErrorCode { get; set; }

        public string ErrorDescription { get; set; }

        public string RetryCount { get; set; }

        public ulong TransactionSeqNumber { get; set; }

        public string Status { get; set; }
    }

    public abstract class BaseSvcTagRequest
    {
        public FaasMessageHeader MessageHeader { get; set; }
    }

    public class OrderSvcTagRequest : BaseSvcTagRequest
    {
        public object xmlns { get; set; }
        public List<PEFMessageBody> Request { get; set; }
    }
    public class UEMOrderSvcTagRequest : BaseSvcTagRequest
    {
        public UEMMessageBody Details { get; set; }
    }

    public class PEFEnabledOrderRequest
    {
        public string AsnNum;
        public string Region;
        public OrderSvcTagRequest OrderSvcTagRequest { get; set; }
    }

    public class PEFEnabledOrderRequestData
    {
        public List<PEFEnabledOrderRequest> lstPefEnabledOrderReqData;

    }

    public class UEMEnabledOrderRequest
    {
        public UEMOrderSvcTagRequest OrderSvcTagDetails { get; set; }
    }
    public class UEMEnabledOrderRequestData
    {
        public List<UEMEnabledOrderRequest> lstUEMEnableOrderReqData;
    }

    public class ACK_NACK_STATUS
    {
        public string P_RETURN_CODE { get; set; }
        public string P_ERROR_MESSAGE { get; set; }
    }
    public class AccesToken
    {
        public string access_token { get; set; }
    }

}
