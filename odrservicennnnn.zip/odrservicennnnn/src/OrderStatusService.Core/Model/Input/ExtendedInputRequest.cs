﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Model
{
    [ExcludeFromCodeCoverage]
    public class ExtendedInputRequest
    {
        public string EntityType { get; set; }
        public List<string> EntityValue { get; set; }
        public int EventID { get; set; }
        public DateTime EventTimestamp { get; set; }
        public string Version { get; set; }
        public string DataSource { get; set; }
        public string Region { get; set; }
        public string EventName { get; set; }
        public string FinalAsn { get; set; }
        public string VendorName { get; set; }
        public string TraceId { get; set; }
        public string BaseSource { get; set; }
        public string ManifestRef { get; set; }
    }
}
