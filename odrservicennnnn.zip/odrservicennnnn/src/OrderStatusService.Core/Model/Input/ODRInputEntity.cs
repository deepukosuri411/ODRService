﻿namespace OrderStatusService.Core.Model
{
    public class ODRInputEntity
    {
        public ODRTbl OrderValInputTbl { get; set; }
    }
}
