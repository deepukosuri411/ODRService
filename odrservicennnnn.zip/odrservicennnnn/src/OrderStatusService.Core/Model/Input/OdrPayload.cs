﻿using OrderStatusService.Core.Model.SpSchemaDeclarations.Udt;

namespace OrderStatusService.Core.Model
{
    public class OdrPayload
    {
        public virtual BrhSyncroMsg_Tbl SyncroOrder { get; set; }

        public virtual FGA_ITEM_BOM_TBL ItemBom { get; set; }

        public string Sender_Id { get; set; }

        public string Created_By { get; set; }

        public string CloB_XML { get; set; }

        public string Order_Type { get; set; }

        public string AI_Order_No { get; set; }
    }
}
