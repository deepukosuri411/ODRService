﻿namespace OrderStatusService.Core.Model
{
    public class ODRTbl
    {

        private bool m_IsNull;

        private OdrPayload[] m_ODR_T;

        public ODRTbl()
        {
            // TODO : Add code to initialise the object
        }

        public ODRTbl(string str)
        {
            // TODO : Add code to initialise the object based on the given string 
        }

        public virtual bool IsNull
        {
            get
            {
                return this.m_IsNull;
            }
        }

        public static ODRTbl Null
        {
            get
            {
                ODRTbl obj = new ODRTbl();
                obj.m_IsNull = true;
                return obj;
            }
        }

        public virtual OdrPayload[] Value
        {
            get
            {
                return this.m_ODR_T;
            }
            set
            {
                this.m_ODR_T = value;
            }
        }
    }
       
}
