﻿using System;

namespace OrderStatusService.Core.Model.Input
{
    public class BaseRequest
    {
        public Guid TransactionReferenceID
        {
            get
            {
                return Guid.NewGuid();
            }
        }
        public override string ToString()
        {
            return string.Empty;
        }
    }
}
