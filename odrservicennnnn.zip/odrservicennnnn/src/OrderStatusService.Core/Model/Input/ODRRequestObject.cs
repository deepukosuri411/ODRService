﻿namespace OrderStatusService.Core.Model.Input
{
    public class ODRRequestObject : BaseRequest
    {
        public ODRRequest OrderStatusRequest { get; set; }
    }
}
