﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Model
{
    [ExcludeFromCodeCoverage]
    public class InputRequest
    {
        public string EntityType { get; set; }
        public List<string> EntityValue { get; set; }
        public int EventID { get; set; }
        public DateTime EventTimestamp { get; set; }
        public string Version { get; set; }
        public List<EventAttribute> Attributes { get; set; }

       
    }

    [ExcludeFromCodeCoverage]
    public class EventAttribute
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
