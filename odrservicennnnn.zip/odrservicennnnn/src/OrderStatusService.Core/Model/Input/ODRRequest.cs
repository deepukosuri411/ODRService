﻿
using OrderStatusService.Core.Model.SpSchemaDeclarations.Udt;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace OrderStatusService.Core.Model.Input
{
    public  class ODRRequest
    {

        public ODRRequest()
        {
        }

        [XmlElement(IsNullable = false)]
        [DataMember(IsRequired = true)]
        public virtual BrhSyncroMsg_Tbl Value1 { get; set; }

        public virtual FGA_ITEM_BOM_TBL Value2 { get; set; }


        [XmlElement(IsNullable = true)]
        public string Sender_Id { get; set; }

        public string Created_By { get; set; }

        public string Order_Type { get; set; }

        public string Clob_XML { get; set; }

        public string AI_Order_Number { get; set; }
    }

  
  

}
