﻿using System.Collections.Generic;

namespace OrderStatusService.Core.Model
{
    public class OrderValidationTestMethodEnt
    {
        public List<OrderValReqV3_T> orderValReqTList { get; set; }
        public List<OrderValReqAckT> orderValReqAckTList { get; set; }
    }
}
