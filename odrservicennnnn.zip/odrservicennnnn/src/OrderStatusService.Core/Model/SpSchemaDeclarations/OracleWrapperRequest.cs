﻿using OrderStatusService.Core.Model;
using System.Diagnostics.CodeAnalysis;
using static OrderValidationService.Core.OrderSchemaDeclarations.OrderSchemaBaseModel;

namespace OrderStatusService.Core.SpSchemaDeclarations
{
    [ExcludeFromCodeCoverage]
    public class OracleBaseServiceOrderValidation : OracleBaseApiRequest
    {
        public OdrPayload OdrPayload { get; set; }
    }
}
