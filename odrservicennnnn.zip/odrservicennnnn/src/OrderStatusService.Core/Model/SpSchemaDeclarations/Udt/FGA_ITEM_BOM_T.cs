﻿namespace OrderStatusService.Core.Model.SpSchemaDeclarations.Udt
{
    public class FGA_ITEM_BOM_T
    {
        public string LATE_REV { get; set; }

        public string SUBSTITUTIONS_ALLOWED { get; set; }

        public decimal COMP_LEVEL { get; set; }

        public bool COMP_LEVELIsNull { get; set; } = false;

        public string ISSUE_CODE { get; set; }

        public string COMMODITY { get; set; }

        public string DMS_FLAG { get; set; }

        public string COMP_ITEM { get; set; }

        public string ITEM_CLASS_CODE { get; set; }

        public string MONITOR_CODE { get; set; }

        public decimal LINE_SKU_REF { get; set; }

        public bool LINE_SKU_REFIsNull { get; set; } = true;

        public string PARENT_ITEM { get; set; }

        public string IS_FGA_SKU { get; set; }

        public string CCN { get; set; }

        public string COMP_QTY { get; set; }

        public string ITEM_TYPE { get; set; }

        public decimal WEIGHT { get; set; }

        public bool WEIGHTIsNull { get; set; } = false;

        public string ITEM_SUB_CLASS_CODE { get; set; }

        public string LOB_CODE { get; set; }

        public string IS_SYSTEM { get; set; }

        public string ORDER_NUM { get; set; }

        public string BOX_CODE { get; set; }
    }
}
