﻿namespace OrderStatusService.Core.Model.SpSchemaDeclarations.Udt
{
    public class FGA_ITEM_BOM_TBL
    {
        public virtual FGA_ITEM_BOM_T[] Value { get; set; }
    }
}
