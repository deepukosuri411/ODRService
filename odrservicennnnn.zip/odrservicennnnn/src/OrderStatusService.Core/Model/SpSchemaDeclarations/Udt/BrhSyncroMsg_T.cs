﻿namespace OrderStatusService.Core.Model.SpSchemaDeclarations.Udt
{
    public class BrhSyncroMsg_T
    {
        public string SKU_NUMBER { get; set; }

        public string SKU_DESCRIPTION { get; set; }

        public string FGID { get; set; }

        public string BASE_FLAG { get; set; }

        public decimal TIE_NUMBER { get; set; }

        public bool TIE_NUMBERIsNull { get; set; }

        public string ORDER_NUMBER { get; set; }

        public decimal SKU_QTY { get; set; }

        public bool SKU_QTYIsNull { get; set; }
    }
}
