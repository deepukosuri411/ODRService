﻿namespace OrderStatusService.Core.Model.SpSchemaDeclarations.Udt
{
    public class BrhSyncroMsg_Tbl
    {
        public virtual BrhSyncroMsg_T[] Value { get; set; }
    }
}
