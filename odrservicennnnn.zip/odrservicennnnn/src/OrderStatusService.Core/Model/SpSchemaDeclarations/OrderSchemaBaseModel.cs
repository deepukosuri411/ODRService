﻿using OrderStatusService.Core.Global.Configs;
using System;
using System.Data;
using System.Diagnostics.CodeAnalysis;


namespace OrderValidationService.Core.OrderSchemaDeclarations
{
    [ExcludeFromCodeCoverage]
    public class OrderSchemaBaseModel
    {
        #region OrderSchemaBaseModel
        [Serializable]
        [ExcludeFromCodeCoverage]
        public class OracleBaseServiceRequestBase
        {
            public string StoredProcName { get; set; }
            public string Region { get; set; }
        }

        [Serializable]
        [ExcludeFromCodeCoverage]
        public class OracleParamEntityBase
        {
            public string ParameterName { get; set; }
           
            public ParameterDirection Direction { get; set; }
            public string UdtTypeName { get; set; }
            public int Size { get; set; }
        }

        public class OracleBaseApiRequest
        {
            public OracleExecution OracleExecution { get; set; }
            public string Region { get; set; }
        }
        #endregion
    }
}
