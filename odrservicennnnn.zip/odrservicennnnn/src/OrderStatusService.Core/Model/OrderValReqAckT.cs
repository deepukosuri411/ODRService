﻿using System;

namespace OrderStatusService.Core.Model
{
    public class OrderValReqAckT
    {
        public OrderValReqAckT()
        {

        }

        public decimal ORDER_ID { get; set; }

        public bool ORDER_IDIsNull { get; set; }

        public string PLAN_TYPE { get; set; }

        public DateTime PLAN_DATE { get; set; }

        public bool PLAN_DATEIsNull { get; set; }

        public string ERROR_ID { get; set; }

        public string ERROR_DESC { get; set; }

        public string PARTIAL_SHIP_ID { get; set; }

        public string IS_DG_ENABLED { get; set; }
    }
}

