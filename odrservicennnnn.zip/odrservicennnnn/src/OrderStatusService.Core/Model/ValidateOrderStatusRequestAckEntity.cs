﻿namespace OrderStatusService.Core.Model
{
    public class ValidateOrderStatusRequestAckEntity
    {
        public OrderValReqAckTbl OrderValReqAckTbl { get; set; }
    }
}
