﻿namespace OrderStatusService.Core.Model
{
    public class OrderValReqV3_T
    {
    }
}