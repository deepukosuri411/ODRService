﻿using System.Collections.Generic;

namespace OrderStatusService.Core.Model.OrderStatus
{
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:epcglobal:epcis:xsd:1", IsNullable = false)]
    public partial class EPCISDocument
    {
        private EPCISDocumentEPCISHeader ePCISHeaderField;

        private EPCISDocumentEventList ePCISEventbodyField;

        private System.DateTime creationDateField;

        private string schemaVersionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public EPCISDocumentEPCISHeader EPCISHeader
        {
            get
            {
                return this.ePCISHeaderField;
            }
            set
            {
                this.ePCISHeaderField = value;
            }
        }



        /// <remarks/>
        //[System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        //[System.Xml.Serialization.XmlArrayItemAttribute("EventBody", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = false)]  
        //[System.Xml.Serialization.XmlArrayItemAttribute("EventList", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = false, NestingLevel = 1 )]  
        //[System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public EPCISDocumentEventList EPCISBody
        {
            get
            {
                return this.ePCISEventbodyField;
            }
            set
            {
                this.ePCISEventbodyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public System.DateTime creationDate
        {
            get
            {
                return this.creationDateField;
            }
            set
            {
                this.creationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string schemaVersion
        {
            get
            {
                return this.schemaVersionField;
            }
            set
            {
                this.schemaVersionField = value;
            }
        }
    }
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.unece.org/cefact/namespaces/StandardBusinessDocumentHeader")]
    [System.Xml.Serialization.XmlRootAttribute("StandardBusinessDocumentHeader", Namespace = "http://www.unece.org/cefact/namespaces/StandardBusinessDocumentHeader", IsNullable = true)]
    public partial class EPCISDocumentEPCISHeader
    {

        private StandardBusinessDocumentHeader standardBusinessDocumentHeaderField;

        /// <remarks/>
        public StandardBusinessDocumentHeader StandardBusinessDocumentHeader
        {
            get
            {
                return this.standardBusinessDocumentHeaderField;
            }
            set
            {
                this.standardBusinessDocumentHeaderField = value;
            }
        }
    }


    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class EPCISDocumentEventBody
    {
        private EPCISDocumentEventList ePCISEventListField;

        ///// <remarks/>
        //[System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        //[System.Xml.Serialization.XmlArrayItemAttribute("EventList", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = false)]
        public EPCISDocumentEventList EventList
        {
            get
            {
                return this.ePCISEventListField;
            }
            set
            {
                this.ePCISEventListField = value;
            }
        }

    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class EPCISDocumentEventList
    {
        private List<EPCISDocumentEventListObjectEvent> ePCISObjectField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        [System.Xml.Serialization.XmlArrayItemAttribute("ObjectEvent", typeof(EPCISDocumentEventListObjectEvent), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<EPCISDocumentEventListObjectEvent> EventList
        {
            get
            {
                return this.ePCISObjectField;
            }
            set
            {
                this.ePCISObjectField = value;
            }
        }

    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    // [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    public partial class EPCISDocumentEventListObjectEvent
    {

        private System.DateTime eventTimeField;

        private string eventTimeZoneOffsetField;

        private List<EPCISDocumentEventListObjectEventEpcListEpc> epcListField;

        private string actionField;

        private string bizStepField;

        private string dispositionField;

        private List<EPCISDocumentEventListObjectEventReadPoint> readPointField;

        private List<EPCISDocumentEventListObjectEventBizLocation> bizLocationField;

        private List<EPCISDocumentEventListObjectEventBizTransactionListBizTransaction> bizTransactionListField;

        private string custodyOwnerField;

        private List<EPCISDocumentEventListObjectEventExtension> bizExtensionListField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public System.DateTime eventTime
        {
            get
            {
                return this.eventTimeField;
            }
            set
            {
                this.eventTimeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string eventTimeZoneOffset
        {
            get
            {
                return this.eventTimeZoneOffsetField;
            }
            set
            {
                this.eventTimeZoneOffsetField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        [System.Xml.Serialization.XmlArrayItemAttribute("epc", typeof(EPCISDocumentEventListObjectEventEpcListEpc), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<EPCISDocumentEventListObjectEventEpcListEpc> epcList
        {
            get
            {
                return this.epcListField;
            }
            set
            {
                this.epcListField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string action
        {
            get
            {
                return this.actionField;
            }
            set
            {
                this.actionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string bizStep
        {
            get
            {
                return this.bizStepField;
            }
            set
            {
                this.bizStepField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string disposition
        {
            get
            {
                return this.dispositionField;
            }
            set
            {
                this.dispositionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("readPoint", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<EPCISDocumentEventListObjectEventReadPoint> readPoint
        {
            get
            {
                return this.readPointField;
            }
            set
            {
                this.readPointField = value;
            }
        }


        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("bizLocation", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<EPCISDocumentEventListObjectEventBizLocation> bizLocation
        {
            get
            {
                return this.bizLocationField;
            }
            set
            {
                this.bizLocationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        [System.Xml.Serialization.XmlArrayItemAttribute("bizTransaction", typeof(EPCISDocumentEventListObjectEventBizTransactionListBizTransaction), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<EPCISDocumentEventListObjectEventBizTransactionListBizTransaction> bizTransactionList
        {
            get
            {
                return this.bizTransactionListField;
            }
            set
            {
                this.bizTransactionListField = value;
            }
        }




        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://verifybrand.com")]
        public string CustodyOwner
        {
            get
            {
                return this.custodyOwnerField;
            }
            set
            {
                this.custodyOwnerField = value;
            }
        }




        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        [System.Xml.Serialization.XmlArrayItemAttribute("extension", typeof(EPCISDocumentEventListObjectEventExtension), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<EPCISDocumentEventListObjectEventExtension> extension
        {
            get
            {
                return this.bizExtensionListField;
            }
            set
            {
                this.bizExtensionListField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    public partial class EPCISDocumentEventListObjectEventEpcListEpc
    {

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    public partial class EPCISDocumentEventListObjectEventBizLocation
    {

        private string idField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    public partial class EPCISDocumentEventListObjectEventReadPoint
    {

        private string idField;

        private EPCISDocumentEventListObjectEventExtension extensionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        //[System.Xml.Serialization.XmlArrayItemAttribute("extension", typeof(EPCISDocumentEventListObjectEventExtension), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public EPCISDocumentEventListObjectEventExtension extension
        {
            get
            {
                return this.extensionField;
            }
            set
            {
                this.extensionField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    public partial class EPCISDocumentEventListObjectEventBizTransactionListBizTransaction
    {

        private string typeField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:epcglobal:epcis:xsd:1")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:epcglobal:epcis:xsd:1", IsNullable = false)]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "")]
    public partial class EPCISDocumentEventListObjectEventExtension
    {
        private string extensionField;
        private string address1Field;
        private string address2Field;
        private string Address3Field;
        private string cityField;
        private string adminDistrictField;
        private string countryField;
        private string postalCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("extension")]
        public string Extension
        {
            get { return extensionField; }
            set { extensionField = value; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Address1")]
        public string Address1
        {
            get { return address1Field; }
            set { address1Field = value; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Address2")]
        public string Address2
        {
            get { return this.address2Field; }
            set { this.address2Field = value; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Address3")]
        public string Address3
        {
            get { return this.Address3Field; }
            set { this.Address3Field = value; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("City")]
        public string City
        {
            get { return this.cityField; }
            set { this.cityField = value; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("AdminDistrict")]
        public string AdminDistrict
        {
            get { return this.adminDistrictField; }
            set { this.adminDistrictField = value; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Country")]
        public string Country
        {
            get { return this.countryField; }
            set { this.countryField = value; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PostalCode")]
        public string PostalCode
        {
            get { return this.postalCodeField; }
            set { this.postalCodeField = value; }
        }

    }
    public partial class StandardBusinessDocumentHeader
    {

        private string headerVersionField;

        private StandardBusinessDocumentHeaderSender senderField;

        private StandardBusinessDocumentHeaderReceiver receiverField;

        private StandardBusinessDocumentHeaderDocumentIdentification documentIdentificationField;

        /// <remarks/>
        public string HeaderVersion
        {
            get
            {
                return this.headerVersionField;
            }
            set
            {
                this.headerVersionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Sender")]
        public StandardBusinessDocumentHeaderSender Sender
        {
            get
            {
                return this.senderField;
            }
            set
            {
                this.senderField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Receiver")]
        public StandardBusinessDocumentHeaderReceiver Receiver
        {
            get
            {
                return this.receiverField;
            }
            set
            {
                this.receiverField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("DocumentIdentification")]
        public StandardBusinessDocumentHeaderDocumentIdentification DocumentIdentification
        {
            get
            {
                return this.documentIdentificationField;
            }
            set
            {
                this.documentIdentificationField = value;
            }
        }
    }
    public partial class StandardBusinessDocumentHeaderDocumentIdentification
    {

        private string standardField;

        private string typeVersionField;

        private string instanceIdentifierField;

        private string typeField;

        private System.DateTime creationDateAndTimeField;

        /// <remarks/>
        public string Standard
        {
            get
            {
                return this.standardField;
            }
            set
            {
                this.standardField = value;
            }
        }

        /// <remarks/>
        public string TypeVersion
        {
            get
            {
                return this.typeVersionField;
            }
            set
            {
                this.typeVersionField = value;
            }
        }

        /// <remarks/>
        public string InstanceIdentifier
        {
            get
            {
                return this.instanceIdentifierField;
            }
            set
            {
                this.instanceIdentifierField = value;
            }
        }

        /// <remarks/>
        public string Type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        public System.DateTime CreationDateAndTime
        {
            get
            {
                return this.creationDateAndTimeField;
            }
            set
            {
                this.creationDateAndTimeField = value;
            }
        }
    }
    public partial class StandardBusinessDocumentHeaderReceiver
    {

        private string identifierField;

        /// <remarks/>
        public string Identifier
        {
            get
            {
                return this.identifierField;
            }
            set
            {
                this.identifierField = value;
            }
        }
    }
    public partial class StandardBusinessDocumentHeaderSender
    {

        private string identifierField;

        /// <remarks/>
        public string Identifier
        {
            get
            {
                return this.identifierField;
            }
            set
            {
                this.identifierField = value;
            }
        }
    }
}
