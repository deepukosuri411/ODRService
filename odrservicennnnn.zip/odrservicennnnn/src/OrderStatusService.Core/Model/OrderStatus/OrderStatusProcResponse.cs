﻿using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Model
{
    [ExcludeFromCodeCoverage]
    public class OrderStatusProcResponse
    {
        public bool IsSaved { get; set; }
    }
}
