﻿//using Dell.Manufacturing.FDL.Utilities;
namespace OrderStatusService.Core.Model
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using System;
    using System.Globalization;

    public partial class ItemBomList
        {
            [JsonProperty("ITEMBOM", NullValueHandling = NullValueHandling.Ignore)]
            public ItemBom[] Itembom { get; set; }
        }
        public partial class ItemBom
        {
            [JsonProperty("IS_SYSTEM", NullValueHandling = NullValueHandling.Ignore)]
            public string IsSystem { get; set; }

            [JsonProperty("LOB_CODE", NullValueHandling = NullValueHandling.Ignore)]
            [JsonConverter(typeof(ParseStringConverter))]
            public string LobCode { get; set; }

            [JsonProperty("DESCRIPTION", NullValueHandling = NullValueHandling.Ignore)]
            public string Description { get; set; }

            [JsonProperty("ITEM_TYPE", NullValueHandling = NullValueHandling.Ignore)]
            public string ItemType { get; set; }

            [JsonProperty("ISSUE_CODE", NullValueHandling = NullValueHandling.Ignore)]
            public string IssueCode { get; set; }

            [JsonProperty("COMMODITY", NullValueHandling = NullValueHandling.Ignore)]
            public string Commodity { get; set; }

            [JsonProperty("PRINT_ON_TRAVELER", NullValueHandling = NullValueHandling.Ignore)]
            public string PrintOnTraveler { get; set; }

            [JsonProperty("BOX_CODE", NullValueHandling = NullValueHandling.Ignore)]
            public string BoxCode { get; set; }

            [JsonProperty("IS_RELIEF_EXCEPTION", NullValueHandling = NullValueHandling.Ignore)]
            public string IsReliefException { get; set; }

            [JsonProperty("MONITOR_CODE", NullValueHandling = NullValueHandling.Ignore)]
            public string MonitorCode { get; set; }

            [JsonProperty("ABC", NullValueHandling = NullValueHandling.Ignore)]
            public string Abc { get; set; }

            [JsonProperty("MANDATORY_PRINT", NullValueHandling = NullValueHandling.Ignore)]
            public string MandatoryPrint { get; set; }

            [JsonProperty("SCRAP_PCT", NullValueHandling = NullValueHandling.Ignore)]
            public string ScrapPct { get; set; }

            [JsonProperty("BULK_EXPENSED", NullValueHandling = NullValueHandling.Ignore)]
            public string BulkExpensed { get; set; }

            [JsonProperty("COA", NullValueHandling = NullValueHandling.Ignore)]
            public string Coa { get; set; }

            [JsonProperty("COMPLIANCE_REQUIRED", NullValueHandling = NullValueHandling.Ignore)]
            public string ComplianceRequired { get; set; }

            [JsonProperty("CONSIGNED", NullValueHandling = NullValueHandling.Ignore)]
            public string Consigned { get; set; }

            [JsonProperty("DGP_MANAGED", NullValueHandling = NullValueHandling.Ignore)]
            public string DgpManaged { get; set; }

            [JsonProperty("DOWNLOAD_TO_ODM", NullValueHandling = NullValueHandling.Ignore)]
            public string DownloadToOdm { get; set; }

            [JsonProperty("FINISHED_GOOD", NullValueHandling = NullValueHandling.Ignore)]
            public string FinishedGood { get; set; }

            [JsonProperty("PPID_REQUIRED", NullValueHandling = NullValueHandling.Ignore)]
            public string PpidRequired { get; set; }

            [JsonProperty("RETURN_ON_ASN", NullValueHandling = NullValueHandling.Ignore)]
            public string ReturnOnAsn { get; set; }

            [JsonProperty("SUBSTITUTIONS_ALLOWED", NullValueHandling = NullValueHandling.Ignore)]
            public string SubstitutionsAllowed { get; set; }

            [JsonProperty("REVISION", NullValueHandling = NullValueHandling.Ignore)]
            public string Revision { get; set; }

            [JsonProperty("HEIGHT", NullValueHandling = NullValueHandling.Ignore)]
            public string Height { get; set; }

            [JsonProperty("HEIGHT_UM", NullValueHandling = NullValueHandling.Ignore)]
            public string HeightUm { get; set; }

            [JsonProperty("LENGTH", NullValueHandling = NullValueHandling.Ignore)]
            public string Length { get; set; }

            [JsonProperty("LENGTH_UM", NullValueHandling = NullValueHandling.Ignore)]
            public string LengthUm { get; set; }

            [JsonProperty("WIDTH", NullValueHandling = NullValueHandling.Ignore)]
            public string Width { get; set; }

            [JsonProperty("WIDTH_UM", NullValueHandling = NullValueHandling.Ignore)]
            public string WidthUm { get; set; }

            [JsonProperty("WEIGHT", NullValueHandling = NullValueHandling.Ignore)]
            public string Weight { get; set; }

            [JsonProperty("WEIGHT_UM", NullValueHandling = NullValueHandling.Ignore)]
            public string WeightUm { get; set; }

            [JsonProperty("PART_STATUS", NullValueHandling = NullValueHandling.Ignore)]
            public string PartStatus { get; set; }

            [JsonProperty("IS_FGA_SKU", NullValueHandling = NullValueHandling.Ignore)]
            public string IsFgaSku { get; set; }

            [JsonProperty("PART_TYPE", NullValueHandling = NullValueHandling.Ignore)]
            public string PartType { get; set; }

            [JsonProperty("FIELD_SERVICE_SPARE", NullValueHandling = NullValueHandling.Ignore)]
            public string FieldServiceSpare { get; set; }

            [JsonProperty("EXTERNAL_DESCRIPTION", NullValueHandling = NullValueHandling.Ignore)]
            public string ExternalDescription { get; set; }

            [JsonProperty("Battery_Wh_Rating", NullValueHandling = NullValueHandling.Ignore)]
            public string BatteryWhRating { get; set; }

            [JsonProperty("Battery_Weight", NullValueHandling = NullValueHandling.Ignore)]
            public string BatteryWeight { get; set; }

            [JsonProperty("ITEMBOM", NullValueHandling = NullValueHandling.Ignore)]
            public ItemBom[] ItembomItembom { get; set; }

            [JsonProperty("IS_ARCHIVED", NullValueHandling = NullValueHandling.Ignore)]
            public string IsArchived { get; set; }

            [JsonProperty("BOM_LEVEL", NullValueHandling = NullValueHandling.Ignore)]
            [JsonConverter(typeof(ParseStringConverter))]
            public string BomLevel { get; set; }

            [JsonProperty("COMP_ITEM", NullValueHandling = NullValueHandling.Ignore)]
            public string CompItem { get; set; }

            [JsonProperty("COMP_QTY", NullValueHandling = NullValueHandling.Ignore)]
            [JsonConverter(typeof(ParseStringConverter))]
            public string CompQty { get; set; }

            [JsonProperty("LATE_REV", NullValueHandling = NullValueHandling.Ignore)]
            public string LateRev { get; set; }

            [JsonProperty("CURRENT_VERSION_FLAG", NullValueHandling = NullValueHandling.Ignore)]
            public string CurrentVersionFlag { get; set; }

            [JsonProperty("ASSM_RELEASE_CODE", NullValueHandling = NullValueHandling.Ignore)]
            public string AssmReleaseCode { get; set; }

            [JsonProperty("TYPE", NullValueHandling = NullValueHandling.Ignore)]
            public string Type { get; set; }

            [JsonProperty("DMS_FLAG", NullValueHandling = NullValueHandling.Ignore)]
            public string DmsFlag { get; set; }

            [JsonProperty("ITEM_CLASS_CODE", NullValueHandling = NullValueHandling.Ignore)]
            public string ItemClassCode { get; set; }

            [JsonProperty("ITEM_SUB_CLASS_CODE", NullValueHandling = NullValueHandling.Ignore)]
            public string ItemSubClassCode { get; set; }

            [JsonProperty("DOC_01_FLAG", NullValueHandling = NullValueHandling.Ignore)]
            public string Doc01_Flag { get; set; }

            [JsonProperty("PART_CLASS", NullValueHandling = NullValueHandling.Ignore)]
            public string PartClass { get; set; }

            [JsonProperty("LEVEL", NullValueHandling = NullValueHandling.Ignore)]
            public string Level { get; set; }

            [JsonProperty("CFI", NullValueHandling = NullValueHandling.Ignore)]
            public string Cfi { get; set; }

            [JsonProperty("PARENT_ITEM", NullValueHandling = NullValueHandling.Ignore)]
            public string ParentItem { get; set; }

            [JsonProperty("EFFECTIVE_BEGIN_DATE", NullValueHandling = NullValueHandling.Ignore)]
            public string EffectiveBeginDate { get; set; }

            [JsonProperty("Dangerous_Goods_Class", NullValueHandling = NullValueHandling.Ignore)]
            [JsonConverter(typeof(ParseStringConverter))]
            public string DangerousGoodsClass { get; set; }

            [JsonProperty("Chemical_Type", NullValueHandling = NullValueHandling.Ignore)]
            public string ChemicalType { get; set; }

            [JsonProperty("Battery_Content_Type", NullValueHandling = NullValueHandling.Ignore)]
            public string BatteryContentType { get; set; }
        }

        public partial class ItemBomList
        {
            //public static ItemBomList FromJson(string json) => JsonConvert.DeserializeObject<ItemBomList>(json, Dell.FSL.DataService.PDSLService.Converter.Settings);
        }

        public static class Serialize
        {
            //public static string ToJson(this ItemBomList self) => JsonConvert.SerializeObject(self, Dell.FSL.DataService.PDSLService.Converter.Settings);
        }

        internal static class Converter
        {
            public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
            {
                MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
                DateParseHandling = DateParseHandling.None,
                Converters =
            {
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
            };
        }

        internal class ParseStringConverter : JsonConverter
        {
            public override bool CanConvert(Type t) => t == typeof(long) || t == typeof(long?);

            public override object ReadJson(JsonReader reader, Type t, object existingValue, JsonSerializer serializer)
            {
                if (reader.TokenType == JsonToken.Null) return null;
                var value = serializer.Deserialize<string>(reader);
                return value;
                throw new Exception("Cannot unmarshal type long");
            }

            public override void WriteJson(JsonWriter writer, object untypedValue, JsonSerializer serializer)
            {
                if (untypedValue == null)
                {
                    serializer.Serialize(writer, null);
                    return;
                }
                var value = (long)untypedValue;
                serializer.Serialize(writer, value.ToString());
                return;
            }

            public static readonly ParseStringConverter Singleton = new ParseStringConverter();
        }
    }
