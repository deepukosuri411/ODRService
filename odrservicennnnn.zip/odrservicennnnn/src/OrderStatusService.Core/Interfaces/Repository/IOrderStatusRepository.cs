﻿using OrderStatusService.Core.Model;
using OrderStatusService.Core.ViewModel;
using System.Threading.Tasks;


namespace OrderStatusService.Core.Interfaces.Repository
{
    public interface IOrderStatusRepository
    {
        #region OrderStatus 
        Task<OrderStatusProcResponse> PersistOrderStatusEntityAsync(OrderStatusInputViewModel orderStatusInputViewModel, OdrPayload odrPayload, string region,string traceId, bool isTest);
        //Task<OrderStatusProcResponse> PersistOrderStatusErrorEntityAsync(string ErrorMessage, string orderNumber);
        #endregion


    }
}