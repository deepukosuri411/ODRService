﻿using OrderStatusService.Core.ViewModel;
using System.Threading.Tasks;

namespace OrderStatusService.Core.Interfaces.Repository
{
    public interface ISyncroMessageRepository
    {
        public Task<OrderStatusOutputViewModel> ProcessSyncroMessages(OrderStatusInputViewModel orderStatusInputViewModel, OrderStatusOutputViewModel orderStatusOutputViewModel, bool isTest);
    }
}
