﻿using OrderStatusService.Core.Model;
using OrderStatusService.Core.ViewModel;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OrderStatusService.Core.Interfaces.Repository
{
    public interface IPdslRepository
    {
        public Task<ItemBomList> GetItemBomList(OrderStatusInputViewModel orderStatusInputViewModel, List<string> skuList, string regionCode, string bcrType);
        //public Task<bool> ValidateAndProcessPdslRequest(ItemBomList itemBomList, BrhSyncroMsg_Tbl order, List<FGA_ITEM_BOM_T> fgalItemBomList, List<string> skuNumList);
        public bool IsPDSLResponseValid(ItemBomList itemBomList);
    }
}
