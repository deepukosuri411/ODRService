﻿using System.Runtime.CompilerServices;

namespace OrderStatusService.Core.Interfaces.Logging
{
    public interface ICommonLogger
    {
        void Input(string traceId, string methodName, string entityType, string entityValue, params object[] list);
        void Debug(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "");
        void Error(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "");
        void Error(object type, string traceId, string logText, [CallerMemberName] string callerFunction = "");
        void Fatal(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "");
        void Info(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "");
        void Warning(object type, string traceId, string entityType, string entityValue, string logText, [CallerMemberName] string callerFunction = "");
        void Output(string traceId, string methodName, string entityType, string entityValue, params object[] list);
       
    }
}
