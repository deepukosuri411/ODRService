﻿namespace OrderStatusService.Core.Interfaces.CredHub
{
    public interface ICredHubConfigs
    {
        string LogsV2ConnectionString { get; set; }
        string HostName { get; set; }
        string HostServer { get; set; }
        string ServerName { get; set; }
        string UserName { get; set; }
        string Password { get; set; }
        string VirtualHost { get; set; }
        int Port { get; set; }
        string DaoConnectionString { get; set; }
        string ApjConnectionString { get; set; }
        string EmeaConnectionString { get; set; }
        string LDRConnectionString { get; set; }
        string SIPPConnectionString { get; set; }
    }
}
