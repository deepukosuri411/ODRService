﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace OrderStatusService.Core.Interfaces.Utility
{
    public interface IHttpMethodUtility
    {
        Task<HttpResponseMessage> HttpGetDataAsync(string requestUrl);
        Task<HttpResponseMessage> HttpPostAsync<T>(string requestUrl, T payload, Dictionary<string, string> customHeaders = null);
    }
}