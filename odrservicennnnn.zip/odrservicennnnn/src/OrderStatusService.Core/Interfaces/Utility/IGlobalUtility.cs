﻿using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.Model;

namespace OrderStatusService.Core.Interfaces.Utility
{
    public interface IGlobalUtility
    {
        ExtendedInputRequest GetExtendedInputRequest(InputRequest inputData);
        Region ExtractRegionCode(string region);
        void Map<TSource, TDestination>(TSource source, TDestination destination);
        Enumeration.DownstreamQueuingTool GetDownstreamMessageQueueTool();
        string GetDownstreamRmq(Downstream downstream);
        string GetDownstreamIbmMq(Downstream key);
        string ExtractTrigger(int eventId);
    
    }
}