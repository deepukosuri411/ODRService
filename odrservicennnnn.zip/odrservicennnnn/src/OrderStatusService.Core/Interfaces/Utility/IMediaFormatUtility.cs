﻿using OrderStatusService.Core.Enumeration;

namespace OrderStatusService.Core.Interfaces.Utility
{
    public interface IMediaFormatUtility
    {
        string SerializeToXmlorJson<T>(T objFaasResponse, string mediaType, JsonSerializerType jsonSerializerType = JsonSerializerType.NewtonSoftJson);
    }
}