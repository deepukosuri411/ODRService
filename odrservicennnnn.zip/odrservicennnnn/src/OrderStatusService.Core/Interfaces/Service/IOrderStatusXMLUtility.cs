﻿using OrderStatusService.Core.Model;
using OrderStatusService.Core.Model.Input;
using OrderStatusService.Core.Model.SpSchemaDeclarations.Udt;

namespace OrderStatusService.Core.Interfaces.Service
{
    public  interface IOrderStatusXMLUtility
    {
        ODRRequest GetOrderStatusRequestDetails(string document, BrhSyncroMsg_Tbl Order, FGA_ITEM_BOM_TBL itemBomLibrary,FSLContext ctx);
    }
}
