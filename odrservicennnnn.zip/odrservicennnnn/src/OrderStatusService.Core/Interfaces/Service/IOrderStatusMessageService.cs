﻿using Microsoft.AspNetCore.Http;
using OrderStatusService.Core.ViewModel;
using System.Threading.Tasks;

namespace OrderStatusService.Core.Interfaces.Service
{
    public interface IOrderStatusMessageService
    {
        Task<OrderStatusOutputViewModel> OrderStatusServiceAsync(IFormFile formFile, bool isTest);
    }
}
