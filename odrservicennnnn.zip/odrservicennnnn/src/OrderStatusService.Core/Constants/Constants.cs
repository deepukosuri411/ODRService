﻿using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Constants
{
    [ExcludeFromCodeCoverage]
    public class GlobalConstants
    {
        protected GlobalConstants()
        {

        }

        #region Global Constants
        public const string XmlEntityType = "XML";
        public const string SwaggerVesrion = "v1";
        #endregion

        #region Media Format Constants
        public const string XmlMediaType = "XML";
        public const string JsonMediaType = "JSON";
        #endregion

        #region Listener
        public const string RabbitMqListenerNoConfig = "{0} listener | Config data not found in Config Server Config, please check get method api/config/configserverdata for more details.";
        public const string RabbitMqListenerVmError = "{0} listener | Error: {1}.";
        public const string RabbitMqListenerSuccessfulConnectionMsg = "{0} listener | Successfully Connected.";
        public const string RabbitMqListenerSuccessfulReceiveMsg = "{0} listener | Received Message: {1}.";
        public const string RabbitMqListeneOutputDataMsg = "{0} listener | Output Data: {1}.";
        public const string RabbitMqListenerRetryMsg = "{0} listener | Retry Rabbit {1}.";
        public const string RabbitMqListenerDeadLetterQMsg = "{0} listener | Pushed Input Data to Dead Letter Queue: {1}.";
        public const string RabbitMqListenerErrorWhileTriggerMsg = "{0} listener | Exception occured while triggering the service: {1} | {2}.";
        public const string RabbitMqListenerErrorWhileReceivingMsg = "{0} listener | Exception occured while receiving messages from consumer: {1} | {2}.";
        public const string RabbitMqListenerErrorOccuredInsideMqMsg = "{0} listener | Error occured inside RabbitMQ Listener: {1} | {2}.";
        public const string RabbitMqListenerConnectionBrokenMsg = "{0} listener | Connection broken!";
        #endregion

        #region Publisher
        public const string RabbitMqPublishSuccessMsg = "{0} publisher | Pushed message to RabbitMQ.";
        public const string RabbitMqPublishExceptionMsg = "{0} MQ publisher | Exception occured while publishing message to RabbitMQ: {1}.";
        public const string RabbitMqPublishFailedMsg = "{0} MQ publisher | Unable to push to RabbitMQ.";
        public const string RabbitMqPublisherConnectionBrokenMsg = "{0} MQ publisher | Connection broken!";
        public const string RabbitMqPublishExceptionMsgDelayProc = "{0}  DelayProcessor MQ publisher | Exception occured while publishing message to Delay Processor RabbitMQ: {1}.";
        public const string RabbitMqPublishFailedMsgDelayProc = "{0} DelayProcessor MQ publisher | Unable to push to Delay Processor RabbitMQ.";
        public const string RabbitMqPublisherConnectionBrokenMsgDelayProc = "{0} DelayProcessor MQ publisher | Connection broken!";
        #endregion

        # region CredHubConfigs
        public const string LogsV2ConnectionString = "LogsV2ConnectionString";
        public const string RmqHostName = "RMQHostName";
        public const string RmqServerName = "RMQServerName";
        public const string RmqUserName = "RMQUserName";
        public const string RmqPswd = "RMQPassword";
        public const string RmqVirtualHost = "RMQVirtualHost";
        public const string RmqPort = "RMQPort";
        //public const string DaoConnectionString = "DAOConnectionString"; 
        public const string DaoConnectionString = "DAOConnectionString_SITBROWSER";
        public const string EmeaConnectionString = "EMEAConnectionString";
        public const string ApjConnectionString = "APJConnectionString";
        //public const string LDRConnectionString = "LDRConnectionString";
        public const string LDRConnectionString = "LDRConnectionString_SITBROWSER";
        public static readonly string GetUpdateProc = "GetUpdateProc";

        #endregion

        #region OtherMessage
        public const string TraceId = "TraceId";
        public const string TraceIdHeaderName = "X-B3-TraceId";
        public const string TraceIdNotAvailable = "TraceId Not Available.";
        public const string NoRecordAvailable = "No record available.";
        public const string NotSaved = "No record Saved.";
        public const string ODRService = "ODRService";
        public const string OrderStatusServiceRoute = "/ODR/ODRService";
        public const string OracleBaseApiUrl = "http://localhost:44360/";

        #endregion

        #region XmlTraverseConstants
        public const string XmlPathForOrder = "Order";
        public const string XmlPathForOrderNumber = "OrderNumber";
        public const string XmlPathForSkuNumber = "SKUNumber";
        #endregion

        #region AppFailureConstants
        public const string NoOrderFoundMessage = "There are no OrderNumbers in the message";
        public const string SyncoInValidBaseFlagMessage = "Invalid Base flag value";
        #endregion

        #region HttpClientConstants
        public const string HttpTokenType = "Bearer ";
        public const string HttpHeaderAuthKey = "authorization";
        public const string HttpMediaType = "application/json";
        public const int DefaultChunkSizeInApiRequest = 10;
        #endregion

        public const string MicroServiceNameOrderStatus = "";
        public const string TraceIdMsg = "";

        public const string InboundOdrRegion = "BRH";
    }
}