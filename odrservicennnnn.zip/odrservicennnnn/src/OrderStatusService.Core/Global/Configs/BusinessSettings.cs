﻿namespace OrderStatusService.Core.Global.Configs
{
    public class BusinessSettings
    {
        public string ValidBaseFlagKeys { get; set; }
        public string OrderTypeKeys { get; set; }
        public string BypassValidationForOrderType { get; set; }
        public string BcrType { get; set; }
        public string RequestUriGetItemBomList { get; set; }
        public string PdslJwtTokenGetItemBomList { get; set; }
        public string InboundOdrRegion { get; set; }
        public bool IsPdslRetryEnabled { get; set; }
        public int PdslRetrySleepTime { get; set; }
        public int PdslMaxRetryCount { get; set; }
    }
}