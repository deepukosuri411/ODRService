﻿using OrderStatusService.Core.Interfaces.CredHub;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Global.Configs
{
    [ExcludeFromCodeCoverage]
    public class CredHubConfigs : ICredHubConfigs
    {
        public string LogsV2ConnectionString { get; set; }
        public string HostName { get; set; }
        public string HostServer { get; set; }
        public string ServerName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string VirtualHost { get; set; }
        public int Port { get; set; }
        public string DaoConnectionString { get; set; }
        public string ApjConnectionString { get; set; }
        public string EmeaConnectionString { get; set; }
        public string LDRConnectionString { get; set; }
        public string SIPPConnectionString { get; set; }
    }
}
