﻿namespace OrderStatusService.Core.Global.Configs
{
    public class OracleTlsConfigurations
    {
        public FilesAndFolderSettings FilesAndFolderSettings { get; set; }
    }

    public class FilesAndFolderSettings
    {
        public string OracleWalletFolderName { get; set; }
        public string CWalletFileName { get; set; }
        public string EWalletFileName { get; set; }
    }
}
