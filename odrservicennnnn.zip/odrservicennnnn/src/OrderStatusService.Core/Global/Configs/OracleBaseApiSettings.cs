﻿using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Global.Configs
{
    [ExcludeFromCodeCoverage]
   public class OracleBaseApiSettings
    {
        public string OracleBaseApiUrl { get; set; }
        public string OrderStatusSPName { get; set; }
        public string OrderStatusServiceRoute { get; set; }
    }
}
