﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Global.Configs
{
    [ExcludeFromCodeCoverage]
    public class OracleSettings
    {
        public string FunctionToGetFacility { get; set; }
        public List<OracleExecution> OracleExecution { get; set; }
        public List<string> ConnKeyListSchemaNameNotNeeded { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class OracleExecution
    {
        public string OracleCommandKey { get; set; }
        public string ConnectionKey { get; set; }
        public string DbRegion { get; set; }
        public string CommandText { get; set; }
        public string CommandType { get; set; }
        public string SchemaName { get; set; }
        public List<Parameter> ParameterList { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Parameter
    {
        public string ParameterName { get; set; }
        public string UdtTypeName { get; set; }
        public string DbType { get; set; }
        public string Direction { get; set; }
        public dynamic Value { get; set; }
        public int Size { get; set; }
    }
}
