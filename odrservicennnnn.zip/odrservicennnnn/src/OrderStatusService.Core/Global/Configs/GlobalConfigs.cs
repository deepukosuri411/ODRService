﻿using Fsl.Utilities.Models;
using LogIt;
using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Global.Configs
{
    [ExcludeFromCodeCoverage]
    public class GlobalConfigs
    {
        public GlobalConfigs()
        {
            GlobalSettings = new GlobalSettings();
            RabbitMqConfigurations = new QueueConfigurations();
            HttpClientFactorySettings = new HttpClientFactorySettings();
            LogConfigs = new LogConfigs();
            BusinessSettings = new BusinessSettings();
            OracleSettings = new OracleSettings();
            OracleTlsConfigurations = new OracleTlsConfigurations();
            IbmMqConfigurations = new IbmMqConfigurations();
            IbmMqCertConfig = new IbmMqCertConfig();
            OracleBaseApiSettings = new OracleBaseApiSettings();

        }
        public OracleBaseApiSettings OracleBaseApiSettings { get; set; }
        public GlobalSettings GlobalSettings { get; set; }
        public QueueConfigurations RabbitMqConfigurations { get; set; }
        public HttpClientFactorySettings HttpClientFactorySettings { get; set; }
        public LogConfigs LogConfigs { get; set; }
        public BusinessSettings BusinessSettings { get; set; }
        public OracleSettings OracleSettings { get; set; }
        public OracleTlsConfigurations OracleTlsConfigurations { get; set; }
        public IbmMqConfigurations IbmMqConfigurations { get; set; }
        public IbmMqCertConfig IbmMqCertConfig { get; set; }
    }
}
