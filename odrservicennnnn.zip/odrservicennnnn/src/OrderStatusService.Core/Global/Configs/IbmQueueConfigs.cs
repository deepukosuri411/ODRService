﻿using System.Collections.Generic;

namespace OrderStatusService.Core.Global.Configs
{
    public class IbmQueueConfig
    {
        public string Key { get; set; }
        public string QueueName { get; set; }
    }

    public class IbmMqConfigurations
    {
        public List<IbmQueueConfig> IbmQueueConfigs { get; set; }
        public string MqHost { get; set; }
        public string MqChannel { get; set; }
        public int MqPort { get; set; }
        public string MqCiperSpecProperty { get; set; }
        public string MqCertStoreProperty { get; set; }
        public string MqQueueManager { get; set; }
        public int CharacterSetId { get; set; }
    }
}
