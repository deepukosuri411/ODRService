﻿using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Global.Configs
{
    [ExcludeFromCodeCoverage]
    public class GlobalSettings
    {
    
    }
}
