﻿using System.Diagnostics.CodeAnalysis;

namespace OrderStatusService.Core.Global.Configs
{
    [ExcludeFromCodeCoverage]
    public class HttpClientFactorySettings
    {
        public int TimeOutInMinutes { get; set; }
        public int RetryCount { get; set; }
    }
}
