﻿using System.IO;
using System.Text;

namespace OrderStatusService.Core.Common
{
    public class Utf8StringWriter : StringWriter
    {

        /// <summary>
        /// Gets the <see cref="T:System.Text.Encoding"/> in which the output is written.
        /// </summary>
        /// <returns>The Encoding in which the output is written.</returns>
        public override Encoding Encoding
        {
            get
            {
                return Encoding.UTF8;
            }
        }
    }
}
