﻿using Microsoft.Extensions.FileProviders;
using OrderStatusService.Core.Enumeration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Xsl;

namespace OrderStatusService.Core.Common
{
    public class Transformer
    {
        public static string Transform(string inputXml, XslFileName xsltFileName, XsltArgumentList xsltArguments = null)
        {
            string xsltUrl = $"{xsltFileName.ToString()}.xsl";
            string outputXml = Transform(inputXml, xsltUrl, xsltArguments);
            return outputXml;
        }

        public static string Transform(string inputXml, string xsltUrl, XsltArgumentList xsltArguments = null)
        {
            string result = string.Empty;
            MemoryStream ms = null;
            try
            {
                ms = new MemoryStream();
                using (StringReader sr = new StringReader(inputXml))
                {
                    using (XmlReader xr = XmlReader.Create(sr))
                    {
                        using (StreamReader smr = new StreamReader(ms))
                        {
                            XslCompiledTransform xct = XslCache.GetXslCache(xsltUrl);

                            using (XmlWriter xw = XmlWriter.Create(ms, xct.OutputSettings))
                            {
                                if (xsltArguments == null)
                                    xct.Transform(xr, xw);
                                else
                                    xct.Transform(xr, xsltArguments, xw);

                                ms.Position = 0;
                                result = smr.ReadToEnd();
                            }
                        }

                    }
                }
            }
            catch (Exception e)
            {
                return e.Message;
            }
            finally
            {
                ms?.Dispose();
            }
            return result;
        }


        protected class XslCache
        {
            private static readonly SortedList<string, XslCompiledTransform> xslts = new SortedList<string, XslCompiledTransform>();
            private static IFileProvider _fileProvider { get; set; }

            protected XslCache()
            {
            }

            public static XslCompiledTransform GetXslCache(string xsltUrl)
            {
                XslCompiledTransform xct = null;
                if (!File.Exists(xsltUrl))
                {
                    _fileProvider = new PhysicalFileProvider(Directory.GetCurrentDirectory());
                    var contents = _fileProvider.GetDirectoryContents("Files");
                    string path = contents?.FirstOrDefault(x => x.Name == "Xslt").PhysicalPath;
                    xsltUrl = Path.Combine(path, @xsltUrl);
                }

                bool found = xslts.TryGetValue(xsltUrl, out xct);
                if (!found)
                {
                    lock (string.Intern(xsltUrl))
                    {
                        bool StillNotfound = xslts.TryGetValue(xsltUrl, out xct);
                        if (!StillNotfound)
                        {
                            xct = new XslCompiledTransform(false);
                            XsltSettings settings = new XsltSettings(true, true);
                            xct.Load(xsltUrl, settings, new XmlUrlResolver());
                            xslts[xsltUrl] = xct;
                        }
                    }
                }

                return xct;
            }
        }
    }
}
