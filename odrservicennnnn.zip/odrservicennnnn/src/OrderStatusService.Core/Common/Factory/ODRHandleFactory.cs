﻿using OrderStatusService.Core.Enumeration;
using OrderStatusService.Core.Model;
using OrderStatusService.Core.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using FSLContext = OrderStatusService.Core.Model.FSLContext;

namespace OrderStatusService.Core.Common.Factory
{
    public class ODRHandlerFactory
    {
        readonly FSLContext ctx;
        /// <summary>
        /// creates new handler for OrderDataRequest
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="msgtype"></param>
        /// <returns></returns>
   

        /// <summary>
        /// Checks if the message pushed by Synchro or AIDOMS
        /// </summary>
        /// <param name="message"></param>
        /// <returns>true (For AIDOMS)|false (For Synchro)</returns>
        public static bool IsMessageFromDoms(string message)
        {
            MethodBase objbase = MethodInfo.GetCurrentMethod();
            //log.Info("Entered Function: " + objbase.Name);
            bool retFlag = false;
            string SenderId = string.Empty;
            XElement root = XElement.Parse(message);
            if (root.DescendantsAndSelf("Order").Elements("SenderId").Any())
            {
                SenderId = root.DescendantsAndSelf("Order").Elements("SenderId").Select(r => r.Value).SingleOrDefault();
            }

            if (Convert.ToString(SenderId).ToUpper().Equals(ValidSenderId.AIDOMS.ToString()))
            {
                retFlag = true;
            }
            return retFlag;
        }

        /// <summary>
        /// Checks if the message pushed by Synchro is valid. This checking is necessary since we made BaseFlag 
        /// as a non-mandatory element as part of Mexico Hub Ph-3 Program.
        /// </summary>
        /// <param name="message"></param>
        /// <returns>true |false </returns>
        

        /// <summary>
        /// Checks if the message pushed by Synchro is valid. This checking is necessary since we made BaseFlag 
        /// as a non-mandatory element as part of Mexico Hub Ph-3 Program.
        /// </summary>
        /// <param name="message"></param>
        /// <returns>true |false </returns>
        public static void IsPDSLCallRequired(string InputXml, FSLContext ctx, out string OrderType, out bool retFlag)
        {
            //PDSL call not required if ORDER_TYPE is either DELL_PRODUCTS|SPAREPARTS_WARRANTY|ARB_WTM
            retFlag = true;
            OrderType = string.Empty;
            try
            {
                XElement root = XElement.Parse(InputXml);

                //string SenderId = string.IsNullOrEmpty(root.DescendantsAndSelf("Order").Elements("SenderId").Select(r => r.Value).SingleOrDefault())
                //                    ? string.Empty
                //                    : root.DescendantsAndSelf("Order").Elements("SenderId").Select(r => r.Value).SingleOrDefault();

                OrderType = string.IsNullOrEmpty(root.DescendantsAndSelf("Order").Elements("OrderType").Select(r => r.Value).SingleOrDefault())
                                         ? string.Empty
                                         : root.DescendantsAndSelf("Order").Elements("OrderType").Select(r => r.Value).SingleOrDefault().ToUpper();

               
            }
            catch (Exception)
            {
                //log.Error(string.Format("Error Occurred in IsValidSynchroRequest routine for request {0}. Exception Details {1}", InputXml, e.Message));
            }
        }


        /// <summary>
        /// Assigns the MessageType based on the input message
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static MsgType GetMessageType(string message)
        {
            MethodBase objbase = MethodInfo.GetCurrentMethod();
            //log.Info("Entered Function: " + objbase.Name);

            return MsgType.SyncroMessage;
        }

        /// <summary>
        /// Retrieves the OrderNumbers in Syncro message
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static List<string> GetOrderIds(string message)
        {
            MethodBase objbase = MethodInfo.GetCurrentMethod();
            //log.Info("Entered Function: " + objbase.Name);
            List<string> orderslist = new List<string>();

            try
            {
                #region Commented old code
                //using (XmlStringHelper xmlHelper = new XmlStringHelper(message))
                //{
                //    XPathNodeIterator iterator = xmlHelper.GetNodes(FSLConstants.XPATH_ORDER);
                //    if (iterator != null)
                //    {
                //        while (iterator.MoveNext())
                //        {
                //            if (iterator.Current.MoveToFollowing(FSLConstants.ORDERNUMBER, ""))
                //            {
                //                orderslist.Add(iterator.Current.Value);
                //            }
                //        }
                //    }
                //}
                #endregion

                XElement root = XElement.Parse(message);
                var Orders = from XElement order in root.Elements(FSLConstants.XPATH_ORDER)
                             select (string)order.Element(FSLConstants.ORDERNUMBER);

                orderslist = Orders.ToList();
                //log.Info("Exited Function: " + objbase.Name);
            }
            catch (Exception)
            {
                //log.Error(string.Format("Error Occurred while populating OrderNumbers for request {0}. Exception Details {1}", message, e.Message));
            }
            return orderslist;
        }

        /// <summary>
        /// Retrieves SKU Numbers if message contains single order
        /// </summary>
        /// <param name="message"></param>
        /// <returns>List of SKU</returns>
       
        /// <summary>
        /// Retrieves SKU Numbers per order basis
        /// </summary>
        /// <param name="message"></param>
        /// <returns>Dictionary of ordernumber and SKUList</returns>
        public static Dictionary<string, List<string>> GetSkuNumListByOrder(string message)
        {
            MethodBase objbase = MethodInfo.GetCurrentMethod();
            //log.Info("Entered Function: " + objbase.Name);

            Dictionary<string, List<string>> SkuNumListByOrder = new Dictionary<string, List<string>>();
            XElement root = XElement.Parse(message);

            try
            {
                var Orders = from XElement order in root.Elements("Order")
                             select order;

                foreach (XElement order in Orders)
                {
                    string OrderNumber = string.Empty;
                    List<string> SkuNumLIst = new List<string>();

                    OrderNumber = (string)order.Element(FSLConstants.ORDERNUMBER);

                    var Skus = from XElement Sku in order.Descendants("SKU")
                               select Sku;

                    foreach (XElement Sku in Skus)
                    {
                        SkuNumLIst.Add((string)Sku.Element(FSLConstants.SKUNUMBER));
                    }
                    SkuNumListByOrder.Add(OrderNumber, SkuNumLIst);
                }
                //log.Info("Exited Function: " + objbase.Name);
            }
            catch (Exception)
            {
                //log.Error(string.Format("Error Occurred while populating GetSkuNumListByOrder for the request {0}. Error Description: {1} :", message, ex.Message));
            }

            return SkuNumListByOrder;
        }

        /// <summary>
        /// Retrieves SKU Objects per order basis if message contains multiple order
        /// </summary>
        /// <param name="message"></param>
        /// <returns>Dictionary of ordernumber and SKUList</returns>
        public static Dictionary<string, List<SKU>> GetSkuObjListByOrder(string message)
        {
            MethodBase objbase = MethodInfo.GetCurrentMethod();
            //log.Info("Entered Function: " + objbase.Name);

            Dictionary<string, List<SKU>> SkuObjListByOrder = new Dictionary<string, List<SKU>>();
            XElement root = XElement.Parse(message);

            try
            {
                var Orders = from XElement order in root.Elements("Order")
                             select order;

                foreach (XElement order in Orders)
                {
                    string OrderNumber = string.Empty;
                    List<SKU> SkuObjLIst = new List<SKU>();
                    OrderNumber = (string)order.Element(FSLConstants.ORDERNUMBER);
                    var Skus = from XElement Sku in order.Descendants("SKU")
                               select Sku;
                    foreach (XElement Sku in Skus)
                    {
                        SKU skuObj = new SKU();
                        skuObj.SKUNumber = (string)Sku.Element(FSLConstants.SKUNUMBER);
                        skuObj.SkuQty = (string)Sku.Element(FSLConstants.SKUQTY);
                        skuObj.FGID = (string)Sku.Element(FSLConstants.FGID);
                        skuObj.BaseFlag = (string)Sku.Element(FSLConstants.BASEFLAG);
                        skuObj.TieNumber = (string)Sku.Element(FSLConstants.TIENUMBER);
                        SkuObjLIst.Add(skuObj);
                    }
                    SkuObjListByOrder.Add(OrderNumber, SkuObjLIst);
                }
                //log.Info("Exited Function: " + objbase.Name);
            }
            catch (Exception)
            {
                //log.Error("Error Occurred while populating GetSkuObjListByOrder :" + ex.Message);
            }
            return SkuObjListByOrder;
        }

        /// <summary>
        /// Method to get the connection string based on the region.
        /// </summary>
        /// <param name="region"></param>
        /// <returns></returns>
      
    }
}
