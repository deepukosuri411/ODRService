﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace OrderStatusService.Core.Common.Util
{
    public class XmlHelper
    {
        private int _errorsCount = 0;
        private readonly int counter = 0;
        private string _errorMessage = "";
       
        const string xmlnsNs = "http://www.w3.org/2000/xmlns/";
        const string defaultNs = "xmlns";
        static XmlDocument output;
        private readonly Object thislock = new Object();
      
        /// <summary>
        /// Validates the XML against the given XSD.
        /// </summary>
        /// <param name="xmlData">The XML data.</param>
        /// <param name="xsdFullUrl">The XSD full URL.</param>
        /// <returns></returns>
      

        /// <summary>
        /// Validates the XML against the given XSD. Overloaded for ODR services since adding namespace on root element.
        /// </summary>
        /// <param name="xDoc">The XDocument Object.</param>
        /// <param name="xsdFullUrl">The XSD full URL.</param>
        /// <param name="TargetNamespace">The TargetNamespace as specified into XSD.</param>
        /// <returns></returns>
       
        /// <summary>
        /// Method to validate an XML against an XSD.
        /// </summary>
        /// <param name="xmlData">XML in string format.</param>
        /// <param name="key"></param>
        /// <param name="transactionReferenceID"></param>
        /// <returns></returns>
       

        /// <summary>
        /// Validations the handler for XML validation
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="args">The <see cref="System.Xml.Schema.ValidationEventArgs"/> instance containing the event data.</param>
        private void ValidationHandler(object sender, ValidationEventArgs args)
        {
            _errorMessage = _errorMessage + args.Message + "\r\n";
            _errorsCount++;
        }

        /// <summary>
        /// Deserializes from XML.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="xml">The XML.</param>
        /// <returns></returns>
        public static T DeserializeFromXml<T>(string xml)
        {
            T result;
            XmlSerializer ser = new XmlSerializer(typeof(T));

            if (xml.Contains("<ServicesCdata><Services>")) //adding CData to ServicesCdata to preserve content of the node
            {
                xml = xml.Replace("<ServicesCdata><Services>", "<ServicesCdata><![CDATA[<Services>");
                xml = xml.Replace("</Services></ServicesCdata>", "</Services>]]></ServicesCdata>");
            }
            using (TextReader tr = new StringReader(xml))
            {
                result = (T)ser.Deserialize(tr);
            }
            return result;
        }

        /// <summary>
        /// Serializes the specified type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        public static string Serialize<T>(T type)
        {
            //string output = string.Empty;
            //XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            //ns.Add("", "");
            //XmlSerializer serializer = new XmlSerializer(typeof(T));

            //using (StringWriter writer = new Utf8StringWriter())
            //{
            //    serializer.Serialize(writer, type,ns);
            //    output = writer.ToString();
            //}
            //return output;

            string output = string.Empty;
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (StringWriter writer = new Utf8StringWriter())
            {
                serializer.Serialize(writer, type);
                output = writer.ToString();
            }


            return output;
        }

        public XmlDocument StripNS(XmlDocument input)
        {
            output = new XmlDocument();
            output.PreserveWhitespace = true;
            try
            {
                foreach (XmlNode child in input.ChildNodes)
                {
                    //changed code for error 'The node to be inserted is from a different document context'
                    //The input xmldocument node is being added to the output document
                    XmlNode outputnode = output.ImportNode(StripNamespace(child), true);
                    output.AppendChild(outputnode);
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return output;
        }

        public static string RemoveAllNamespaces(string xmlDocument)
        {
            XmlDocument inputdoc = new XmlDocument();
            inputdoc.LoadXml(xmlDocument);

            XmlHelper helper = new XmlHelper();

            XmlDocument doc = helper.StripNamespace(inputdoc);
            return doc.InnerXml;

            //XElement xmlDocumentWithoutNs = RemoveAllNamespaces(XElement.Parse(xmlDocument));

            //return xmlDocumentWithoutNs.ToString();
        }


        public static string PurgeNameSpace(string MessageContent)
        {
            int Idx = MessageContent.IndexOf("<?");
            int EndIdx = 0;
            int SpaceIdx = 0;
            if (Idx > -1)
            {
                Idx = MessageContent.IndexOf("<", Idx + 1);
            }
            else
                Idx = MessageContent.IndexOf("<");

            EndIdx = MessageContent.IndexOf(">", Idx + 1);
            SpaceIdx = MessageContent.IndexOf(' ', Idx + 1);

            if (SpaceIdx > EndIdx)
            {
                SpaceIdx = MessageContent.IndexOf(Environment.NewLine, Idx + 1);
            }
            if (SpaceIdx == -1 || SpaceIdx >= EndIdx)
            {
                // no namespace to purge
                return MessageContent;
            }

            string tag = MessageContent.Substring(Idx, SpaceIdx - Idx) + ">";
            MessageContent = tag + MessageContent.Substring(EndIdx + 1);

            if (MessageContent.IndexOf("<?") > 0)
                PurgeNameSpace(MessageContent);

            return MessageContent;
        }


        //public static string PurgeNameSpace(string MessageContent)
        //{
        //    int Idx = MessageContent.IndexOf("<?");
        //    int EndIdx = 0;
        //    int SpaceIdx = 0;
        //    if (Idx > -1)
        //    {
        //        Idx = MessageContent.IndexOf("<", Idx + 1);
        //    }
        //    else
        //        Idx = MessageContent.IndexOf("<");

        //    EndIdx = MessageContent.IndexOf(">", Idx + 1);
        //    SpaceIdx = MessageContent.IndexOf(' ', Idx + 1);

        //    if (SpaceIdx > EndIdx)
        //    {
        //        SpaceIdx = MessageContent.IndexOf(Environment.NewLine, Idx + 1);
        //}
        //    if (SpaceIdx == -1 || SpaceIdx >= EndIdx)
        //    {
        //        // no namespace to purge
        //        return MessageContent;
        //    }

        //    string tag = MessageContent.Substring(Idx, SpaceIdx - Idx) + ">";
        //    MessageContent = tag + MessageContent.Substring(EndIdx + 1);

        //    if (MessageContent.IndexOf("<?") > 0)
        //        PurgeNameSpace(MessageContent);

        //    return MessageContent;
        //}


     
        //Core recursion function
        private static XElement RemoveAllNamespaces(XElement xmlDocument)
        {
            // if (!xmlDocument.HasElements)
            // {
            //     XElement xElement = new XElement(xmlDocument.Name.LocalName);
            //     xElement.Value = xmlDocument.Value;

            //     foreach (XAttribute attribute in xmlDocument.Attributes())
            //         xElement.Add(attribute);

            //     return xElement;
            // }

            //return new XElement(xmlDocument.Name.LocalName, xmlDocument.Elements().Select(el => RemoveAllNamespaces(el)));
            XElement xElement = new XElement(xmlDocument.Name.LocalName);
            foreach (XElement e in xmlDocument.Elements())
            {
                xElement = new XElement(e.Name.LocalName);
                xElement.Value = e.Value;

                if (e.HasAttributes)
                {
                    foreach (XAttribute attribute in xmlDocument.Attributes())
                    {
                        xElement.Add(attribute);
                    }

                }

            }

            return xElement;

        }

        public XmlDocument StripNamespace(XmlDocument input)
        {
            output = new XmlDocument();
            output.PreserveWhitespace = true;
            foreach (XmlNode child in input.ChildNodes)
            {
                //changed code for error 'The node to be inserted is from a different document context'
                //The input xmldocument node is being added to the output document
                output.AppendChild(output.ImportNode(StripNamespace(child), true));
            }


            return output;
        }


        XmlNode StripNamespace(XmlNode inputNode)
        {

            XmlNode outputNode = output.CreateNode(inputNode.NodeType, inputNode.LocalName, null);
            try
            {
                // copy attributes, stripping namespaces
                if (inputNode.Attributes != null)
                {
                    foreach (XmlAttribute inputAttribute in inputNode.Attributes)
                    {
                        if (!(inputAttribute.NamespaceURI == xmlnsNs || inputAttribute.LocalName == defaultNs))
                        {
                            XmlAttribute outputAttribute = output.CreateAttribute(inputAttribute.LocalName);
                            outputAttribute.Value = inputAttribute.Value;
                            outputNode.Attributes.Append(outputAttribute);
                        }
                    }
                }


                // copy child nodes, stripping namespaces
                foreach (XmlNode childNode in inputNode.ChildNodes)
                {
                    //changed code for error 'The node to be inserted is from a different document context'
                    //The input xmldocument node is being added to the output document
                    XmlNode outputnode = output.ImportNode(StripNamespace(childNode), true);
                    outputNode.AppendChild(outputnode);
                }


                // copy value for nodes without children
                if (inputNode.Value != null)
                {
                    outputNode.Value = inputNode.Value;
                }

            }
            catch (Exception ex)
            {
                //log.Error("Error occurred at Stripnamespace(Xmlnode)");
                throw ex;
            }
            return outputNode;
        }
        //return new XElement(xmlDocument.Name.LocalName, xmlDocument.Elements().Select(el => RemoveAllNamespaces(el)));

        
    }
}
