﻿using OrderStatusService.Core.Enumeration;

namespace OrderStatusService.Core.Common.Util
{
    public class DataMapper<T>
    {
        /// <param name="xslFileName">Name of the XSL file which will transform T into K.</param>
        /// <returns></returns>
        public K MapData<K>(T typeObject, XslFileName xslFileName)
        {
            //serialize an entity
            string inputxml = XmlHelper.Serialize<T>(typeObject);
            //transform the entity 
            //string outputxml = Transformer.Transform(inputxml, xslFileName, null);
            //deserialize the transformed string into type K
            K responseObject = XmlHelper.DeserializeFromXml<K>(inputxml);

            return responseObject;
        }
        /// <summary>
        /// Generic method which converts a serialized string into another object via Transformation.
        /// </summary>
        /// <param name="serializedXML">String that has to be represented as another object.</param>
        /// <param name="xslFileName">Name of XSL file which will tranform the string into a string, which when is de-serialized, will be of type K </param>
        /// <returns></returns>
        public T MapData(string serializedXML, XslFileName xslFileName)
        {
            string outputxml = Transformer.Transform(serializedXML, xslFileName, null);
            //deserialize the transformed string into type K
            T responseObject = XmlHelper.DeserializeFromXml<T>(outputxml);

            return responseObject;
        }
    }
}
