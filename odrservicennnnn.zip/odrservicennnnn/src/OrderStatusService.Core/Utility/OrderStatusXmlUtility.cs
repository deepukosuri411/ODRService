﻿

//using OrderStatusService.Core.Interfaces.Service;
//using OrderStatusService.Core.Model;
//using OrderStatusService.Core.Model.Input;
//using OrderStatusService.Core.Model.SpSchemaDeclarations.Udt;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml;

//namespace OrderStatusService.Core.Utility
//{
//    public class OrderStatusXmlUtility : IOrderStatusXMLUtility
//    {
//        public ODRRequest GetOrderStatusRequestDetails(string document, BrhSyncroMsg_Tbl SynchroOrder, FGA_ITEM_BOM_TBL ItemBomLibrary, FSLContext ctx)
//        {

//            ODRRequest orderStatusRequestInputModel = new ODRRequest();


//            orderStatusRequestInputModel.Sender_Id = ctx.ODRElement.SenderId;
//            orderStatusRequestInputModel.Created_By = System.Environment.MachineName;
//            orderStatusRequestInputModel.Clob_XML = ctx.ODRElement.RawRequestXml;
//            orderStatusRequestInputModel.AI_Order_Number = ctx.ODRElement.OrderList.FirstOrDefault();
//            //orderStatusRequestInputModel.Value1 = GetDataFromXml(document, "dell1:BUID");
//            orderStatusRequestInputModel.Order_Type = ctx.ODRElement.OrderType;
//            orderStatusRequestInputModel.Value1 = SynchroOrder;
//            orderStatusRequestInputModel.Value2 = ItemBomLibrary;


//            //var orders = GetDataFromXml(document, "dell1:SalesOrder");
//            //var salesOrders = orders.Split(',');

//            //List<Order> orderList = new List<Order>();

//            //for (int i = 0; i < salesOrders.Length; i++)
//            //{
//            //    //Order order = new Order();
//            //    //order.SalesOrder = salesOrders[i];
//            //    //order.IBU = GetDataFromXml(document, "dell1:IBU");
//            //    //orderList.Add(order);
//            //}
//            //orderStatusRequestInputModel.Order = orderList;
//            return orderStatusRequestInputModel;
//        }

//        /// <summary>
//        /// Reads data from the XML
//        /// </summary>
//        /// <param name="attrName"></param>
//        /// <returns></returns>
//        /// 
//        private string GetDataFromXml(XmlDocument _xmlDocument, string attrName)
//        {
//            string attrValue = string.Empty;
//            XmlNodeList elemList = _xmlDocument.GetElementsByTagName(attrName);
//            for (int i = 0; i < elemList.Count; i++)
//            {
//                if (string.IsNullOrEmpty(attrValue))
//                    attrValue = elemList[i].InnerText;
//                else
//                    attrValue = $"{attrValue},{elemList[i].InnerText}"; /*for more than 1 child element*/
//            }

//            return attrValue;
//        }
//    }
//}
