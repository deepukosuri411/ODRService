﻿namespace OrderStatusService.Core.Enumeration
{
    public enum ServiceName
    {
        OrderStatusService
    }
    public enum XsdFileName
    {
        ValidateOrderRequestAck
    }
    
    public enum Region
    {
        D,
        E,
        A,
        L,
        APJ,
        DAO,
        EMEA,
        B,
        LOG,
        UNKNOWN
    }

    public enum HttpAuthorization
    {
        Basic,
        Bearer,
        None
    }

    public enum JsonSerializerType
    {
        NewtonSoftJson,
        SystemTextJson
    }

    public enum XslFileName
    {
        ValidateOrderAck,
        ODR_SYNCRO_V1 = 21
    }

    public enum GloviaMsgType
    {
        MATL_MVMT_ACK,
        PO_RCPT_VALIDATION_ACK
    }
    public enum OracleCommandKey
    {
        EXTRACTSHIPMENTTRACKINGDATA,
        ISDPEDIGREEORDERS,
        GETASBUILTORDERS,
        GETDPORDERS,
        GETASBUILTDATA,
        EXTRACTLSPMASTERDATA,
        EXTRACTFDLMASTERDATA,
        EXTRACTFDLMASTERDATAFDL,
        GETPARTDETAILS,
        PERSISTORDERDATA,
        PERSISTORDERDATAFGASEED,
        PERSISTODRERRORLOG
    }

    public enum MsgType
    {
        SyncroMessage,
        DomsMessage,
        SyncroBrhMessage
    }
 
    public enum DownstreamQueuingTool
    {
        IBMMQ,
        RMQ,
        NONE
    }

    public enum ValidSenderId
    {
        AIDOMS,
        SYNCHRO
    }

    public enum Downstream
    {
        ASNMSGORCHESTRATORTOELIGIBILITY,
        ELIGIBILITYTOFAAS,
        BIL,
        FSLTOBIL,
        GPT,
        FSLTOGPT,
        CSCORE,
        FSLTOCSCORE,
        NONE
    }
}
